"""Erinnerungen/Timer: Der Bot kann sich merken, dass er die Person nach
einer bestimmten Zeit an etwas erinnern soll, und meldet sich dann von
selbst - nach demselben Prinzip wie die bestehende Begleiter-Proaktivität
(Fälligkeitsprüfung bei jedem /api/state statt eigenem Hintergrund-Thread).
"""
import json
import os
import secrets
import threading
import time

import bot

ERINNERUNGEN_DATEI = os.path.join(bot.DATEN, "erinnerungen.json")
MAX_ERINNERUNGEN = 50          # erledigte werden darüber hinaus nicht mehr aufgehoben
MAX_MINUTEN = 60 * 24 * 14     # höchstens 14 Tage im Voraus

_lock = threading.Lock()


def _lade():
    try:
        with open(ERINNERUNGEN_DATEI, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = []
    return d if isinstance(d, list) else []


def _speichere(liste):
    tmp = ERINNERUNGEN_DATEI + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(liste, f, ensure_ascii=False, indent=1)
    os.replace(tmp, ERINNERUNGEN_DATEI)


def liste():
    """Nur die noch offenen Erinnerungen, älteste zuerst."""
    with _lock:
        return sorted((e for e in _lade() if not e.get("erledigt")),
                       key=lambda e: e.get("faellig", 0))


def hinzufuegen(text, minuten):
    text = " ".join(str(text or "").split())[:200]
    try:
        minuten = float(minuten)
    except (TypeError, ValueError):
        return None
    if not text or minuten <= 0:
        return None
    minuten = min(minuten, MAX_MINUTEN)
    eintrag = {
        "id": secrets.token_hex(6),
        "text": text,
        "faellig": time.time() + minuten * 60,
        "erstellt": time.time(),
        "erledigt": False,
    }
    with _lock:
        aktuelle = _lade()
        aktuelle.append(eintrag)
        # erledigte/abgelaufene Altlasten begrenzen, damit die Datei nicht endlos wächst
        offene = [e for e in aktuelle if not e.get("erledigt")]
        erledigte = [e for e in aktuelle if e.get("erledigt")][-MAX_ERINNERUNGEN:]
        _speichere(offene + erledigte)
    return eintrag


def entfernen(eid):
    eid = str(eid or "")
    with _lock:
        aktuelle = _lade()
        neu = [e for e in aktuelle if e.get("id") != eid]
        if len(neu) == len(aktuelle):
            return False
        _speichere(neu)
        return True


def faellige_abholen():
    """Gibt alle fälligen, noch nicht ausgelieferten Erinnerungen zurück und
    markiert sie sofort als erledigt, damit sie nicht doppelt ausgeliefert
    werden."""
    jetzt = time.time()
    with _lock:
        aktuelle = _lade()
        faellig_ids = {e["id"] for e in aktuelle
                       if not e.get("erledigt") and e.get("faellig", 0) <= jetzt}
        if not faellig_ids:
            return []
        faellige = [e for e in aktuelle if e["id"] in faellig_ids]
        for e in aktuelle:
            if e["id"] in faellig_ids:
                e["erledigt"] = True
        _speichere(aktuelle)
        return faellige
