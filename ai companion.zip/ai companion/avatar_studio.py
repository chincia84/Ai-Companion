"""Avatar-Verwaltung: Garderobe, Import aus VRoid Studio und Steckbrief.

Feste Regeln:
- Neue Avatar-Dateien aus dem Importordner werden nur nach ausdrücklicher
  Bestätigung des Nutzers übernommen (nie automatisch).
- VRM-Dateien werden nur gelesen, kopiert und angezeigt, nie ausgeführt.
- Die Oberfläche kann keine Dateipfade angeben: Import läuft über IDs, Auswahl
  nur aus der Liste, Dateinamen werden bereinigt.
- Der Bot darf das Outfit wechseln, aber nur auf Namen aus der Garderobe, nur
  wenn der Nutzer es erlaubt hat und nur mit Pause zwischen zwei Wechseln.
- Für den Steckbrief gehen nur Name, Persönlichkeit, Stil und dein Wunsch an
  das Modell (bei Claude: an Anthropic), keine Fakten über dich.
"""
import hashlib
import io
import json
import os
import re
import secrets
import struct
import threading
import time
import zipfile
import zlib

import bot
import claude_partner
import live2d

BASIS = os.path.dirname(os.path.abspath(__file__))
AVATAR_DIR = os.path.join(BASIS, "avatar")
IMPORT_DIR = os.path.join(BASIS, "import")
ANIM_DIR = os.path.join(BASIS, "animationen")
ZWEID_DIR = os.path.join(BASIS, "avatare2d")
ZWEID_DATEI = os.path.join(bot.DATEN, "avatare2d.json")
MAX_ZWEID_BILD = 8 * 1024 * 1024        # 8 MB pro Bild
MAX_ZWEID_PAKET = 60 * 1024 * 1024      # 60 MB für eine hochgeladene .veadomini-Datei
MAX_VEADO_PAKET = 150 * 1024 * 1024     # 150 MB für eine hochgeladene .veado-Projektdatei
MAX_VEADO_BILDGROESSE = 4096            # Breite/Höhe je Bild in einer .veado-Datei
MAX_ZWEID_SAETZE = 30
ZUSTAENDE = bot.EMOTIONEN                # ["neutral", "freundlich", "traurig", "überrascht"]
HG_DIR = os.path.join(BASIS, "hintergruende")
HG_DATEI = os.path.join(bot.DATEN, "hintergruende.json")
MAX_HG_BILD = 20 * 1024 * 1024       # 20 MB
MAX_HG_EINTRAEGE = 40
STATUS_DATEI = os.path.join(bot.DATEN, "avatare.json")
STECKBRIEF_DATEI = os.path.join(bot.DATEN, "steckbrief.json")
MAX_AVATAR = 300 * 1024 * 1024       # 300 MB
MAX_KANDIDATEN = 50
WECHSEL_PAUSE = float(os.environ.get("KI_OUTFIT_PAUSE", "30"))   # Sekunden
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-]{0,58}\.vrm$")
ANIM_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-]{0,58}\.vrma$")
HEX_RE = re.compile(r"^#[0-9a-fA-F]{6}$")


class AvatarFehler(Exception):
    """Fehler, der dem Nutzer verständlich angezeigt wird."""


_lock = threading.RLock()
_hashes = {}
_infos = {}
_letzter_wechsel = 0.0


def _s(wert, n=120):
    return " ".join(str(wert if wert is not None else "").replace("`", "").split())[:n]


def _kurz(name):
    return re.sub(r"\.vrm$", "", str(name), flags=re.I)


def _norm(text):
    return re.sub(r"[^a-z0-9]", "", _kurz(text).lower())


# ---------- Einstellungen ----------
def _lade_status():
    st = {"aktiv": None, "beschreibungen": {}, "importiert": [], "abgelehnt": [],
          "bot_darf_wechseln": True, "import_ordner": ""}
    try:
        with open(STATUS_DATEI, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        return st
    if not isinstance(d, dict):
        return st
    typen = {"aktiv": (str, type(None)), "beschreibungen": dict, "importiert": list,
             "abgelehnt": list, "bot_darf_wechseln": bool, "import_ordner": str}
    for schluessel, typ in typen.items():
        if schluessel in d and isinstance(d[schluessel], typ):
            st[schluessel] = d[schluessel]
    return st


def _speichere_status(st):
    tmp = STATUS_DATEI + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=1)
    os.replace(tmp, STATUS_DATEI)


# ---------- VRM-Dateien ----------
def _sicherer_name(roh):
    basis = os.path.basename(str(roh).replace("\\", "/"))
    stamm = re.sub(r"\.vrm$", "", basis, flags=re.I)
    stamm = re.sub(r"[^A-Za-z0-9_.\-]", "_", stamm).strip("._-")[:50] or "avatar"
    return stamm + ".vrm"


def _freier_name(name):
    stamm, n, kandidat = name[:-4], 2, name
    while os.path.exists(os.path.join(AVATAR_DIR, kandidat)):
        kandidat = f"{stamm}-{n}.vrm"
        n += 1
    return kandidat


def _sicherer_anim_name(roh):
    basis = os.path.basename(str(roh).replace("\\", "/"))
    stamm = re.sub(r"\.vrma$", "", basis, flags=re.I)
    stamm = re.sub(r"[^A-Za-z0-9_.\-]", "_", stamm).strip("._-")[:50] or "bewegung"
    return stamm + ".vrma"


def _freier_anim_name(name):
    stamm, n, kandidat = name[:-5], 2, name
    while os.path.exists(os.path.join(ANIM_DIR, kandidat)):
        kandidat = f"{stamm}-{n}.vrma"
        n += 1
    return kandidat


def vrm_info(pfad):
    """Liest Name, Autor und Lizenz aus dem VRM-Kopf (nur lesen)."""
    try:
        with open(pfad, "rb") as f:
            kopf = f.read(20)
            if len(kopf) < 20 or kopf[:4] != b"glTF" or kopf[16:20] != b"JSON":
                return {}
            laenge = int.from_bytes(kopf[12:16], "little")
            if laenge > 8 * 1024 * 1024:
                return {}
            js = json.loads(f.read(laenge))
    except (OSError, ValueError):
        return {}
    erw = js.get("extensions", {}) if isinstance(js, dict) else {}
    v1 = (erw.get("VRMC_vrm") or {}).get("meta") if isinstance(erw, dict) else None
    if isinstance(v1, dict):
        autoren = v1.get("authors")
        autoren = ", ".join(map(str, autoren)) if isinstance(autoren, list) else autoren
        return {"version": "1.0", "name": _s(v1.get("name")), "autoren": _s(autoren),
                "lizenz": _s(v1.get("licenseUrl")),
                "kommerziell": _s(v1.get("commercialUsage"))}
    v0 = (erw.get("VRM") or {}).get("meta") if isinstance(erw, dict) else None
    if isinstance(v0, dict):
        return {"version": "0.x", "name": _s(v0.get("title")), "autoren": _s(v0.get("author")),
                "lizenz": _s(v0.get("licenseName") or v0.get("otherLicenseUrl")),
                "kommerziell": _s(v0.get("commercialUssageName"))}
    return {}


def _info_gecacht(pfad, stat):
    key = (pfad, stat.st_size, stat.st_mtime_ns)
    if key not in _infos:
        if len(_infos) > 500:
            _infos.clear()
        _infos[key] = vrm_info(pfad)
    return _infos[key]


def _hash_gecacht(pfad, stat):
    """SHA-256 der Datei, None wenn sie keine GLB/VRM-Datei ist."""
    key = (pfad, stat.st_size, stat.st_mtime_ns)
    if key in _hashes:
        return _hashes[key]
    wert = None
    try:
        with open(pfad, "rb") as f:
            kopf = f.read(4)
            if kopf == b"glTF":
                h = hashlib.sha256(kopf)
                for teil in iter(lambda: f.read(1 << 20), b""):
                    h.update(teil)
                wert = h.hexdigest()
    except OSError:
        return None
    if len(_hashes) > 500:
        _hashes.clear()
    _hashes[key] = wert
    return wert


# ---------- Garderobe ----------
def liste():
    st = _lade_status()
    ergebnis = []
    try:
        namen = sorted(os.listdir(AVATAR_DIR), key=str.lower)
    except OSError:
        return []
    for n in namen:
        pfad = os.path.join(AVATAR_DIR, n)
        if not NAME_RE.match(n):
            continue
        try:
            if not os.path.isfile(pfad):
                continue
            stat = os.stat(pfad)
        except OSError:
            continue
        ergebnis.append({"name": n, "groesse": stat.st_size,
                         "beschreibung": _s(st["beschreibungen"].get(n, "")),
                         "info": _info_gecacht(pfad, stat)})
    return ergebnis


def aktiver(st=None, lib=None):
    st = st or _lade_status()
    namen = {a["name"] for a in (lib if lib is not None else liste())}
    aktiv = st.get("aktiv")
    if aktiv is None:                       # nie gewählt: altes Einzelmodell weiterverwenden
        return "modell.vrm" if "modell.vrm" in namen else ""
    return aktiv if aktiv in namen else ""


def waehlen(name):
    name = str(name or "")
    if name and name not in {a["name"] for a in liste()}:
        raise AvatarFehler("Diesen Avatar gibt es nicht in der Garderobe.")
    with _lock:
        st = _lade_status()
        st["aktiv"] = name
        _speichere_status(st)
    if name and zd_aktiv_id():   # ein VRM- und ein 2D-Avatar schließen sich gegenseitig aus
        zd_waehlen("")
    if name and live2d.aktiv_id():
        live2d.waehlen("")


def loeschen(name):
    name = str(name or "")
    if name not in {a["name"] for a in liste()}:
        raise AvatarFehler("Diesen Avatar gibt es nicht in der Garderobe.")
    with _lock:
        st = _lade_status()
        war_aktiv = aktiver(st) == name
        try:
            os.remove(os.path.join(AVATAR_DIR, name))
        except OSError as e:
            raise AvatarFehler(f"Löschen nicht möglich ({e}).")
        st["beschreibungen"].pop(name, None)
        if war_aktiv:
            st["aktiv"] = ""
        _speichere_status(st)


def beschreibung_setzen(name, text):
    name = str(name or "")
    if name not in {a["name"] for a in liste()}:
        raise AvatarFehler("Diesen Avatar gibt es nicht in der Garderobe.")
    with _lock:
        st = _lade_status()
        st["beschreibungen"][name] = _s(text)
        _speichere_status(st)


def wechselrecht_setzen(erlaubt):
    with _lock:
        st = _lade_status()
        st["bot_darf_wechseln"] = bool(erlaubt)
        _speichere_status(st)


def hochladen(rfile, laenge, name_roh):
    """Nimmt eine VRM-Datei entgegen (Rohdaten) und legt sie in der Garderobe ab."""
    if laenge < 100 or laenge > MAX_AVATAR:
        raise AvatarFehler("Datei zu klein oder zu groß (höchstens 300 MB).")
    os.makedirs(AVATAR_DIR, exist_ok=True)
    tmp = os.path.join(AVATAR_DIR, ".upload.tmp")
    rest, kopf = laenge, b""
    try:
        with open(tmp, "wb") as f:
            while rest > 0:
                teil = rfile.read(min(1 << 20, rest))
                if not teil:
                    break
                if not kopf:
                    kopf = teil[:4]
                f.write(teil)
                rest -= len(teil)
        if rest or kopf != b"glTF":          # VRM ist eine GLB-Datei und beginnt mit "glTF"
            raise AvatarFehler("Keine gültige VRM-Datei.")
        with _lock:
            name = _freier_name(_sicherer_name(name_roh))
            os.replace(tmp, os.path.join(AVATAR_DIR, name))
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return {"name": name, "avatare": info()}


# ---------- Bewegungsdateien (.vrma) ----------
def anim_liste():
    try:
        namen = sorted(os.listdir(ANIM_DIR), key=str.lower)
    except OSError:
        return []
    ergebnis = []
    for n in namen:
        pfad = os.path.join(ANIM_DIR, n)
        if not ANIM_NAME_RE.match(n):
            continue
        try:
            if not os.path.isfile(pfad):
                continue
            groesse = os.path.getsize(pfad)
        except OSError:
            continue
        ergebnis.append({"name": n, "groesse": groesse})
    return ergebnis


def anim_hochladen(rfile, laenge, name_roh):
    """Nimmt eine VRMA-Datei entgegen (Rohdaten) und legt sie ab. Wird nie ausgeführt,
    nur als Bewegungsdaten für den Avatar im Browser abgespielt."""
    if laenge < 100 or laenge > MAX_AVATAR:
        raise AvatarFehler("Datei zu klein oder zu groß (höchstens 300 MB).")
    os.makedirs(ANIM_DIR, exist_ok=True)
    tmp = os.path.join(ANIM_DIR, ".upload.tmp")
    rest, kopf = laenge, b""
    try:
        with open(tmp, "wb") as f:
            while rest > 0:
                teil = rfile.read(min(1 << 20, rest))
                if not teil:
                    break
                if not kopf:
                    kopf = teil[:4]
                f.write(teil)
                rest -= len(teil)
        if rest or kopf != b"glTF":          # VRMA ist ebenfalls eine GLB-Datei
            raise AvatarFehler("Keine gültige VRMA-Datei.")
        with _lock:
            name = _freier_anim_name(_sicherer_anim_name(name_roh))
            os.replace(tmp, os.path.join(ANIM_DIR, name))
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return {"name": name, "avatare": info()}


def anim_loeschen(name):
    name = str(name or "")
    if name not in {a["name"] for a in anim_liste()}:
        raise AvatarFehler("Diese Bewegungsdatei gibt es nicht.")
    try:
        os.remove(os.path.join(ANIM_DIR, name))
    except OSError as e:
        raise AvatarFehler(f"Löschen nicht möglich ({e}).")


# ---------- Hintergrund für den Avatar (Farbe oder Bild, wechselbar) ----------
def _hg_lade():
    try:
        with open(HG_DATEI, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    if not isinstance(d, dict):
        d = {}
    eintraege = d.get("eintraege")
    eintraege = eintraege if isinstance(eintraege, list) else []
    aktiv = d.get("aktiv")
    return {"eintraege": eintraege, "aktiv": aktiv if isinstance(aktiv, str) else ""}


def _hg_speichere(d):
    tmp = HG_DATEI + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, HG_DATEI)


def hg_liste():
    return _hg_lade()["eintraege"]


def hg_aktiv_id():
    d = _hg_lade()
    if d["aktiv"] and any(e.get("id") == d["aktiv"] for e in d["eintraege"]):
        return d["aktiv"]
    return ""


def hg_waehlen(hg_id):
    hg_id = str(hg_id or "")
    with _lock:
        d = _hg_lade()
        if hg_id and not any(e.get("id") == hg_id for e in d["eintraege"]):
            raise AvatarFehler("Diesen Hintergrund gibt es nicht.")
        d["aktiv"] = hg_id
        _hg_speichere(d)


def hg_farbe_hinzufuegen(hex_wert, name=""):
    hex_wert = str(hex_wert or "").strip()
    if not HEX_RE.match(hex_wert):
        raise AvatarFehler("Das ist keine gültige Farbe (Format #rrggbb).")
    with _lock:
        d = _hg_lade()
        if len(d["eintraege"]) >= MAX_HG_EINTRAEGE:
            raise AvatarFehler("Es sind schon genug Hintergründe gespeichert.")
        eid = secrets.token_hex(6)
        d["eintraege"].append({"id": eid, "typ": "farbe", "wert": hex_wert.lower(), "name": _s(name, 40)})
        _hg_speichere(d)
    return eid


def _hg_bildtyp(kopf):
    if kopf.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if kopf.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if kopf[:4] == b"RIFF" and kopf[8:12] == b"WEBP":
        return ".webp"   # auch animiertes WebP - Browser spielen es automatisch ab
    if kopf[:6] in (b"GIF87a", b"GIF89a"):
        return ".gif"    # auch animiertes GIF - Browser spielen es automatisch ab
    return None


def hg_bild_hochladen(rfile, laenge, name_roh):
    """Nimmt ein Hintergrundbild entgegen. Erkennt PNG/JPEG/WebP/GIF am
    Dateikopf, unabhängig davon, was der Dateiname behauptet. WebP und GIF
    dürfen animiert sein - der Browser spielt das als CSS-Hintergrundbild
    automatisch ab."""
    if laenge < 100 or laenge > MAX_HG_BILD:
        raise AvatarFehler("Datei zu klein oder zu groß (höchstens 20 MB).")
    os.makedirs(HG_DIR, exist_ok=True)
    tmp = os.path.join(HG_DIR, ".upload.tmp")
    rest, kopf = laenge, b""
    try:
        with open(tmp, "wb") as f:
            while rest > 0:
                teil = rfile.read(min(1 << 20, rest))
                if not teil:
                    break
                if len(kopf) < 16:
                    kopf += teil[:16 - len(kopf)]
                f.write(teil)
                rest -= len(teil)
        if rest:
            raise AvatarFehler("Beim Hochladen wurde die Verbindung unterbrochen.")
        endung = _hg_bildtyp(kopf)
        if not endung:
            raise AvatarFehler("Nur PNG, JPEG, WebP oder GIF werden unterstützt.")
        with _lock:
            d = _hg_lade()
            if len(d["eintraege"]) >= MAX_HG_EINTRAEGE:
                raise AvatarFehler("Es sind schon genug Hintergründe gespeichert.")
            stamm = re.sub(r"[^A-Za-z0-9_.\-]", "_",
                           os.path.splitext(os.path.basename(str(name_roh)))[0]).strip("._-")[:50] or "hintergrund"
            dateiname, n = stamm + endung, 2
            vorhanden = {e["wert"] for e in d["eintraege"] if e["typ"] == "bild"}
            while os.path.exists(os.path.join(HG_DIR, dateiname)) or dateiname in vorhanden:
                dateiname = f"{stamm}-{n}{endung}"
                n += 1
            os.replace(tmp, os.path.join(HG_DIR, dateiname))
            eid = secrets.token_hex(6)
            d["eintraege"].append({"id": eid, "typ": "bild", "wert": dateiname, "name": stamm})
            _hg_speichere(d)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return eid


def hg_loeschen(hg_id):
    hg_id = str(hg_id or "")
    with _lock:
        d = _hg_lade()
        treffer = next((e for e in d["eintraege"] if e.get("id") == hg_id), None)
        if not treffer:
            raise AvatarFehler("Diesen Hintergrund gibt es nicht.")
        d["eintraege"] = [e for e in d["eintraege"] if e.get("id") != hg_id]
        if d["aktiv"] == hg_id:
            d["aktiv"] = ""
        _hg_speichere(d)
        if treffer["typ"] == "bild":
            try:
                os.remove(os.path.join(HG_DIR, treffer["wert"]))
            except OSError:
                pass


# ---------- Import aus VRoid Studio (nur mit Bestätigung) ----------
def _ordner_liste():
    ordner = [IMPORT_DIR]
    extra = _lade_status()["import_ordner"]
    if extra and os.path.isdir(extra) and os.path.realpath(extra) != os.path.realpath(IMPORT_DIR):
        ordner.append(extra)
    return ordner


def _kandidaten_intern():
    st = _lade_status()
    bekannt = set(st["importiert"]) | set(st["abgelehnt"])
    gesehen, ergebnis, jetzt = set(), [], time.time()
    for ordner in _ordner_liste():
        try:
            with os.scandir(ordner) as it:
                eintraege = sorted(it, key=lambda e: e.name.lower())
        except OSError:
            continue
        for e in eintraege:
            if len(ergebnis) >= MAX_KANDIDATEN:
                return ergebnis
            try:
                if not (e.is_file() and e.name.lower().endswith(".vrm")):
                    continue
                stat = e.stat()
            except OSError:
                continue
            # zu klein/groß oder noch im Export (jünger als 3 Sekunden): überspringen
            if stat.st_size < 100 or stat.st_size > MAX_AVATAR or jetzt - stat.st_mtime < 3:
                continue
            h = _hash_gecacht(e.path, stat)
            if not h or h in bekannt or h in gesehen:
                continue
            gesehen.add(h)
            ergebnis.append({"id": h[:16], "hash": h, "name": e.name, "pfad": e.path,
                             "ordner": ordner, "groesse": stat.st_size,
                             "info": _info_gecacht(e.path, stat)})
    return ergebnis


def kandidaten():
    return [{k: v for k, v in c.items() if k not in ("pfad", "hash")}
            for c in _kandidaten_intern()]


def _finde_kandidat(kid):
    for c in _kandidaten_intern():
        if c["id"] == str(kid):
            return c
    raise AvatarFehler("Diese Datei gibt es nicht mehr oder wurde schon bearbeitet.")


def importieren(kid, anziehen=False):
    c = _finde_kandidat(kid)
    os.makedirs(AVATAR_DIR, exist_ok=True)
    tmp = os.path.join(AVATAR_DIR, ".import.tmp")
    try:
        h = hashlib.sha256()
        with open(c["pfad"], "rb") as q, open(tmp, "wb") as z:
            kopf = q.read(4)
            if kopf != b"glTF":
                raise AvatarFehler("Keine gültige VRM-Datei.")
            h.update(kopf)
            z.write(kopf)
            for teil in iter(lambda: q.read(1 << 20), b""):
                h.update(teil)
                z.write(teil)
        if h.hexdigest() != c["hash"]:
            raise AvatarFehler("Die Datei hat sich beim Kopieren verändert. Bitte noch einmal versuchen.")
        with _lock:
            name = _freier_name(_sicherer_name(c["name"]))
            os.replace(tmp, os.path.join(AVATAR_DIR, name))
            st = _lade_status()
            st["importiert"].append(c["hash"])
            if anziehen:
                st["aktiv"] = name
            _speichere_status(st)
    except OSError as e:
        raise AvatarFehler(f"Kopieren nicht möglich ({e}).")
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return name


def ablehnen(kid):
    c = _finde_kandidat(kid)
    with _lock:
        st = _lade_status()
        st["abgelehnt"].append(c["hash"])
        _speichere_status(st)


def import_ordner_setzen(pfad):
    pfad = str(pfad or "").strip()
    if pfad:
        pfad = os.path.abspath(os.path.expanduser(pfad))
        if not os.path.isdir(pfad):
            raise AvatarFehler("Diesen Ordner gibt es nicht.")
    with _lock:
        st = _lade_status()
        st["import_ordner"] = pfad
        _speichere_status(st)


# ---------- Der Bot und seine Garderobe ----------
def _finde_outfit(text, lib):
    n = _norm(text)
    if not n:
        return ""
    for a in lib:
        if _norm(a["name"]) == n:
            return a["name"]
    treffer = [a["name"] for a in lib if len(n) >= 3 and n in _norm(a["name"])]
    return treffer[0] if len(treffer) == 1 else ""


def bot_zusatz():
    """Zusätzliche Hinweise für den Systemprompt: Aussehen und Outfits."""
    teile = []
    kurz = lade_steckbrief().get("kurzbeschreibung")
    if kurz:
        teile.append("So siehst du aus: " + _s(kurz, 240))
    st = _lade_status()
    lib = liste()
    if len(lib) >= 2 and st["bot_darf_wechseln"]:
        aktuell = aktiver(st, lib)
        namen = ", ".join(_kurz(a["name"]) + (f" ({a['beschreibung']})" if a["beschreibung"] else "")
                          for a in lib)
        teile.append(
            f"Du hast mehrere Outfits (Avatare): {namen}. Aktuell trägst du: "
            f"{_kurz(aktuell) or 'keines'}. Wenn du oder der Nutzer das Outfit wechseln "
            'möchte, füge deiner JSON-Antwort zusätzlich das Feld "outfit" mit genau einem '
            "dieser Namen hinzu. Wechsle nicht ohne Grund und nicht ständig, sonst lass "
            "das Feld einfach weg.")
    return " ".join(teile)


def bot_wechsel(outfit):
    """Wechselt auf Wunsch des Bots das Outfit. Gibt den neuen Dateinamen zurück oder ''."""
    global _letzter_wechsel
    if not str(outfit or "").strip():
        return ""
    st = _lade_status()
    if not st["bot_darf_wechseln"]:
        return ""
    lib = liste()
    ziel = _finde_outfit(outfit, lib)
    if not ziel or ziel == aktiver(st, lib):
        return ""
    with _lock:
        if time.time() - _letzter_wechsel < WECHSEL_PAUSE:
            return ""
        _letzter_wechsel = time.time()
        st = _lade_status()
        st["aktiv"] = ziel
        _speichere_status(st)
    return ziel


# ---------- Steckbrief: Aussehen entwerfen ----------
FELDER = {
    "gesicht": ["form", "augen", "augenfarbe", "augenbrauen", "nase_mund", "besonderheiten"],
    "haare": ["laenge", "stil", "farbe", "pony", "accessoires"],
    "koerper": ["groesse", "statur", "hautton"],
    "kleidung": ["oberteil", "unterteil", "schuhe", "farben"],
}
LABEL = {"form": "Form", "augen": "Augen", "augenfarbe": "Augenfarbe",
         "augenbrauen": "Augenbrauen", "nase_mund": "Nase und Mund",
         "besonderheiten": "Besonderheiten", "laenge": "Länge", "stil": "Stil",
         "farbe": "Farbe", "pony": "Pony", "accessoires": "Accessoires",
         "groesse": "Größe", "statur": "Statur", "hautton": "Hautton",
         "oberteil": "Oberteil", "unterteil": "Unterteil / Kleid",
         "schuhe": "Schuhe", "farben": "Farben"}
TITEL = {"gesicht": "GESICHT", "haare": "HAARE", "koerper": "KÖRPER", "kleidung": "KLEIDUNG"}
SCHEMA = ('{"name": "", "kurzbeschreibung": "", '
          '"gesicht": {"form": "", "augen": "", "augenfarbe": "", "augenbrauen": "", '
          '"nase_mund": "", "besonderheiten": ""}, '
          '"haare": {"laenge": "", "stil": "", "farbe": "", "pony": "", "accessoires": ""}, '
          '"koerper": {"groesse": "", "statur": "", "hautton": ""}, '
          '"kleidung": {"oberteil": "", "unterteil": "", "schuhe": "", "farben": ""}, '
          '"accessoires": "", "farbpalette": ["#rrggbb"]}')


def lade_steckbrief():
    try:
        with open(STECKBRIEF_DATEI, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        return {}
    return d if isinstance(d, dict) else {}


def _stimmen_hinweis(persona):
    stimme = str(persona.get("stimme", "")).lower()
    if any(n in stimme for n in ("ramona", "kerstin", "eva_k")):
        return "Die Stimme des Bots klingt weiblich, das Aussehen soll dazu passen."
    if "thorsten" in stimme:
        return "Die Stimme des Bots klingt männlich, das Aussehen soll dazu passen."
    return ""


def _prompt(wunsch):
    p = bot.lade_persona()
    teile = [f"Du bist Charakterdesigner und entwirfst das Aussehen eines KI-Bots namens "
             f"{p['name']} für den Avatar-Editor VRoid Studio (Anime-Stil).",
             f"Persönlichkeit: {p['beschreibung']}", f"Sprechstil: {p['stil']}."]
    hinweis = _stimmen_hinweis(p)
    if hinweis:
        teile.append(hinweis)
    if wunsch:
        teile.append(f"Wünsche des Nutzers: {wunsch}")
    teile.append("Alle Werte sind kurze, konkrete Angaben auf Deutsch (Farben mit Namen). "
                 "Die Figur soll zur Persönlichkeit passen. Antworte NUR mit einem "
                 "JSON-Objekt in genau dieser Form: " + SCHEMA)
    return " ".join(teile)


def _json_aus_text(text):
    a, b = text.find("{"), text.rfind("}")
    if a == -1 or b <= a:
        raise AvatarFehler("Die Antwort war kein gültiges JSON.")
    try:
        return json.loads(text[a:b + 1])
    except ValueError:
        raise AvatarFehler("Die Antwort war kein gültiges JSON.")


def _bereinigen(roh):
    if not isinstance(roh, dict):
        raise AvatarFehler("Der Entwurf hatte nicht die erwartete Form.")
    sb = {"name": _s(roh.get("name"), 60), "kurzbeschreibung": _s(roh.get("kurzbeschreibung"), 240),
          "accessoires": _s(roh.get("accessoires"), 160)}
    gefuellt = 0
    for gruppe, felder in FELDER.items():
        teil = roh.get(gruppe)
        teil = teil if isinstance(teil, dict) else {}
        sb[gruppe] = {}
        for feld in felder:
            wert = _s(teil.get(feld))
            sb[gruppe][feld] = wert
            gefuellt += bool(wert)
    farben = roh.get("farbpalette")
    farben = farben if isinstance(farben, list) else []
    sb["farbpalette"] = [c.strip() for c in farben
                         if isinstance(c, str) and HEX_RE.match(c.strip())][:5]
    if gefuellt < 8 or not sb["kurzbeschreibung"]:
        raise AvatarFehler("Der Entwurf war unvollständig. Bitte noch einmal versuchen.")
    return sb


def _als_text(sb):
    zeilen = [f"STECKBRIEF: {sb['name'] or bot.lade_persona()['name']}",
              sb["kurzbeschreibung"], ""]
    for gruppe, felder in FELDER.items():
        eintraege = [f"  ☐ {LABEL[f]}: {sb[gruppe][f]}" for f in felder if sb[gruppe][f]]
        if eintraege:
            zeilen += [TITEL[gruppe]] + eintraege + [""]
    if sb["accessoires"]:
        zeilen += ["ACCESSOIRES", f"  ☐ {sb['accessoires']}", ""]
    if sb["farbpalette"]:
        zeilen += ["FARBPALETTE: " + "  ".join(sb["farbpalette"]), ""]
    zeilen += ["Hinweis: Die Bezeichnungen in VRoid Studio können abweichen.",
               f"Exportiere die fertige Figur als .vrm in den Ordner: {IMPORT_DIR}"]
    return "\n".join(zeilen)


def steckbrief_erstellen(quelle, wunsch=""):
    wunsch = _s(wunsch, 200)
    system = _prompt(wunsch)
    if quelle == "claude":
        if not claude_partner.hole_key():
            raise AvatarFehler("Für den Entwurf mit Claude fehlt der API-Schlüssel "
                               "(Bereich \"Gespräch mit Claude\").")
        try:
            text, _ = claude_partner._api(
                system, [{"role": "user", "content": "Entwirf jetzt das Aussehen."}],
                claude_partner.aktuelles_modell(), 900)
        except claude_partner.ClaudeFehler as e:
            raise AvatarFehler(str(e))
        roh, herkunft = _json_aus_text(text), "Claude"
    else:
        try:
            roh = bot.frage_json(system, "Entwirf jetzt das Aussehen.")
        except Exception as e:  # noqa: BLE001
            raise AvatarFehler(f"Der lokale Bot hat keinen brauchbaren Entwurf geliefert ({e}). "
                               "Läuft Ollama?")
        herkunft = "lokaler Bot"
    sb = _bereinigen(roh)
    sb.update({"text": _als_text(sb), "quelle": herkunft, "wunsch": wunsch,
               "erstellt": time.strftime("%Y-%m-%d %H:%M")})
    with _lock:
        tmp = STECKBRIEF_DATEI + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(sb, f, ensure_ascii=False, indent=1)
        os.replace(tmp, STECKBRIEF_DATEI)
    return sb




# ---------- 2D-Avatare: Sets aus Bildern je Stimmung (PNG/JPEG/WebP) ----------
def _zd_lade():
    try:
        with open(ZWEID_DATEI, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    if not isinstance(d, dict):
        d = {}
    saetze = d.get("saetze")
    saetze = saetze if isinstance(saetze, list) else []
    bereinigt = []
    for s in saetze:
        if not isinstance(s, dict) or "id" not in s:
            continue
        zustaende = s.get("zustaende")
        s["zustaende"] = zustaende if isinstance(zustaende, dict) else {}
        s["name"] = str(s.get("name", ""))[:40] or "Avatar"
        bereinigt.append(s)
    aktiv = d.get("aktiv")
    return {"saetze": bereinigt, "aktiv": aktiv if isinstance(aktiv, str) else ""}


def _zd_speichere(d):
    os.makedirs(os.path.dirname(ZWEID_DATEI), exist_ok=True)
    tmp = ZWEID_DATEI + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, ZWEID_DATEI)


def _zd_satz_finden(d, satz_id):
    for s in d["saetze"]:
        if s["id"] == satz_id:
            return s
    return None


def zd_liste():
    return _zd_lade()["saetze"]


def zd_aktiv_id():
    d = _zd_lade()
    if d["aktiv"] and _zd_satz_finden(d, d["aktiv"]):
        return d["aktiv"]
    return ""


def zd_waehlen(satz_id):
    satz_id = str(satz_id or "")
    with _lock:
        d = _zd_lade()
        if satz_id and not _zd_satz_finden(d, satz_id):
            raise AvatarFehler("Dieses 2D-Avatar-Set gibt es nicht.")
        d["aktiv"] = satz_id
        _zd_speichere(d)
    if satz_id and aktiver():   # ein 2D- und ein VRM-Avatar schließen sich gegenseitig aus
        waehlen("")
    if satz_id and live2d.aktiv_id():
        live2d.waehlen("")


def zd_satz_erstellen(name):
    name = " ".join(str(name or "Mein Avatar").split())[:40] or "Mein Avatar"
    with _lock:
        d = _zd_lade()
        if len(d["saetze"]) >= MAX_ZWEID_SAETZE:
            raise AvatarFehler("Es sind schon genug 2D-Avatare gespeichert.")
        sid = secrets.token_hex(6)
        d["saetze"].append({"id": sid, "name": name, "zustaende": {}})
        _zd_speichere(d)
    return sid


def zd_satz_umbenennen(satz_id, name):
    name = " ".join(str(name or "").split())[:40]
    if not name:
        raise AvatarFehler("Bitte einen Namen angeben.")
    with _lock:
        d = _zd_lade()
        satz = _zd_satz_finden(d, satz_id)
        if not satz:
            raise AvatarFehler("Dieses 2D-Avatar-Set gibt es nicht.")
        satz["name"] = name
        _zd_speichere(d)


def zd_satz_loeschen(satz_id):
    with _lock:
        d = _zd_lade()
        satz = _zd_satz_finden(d, satz_id)
        if not satz:
            raise AvatarFehler("Dieses 2D-Avatar-Set gibt es nicht.")
        d["saetze"] = [s for s in d["saetze"] if s["id"] != satz_id]
        if d["aktiv"] == satz_id:
            d["aktiv"] = ""
        _zd_speichere(d)
    for dateiname in satz["zustaende"].values():
        try:
            os.remove(os.path.join(ZWEID_DIR, dateiname))
        except OSError:
            pass


def _zd_bild_speichern(satz_id, zustand, endung, inhalt):
    """Legt Bilddaten ab und trägt sie im angegebenen Set/Zustand ein; löscht ein
    dabei ersetztes altes Bild. Nimmt fertige Bytes entgegen (kein Datei-I/O hier)."""
    os.makedirs(ZWEID_DIR, exist_ok=True)
    dateiname = f"{satz_id}-{zustand}-{secrets.token_hex(4)}{endung}"
    with _lock:
        d = _zd_lade()
        satz = _zd_satz_finden(d, satz_id)
        if not satz:
            raise AvatarFehler("Dieses 2D-Avatar-Set gibt es nicht.")
        alt = satz["zustaende"].get(zustand)
        with open(os.path.join(ZWEID_DIR, dateiname), "wb") as f:
            f.write(inhalt)
        satz["zustaende"][zustand] = dateiname
        _zd_speichere(d)
    if alt:
        try:
            os.remove(os.path.join(ZWEID_DIR, alt))
        except OSError:
            pass


def zd_bild_setzen(satz_id, zustand, rfile, laenge):
    if zustand not in ZUSTAENDE:
        raise AvatarFehler("Unbekannter Zustand.")
    if laenge < 100 or laenge > MAX_ZWEID_BILD:
        raise AvatarFehler("Datei zu klein oder zu groß (höchstens 8 MB).")
    tmp = os.path.join(ZWEID_DIR, ".upload.tmp")
    os.makedirs(ZWEID_DIR, exist_ok=True)
    rest, kopf = laenge, b""
    try:
        with open(tmp, "wb") as f:
            while rest > 0:
                teil = rfile.read(min(1 << 20, rest))
                if not teil:
                    break
                if len(kopf) < 16:
                    kopf += teil[:16 - len(kopf)]
                f.write(teil)
                rest -= len(teil)
        if rest:
            raise AvatarFehler("Beim Hochladen wurde die Verbindung unterbrochen.")
        endung = _hg_bildtyp(kopf)
        if not endung:
            raise AvatarFehler("Nur PNG, JPEG, WebP oder GIF werden unterstützt.")
        with open(tmp, "rb") as f:
            inhalt = f.read()
        _zd_bild_speichern(satz_id, zustand, endung, inhalt)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def zd_zustand_entfernen(satz_id, zustand):
    with _lock:
        d = _zd_lade()
        satz = _zd_satz_finden(d, satz_id)
        if not satz:
            raise AvatarFehler("Dieses 2D-Avatar-Set gibt es nicht.")
        alt = satz["zustaende"].pop(zustand, None)
        _zd_speichere(d)
    if alt:
        try:
            os.remove(os.path.join(ZWEID_DIR, alt))
        except OSError:
            pass


# ---------- veado-Import (.veado - rohes Projektformat von veadotube mini) ----------
# Anders als die .veadomini-ZIP-Exportdatei (siehe unten) ist eine .veado-Datei
# das interne Chunk-Format von veadotube mini selbst: sie beginnt mit der
# ASCII-Kennung "VEADOTUBE", gefolgt von einer Folge selbstbeschreibender
# Chunks (4-Byte-ID, 4-Byte-FourCC-Typ, 4-Byte-Länge, Daten; alles Little-
# Endian). Für uns wichtig: MLST listet die Zustände (MSTA-Chunks) des
# Avatars auf; jeder MSTA-Chunk nennt u.a. 8 Bild-Chunk-IDs (die ersten 4
# sind kleine Vorschaubilder, die letzten 4 die Vollbilder - wir nehmen das
# erste Vollbild als Standardpose). Ein Vollbild ist ein AIMG-Chunk (Breite,
# Höhe, Verweis auf einen ABMP-Chunk mit den eigentlichen Pixeldaten). Die
# Pixeldaten selbst liegen entweder unkomprimiert ("RAW.") oder mit der
# proprietären "VDD."-Delta-RLE-Kompression vor (pro Farbkanal A,R,G,B
# getrennt, siehe _vdd_kanal_decodieren).

def _veado_varint_lesen(daten, pos):
    """Liest eine 7-Bit-codierte variable Ganzzahl (ein Byte pro 7 Datenbits,
    oberstes Bit = 'es folgt noch ein Byte')."""
    ergebnis = 0
    verschiebung = 0
    while True:
        b = daten[pos]
        pos += 1
        ergebnis |= (b & 0x7F) << verschiebung
        if not (b & 0x80):
            break
        verschiebung += 7
    return ergebnis, pos


def _veado_text_lesen(daten, pos):
    """Liest einen längenpräfixierten UTF-8-Text (Länge als Varint)."""
    laenge, pos = _veado_varint_lesen(daten, pos)
    text = daten[pos:pos + laenge].decode("utf-8", "replace")
    return text, pos + laenge


def _veado_chunks_lesen(daten):
    if daten[:9] != b"VEADOTUBE":
        raise AvatarFehler("Das ist keine .veado-Datei (falsche Kennung am "
                           "Dateianfang). Für die .veadomini-ZIP-Exportdatei "
                           "gibt es den Import oben.")
    pos = 9
    gesamt = len(daten)
    chunks = {}
    while pos + 12 <= gesamt:
        cid, ctyp, clen = struct.unpack_from("<I4sI", daten, pos)
        if cid == 0 and ctyp == b"\x00\x00\x00\x00":
            break
        if pos + 12 + clen > gesamt:
            raise AvatarFehler("Die .veado-Datei ist beschädigt (ein Chunk "
                               "reicht über das Dateiende hinaus).")
        chunks[cid] = (ctyp, daten[pos + 12: pos + 12 + clen])
        pos += 12 + clen
    return chunks


class _VeadoBitLeser:
    """Liest Bits aus einem bytes-Objekt, beginnend beim niederwertigsten Bit
    jedes Bytes (so verwendet es das VDD-Format - anhand einer echten Datei
    verifiziert)."""
    __slots__ = ("daten", "bytepos", "bitpos", "ueberlauf")

    def __init__(self, daten):
        self.daten = daten
        self.bytepos = 0
        self.bitpos = 0
        self.ueberlauf = False

    def bit(self):
        if self.bytepos >= len(self.daten):
            self.ueberlauf = True
            return 0
        wert = (self.daten[self.bytepos] >> self.bitpos) & 1
        self.bitpos += 1
        if self.bitpos == 8:
            self.bitpos = 0
            self.bytepos += 1
        return wert

    def bits(self, n):
        v = 0
        for i in range(n):
            v |= self.bit() << i
        return v


def _vdd_kanal_decodieren(daten, anzahl_werte, start):
    """Decodiert einen einzelnen VDD-Farbkanal (Delta-RLE) zu `anzahl_werte`
    Werten (0-255). Siehe veado.tube/docs/tech/file/images/ für die
    Präfix-Code-Tabelle; Bit-/Wertreihenfolge wurde an einer echten Datei
    verifiziert (exakte Pixelanzahl ohne Rest)."""
    br = _VeadoBitLeser(daten)
    out = []
    aktuell = start
    while len(out) < anzahl_werte and not br.ueberlauf:
        delta = 0
        wiederhole = 1
        if br.bit() == 1:
            if br.bit() == 1:
                delta = br.bits(1) + 1
        elif br.bit() == 1:
            if br.bit() == 0:
                delta = br.bits(1) + 3
            else:
                delta = br.bits(2) + 5
        elif br.bit() == 1:
            if br.bit() == 0:
                delta = br.bits(3) + 9
            else:
                delta = br.bits(4) + 17
        elif br.bit() == 1:
            if br.bit() == 0:
                delta = br.bits(5) + 33
            else:
                delta = br.bits(6) + 65
        else:
            wiederhole = br.bits(8) + 7
        if delta != 0:
            if br.bit() == 0:
                delta = -delta
        for _ in range(wiederhole):
            aktuell = (aktuell + delta) % 256
            out.append(aktuell)
            if len(out) >= anzahl_werte:
                break
    if len(out) < anzahl_werte:
        raise AvatarFehler("Bilddaten in der .veado-Datei sind unvollständig "
                           "oder beschädigt.")
    return out


def _vdd_bild_decodieren(textur, breite, hoehe):
    if len(textur) < 16:
        raise AvatarFehler("Unvollständige Bilddaten (VDD) in der .veado-Datei.")
    laengen_worte = struct.unpack_from("<4I", textur, 0)
    gesamt = breite * hoehe
    pos = 16
    kanaele = {}
    alpha = None
    for i, laenge_worte in enumerate(laengen_worte):
        name = "ARGB"[i]
        if laenge_worte >= 0xFFFFFF00:
            konst = laenge_worte & 0xFF
            anzahl = gesamt if i == 0 else sum(1 for a in alpha if a != 0)
            werte = [konst] * anzahl
        else:
            laenge_bytes = laenge_worte * 4
            segment = textur[pos: pos + laenge_bytes]
            if len(segment) < laenge_bytes:
                raise AvatarFehler("Unvollständige Bilddaten (VDD) in der "
                                   ".veado-Datei.")
            pos += laenge_bytes
            if i == 0:
                werte = _vdd_kanal_decodieren(segment, gesamt, start=255)
            else:
                anzahl = sum(1 for a in alpha if a != 0)
                werte = _vdd_kanal_decodieren(segment, anzahl, start=0)
        if i == 0:
            alpha = werte
        kanaele[name] = werte

    a_l, r_l, g_l, b_l = kanaele["A"], kanaele["R"], kanaele["G"], kanaele["B"]
    rgba = bytearray(gesamt * 4)
    ri = gi = bi = 0
    for idx in range(gesamt):
        a = a_l[idx]
        if a == 0:
            r = g = b = 0
        else:
            r = r_l[ri]; ri += 1
            g = g_l[gi]; gi += 1
            b = b_l[bi]; bi += 1
        rgba[idx * 4: idx * 4 + 4] = bytes((r, g, b, a))

    # Pixelreihenfolge laut Spezifikation: zeilenweise von unten nach oben,
    # jede Zeile links nach rechts - für ein normales Bild (oben->unten, wie
    # PNG es erwartet) zeilenweise umsortieren.
    stride = breite * 4
    endgueltig = bytearray(gesamt * 4)
    for y_von_unten in range(hoehe):
        quelle = y_von_unten * stride
        ziel = (hoehe - 1 - y_von_unten) * stride
        endgueltig[ziel: ziel + stride] = rgba[quelle: quelle + stride]
    return bytes(endgueltig)


def _veado_png_schreiben(breite, hoehe, rgba):
    """Baut eine minimale, gültige PNG-Datei (8-Bit-RGBA, unkomprimierter
    Filtertyp 0) ohne externe Bildbibliothek - nur zlib aus der
    Standardbibliothek."""
    def chunk(typ, daten):
        return (struct.pack(">I", len(daten)) + typ + daten +
                struct.pack(">I", zlib.crc32(typ + daten) & 0xFFFFFFFF))
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", breite, hoehe, 8, 6, 0, 0, 0)
    stride = breite * 4
    zeilen = bytearray()
    for y in range(hoehe):
        zeilen.append(0)
        zeilen += rgba[y * stride: (y + 1) * stride]
    idat = zlib.compress(bytes(zeilen), 6)
    return sig + chunk(b"IHDR", ihdr) + chunk(b"IDAT", idat) + chunk(b"IEND", b"")


def _veado_bild_zu_png(abmp_bytes):
    if len(abmp_bytes) < 12:
        raise AvatarFehler("Ungültiger Bild-Chunk in der .veado-Datei.")
    breite, hoehe = struct.unpack_from("<II", abmp_bytes, 0)
    if not (0 < breite <= MAX_VEADO_BILDGROESSE and 0 < hoehe <= MAX_VEADO_BILDGROESSE):
        raise AvatarFehler(f"Bildgröße in der .veado-Datei wird nicht unterstützt "
                            f"(max. {MAX_VEADO_BILDGROESSE}×{MAX_VEADO_BILDGROESSE}).")
    fourcc = abmp_bytes[8:12]
    textur = abmp_bytes[12:]
    gesamt = breite * hoehe
    if fourcc == b"RAW.":
        if len(textur) < gesamt * 4:
            raise AvatarFehler("Unvollständige Bilddaten (RAW) in der .veado-Datei.")
        # RAW liegt wie VDD von unten nach oben vor - ebenfalls umsortieren.
        stride = breite * 4
        rohdaten = textur[:gesamt * 4]
        rgba = bytearray(gesamt * 4)
        for y_von_unten in range(hoehe):
            quelle = y_von_unten * stride
            ziel = (hoehe - 1 - y_von_unten) * stride
            rgba[ziel: ziel + stride] = rohdaten[quelle: quelle + stride]
        rgba = bytes(rgba)
    elif fourcc == b"VDD.":
        rgba = _vdd_bild_decodieren(textur, breite, hoehe)
    else:
        raise AvatarFehler("Unbekanntes Bildformat in der .veado-Datei.")
    return _veado_png_schreiben(breite, hoehe, rgba)


def _veado_aimg_erstes_abmp(aimg_bytes):
    """Liest aus einem AIMG-Chunk die ID des ABMP-Chunks des ersten Frames
    (Animationen mit mehreren Frames werden nicht unterstützt - wir zeigen
    immer nur ein stehendes Bild)."""
    if len(aimg_bytes) < 9:
        return None
    pos = 8
    framezahl, pos = _veado_varint_lesen(aimg_bytes, pos)
    if framezahl < 1:
        return None
    if framezahl > 1:
        _, pos = _veado_varint_lesen(aimg_bytes, pos)   # Wiederholungszahl, unbenutzt
    if pos + 4 > len(aimg_bytes):
        return None
    return struct.unpack_from("<I", aimg_bytes, pos)[0]


def _veado_zustand_bild(chunks, msta_bytes):
    """Liefert (Name, PNG-Bytes) für einen MSTA-Zustands-Chunk, oder
    (Name, None), wenn kein lesbares Bild gefunden wurde."""
    name, pos = _veado_text_lesen(msta_bytes, 0)
    pos += 1   # Zustands-Flags (1 Byte) - hier nicht benötigt
    # Besonderheit: diese 8 Bild-Verweise sind (anders als der Rest des
    # .veado-Formats, das little-endian ist) big-endian kodiert - an einer
    # echten Testdatei verifiziert.
    bild_ids = struct.unpack_from(">8I", msta_bytes, pos)
    # Die ersten 4 IDs sind (an einer echten Datei verifiziert) die kleinen
    # Vorschaubilder, die letzten 4 die Vollbilder - das erste Vollbild wird
    # als Standardpose für diesen Zustand verwendet.
    aimg = chunks.get(bild_ids[4])
    if not aimg or aimg[0] != b"AIMG":
        return name, None
    abmp_id = _veado_aimg_erstes_abmp(aimg[1])
    if abmp_id is None:
        return name, None
    abmp = chunks.get(abmp_id)
    if not abmp or abmp[0] != b"ABMP":
        return name, None
    try:
        return name, _veado_bild_zu_png(abmp[1])
    except AvatarFehler:
        return name, None


def veado_importieren(rfile, laenge, name_roh):
    """Liest eine .veado-Datei (rohes veadotube-mini-Projektformat) und legt
    daraus ein neues 2D-Avatar-Set an - wie veadomini_importieren() unten,
    nur für das interne Projektformat statt der einfachen ZIP-Exportdatei.
    Zustände, deren Name eine Stimmung erkennen lässt, werden automatisch
    zugeordnet; hat kein Zustand einen erkennbaren Namen (z.B. weil sie nie
    umbenannt wurden), wird der erste als 'neutral' verwendet."""
    if laenge < 16 or laenge > MAX_VEADO_PAKET:
        raise AvatarFehler("Datei zu klein oder zu groß (höchstens 150 MB).")
    puffer = io.BytesIO()
    rest = laenge
    while rest > 0:
        teil = rfile.read(min(1 << 20, rest))
        if not teil:
            break
        puffer.write(teil)
        rest -= len(teil)
    if rest:
        raise AvatarFehler("Beim Hochladen wurde die Verbindung unterbrochen.")
    daten = puffer.getvalue()

    chunks = _veado_chunks_lesen(daten)
    mlst = next((b for t, b in chunks.values() if t == b"MLST"), None)
    if mlst is None:
        raise AvatarFehler("In der .veado-Datei wurde keine Zustandsliste "
                           "gefunden. Ist das wirklich eine .veado-Projektdatei "
                           "von veadotube mini?")
    anzahl = len(mlst) // 4
    zustand_ids = struct.unpack_from(f"<{anzahl}I", mlst, 0) if anzahl else ()

    # Namen zuerst billig auslesen - das eigentliche Bild wird erst gleich
    # gezielt nur für die Zustände decodiert, die am Ende auch benutzt werden
    # (das Decodieren ist der aufwendige Teil).
    zustaende = []
    for zid in zustand_ids:
        eintrag = chunks.get(zid)
        if not eintrag or eintrag[0] != b"MSTA":
            continue
        try:
            name, _ = _veado_text_lesen(eintrag[1], 0)
        except (struct.error, IndexError):
            name = ""
        zustaende.append((name, eintrag[1]))
    if not zustaende:
        raise AvatarFehler("In der .veado-Datei wurden keine Avatar-Zustände "
                           "gefunden.")

    zuordnung, rest_msta = {}, []
    for name, msta_bytes in zustaende:
        zustand = _zd_zustand_aus_dateiname(name) if name else None
        if zustand and zustand not in zuordnung:
            zuordnung[zustand] = msta_bytes
        else:
            rest_msta.append(msta_bytes)
    if "neutral" not in zuordnung:
        zuordnung["neutral"] = rest_msta.pop(0) if rest_msta else zustaende[0][1]

    stamm = re.sub(r"[^\w .\-]", "", os.path.splitext(os.path.basename(str(name_roh)))[0],
                   flags=re.UNICODE).strip()
    satz_id = zd_satz_erstellen(stamm or "Importiert")

    erkannt = []
    for zustand, msta_bytes in zuordnung.items():
        try:
            _, png_bytes = _veado_zustand_bild(chunks, msta_bytes)
        except (struct.error, IndexError):
            png_bytes = None
        if png_bytes:
            _zd_bild_speichern(satz_id, zustand, ".png", png_bytes)
            erkannt.append(zustand)
    if not erkannt:
        raise AvatarFehler("Aus der .veado-Datei konnte kein lesbares Bild "
                           "extrahiert werden.")

    return {"id": satz_id, "erkannt": sorted(erkannt),
            "nicht_zugeordnet": max(0, len(zustaende) - len(erkannt))}


# ---------- veadotube-Import (.veadomini) ----------
# Stichworte, an denen sich eine Stimmung im Dateinamen erkennen lässt. Bilder, die zu
# keinem Stichwort passen, werden nicht automatisch zugeordnet, sondern bleiben als
# "nicht zugeordnet" stehen; die Person ordnet sie danach selbst per Hand zu.
_VEADOMINI_STICHWORTE = {
    "freundlich": ("happy", "glad", "smile", "froh", "gluecklich", "lachen", "freu"),
    "traurig": ("sad", "traurig", "cry", "weep", "upset", "wein"),
    "ueberrascht": ("surprise", "shock", "ueberrascht", "wow", "gasp", "erschreck"),
}


def _zd_zustand_aus_dateiname(name):
    n = re.sub(r"[^a-z]", "", name.lower())
    for zustand, stichworte in _VEADOMINI_STICHWORTE.items():
        if any(w in n for w in stichworte):
            return "überrascht" if zustand == "ueberrascht" else zustand
    return None


def veadomini_importieren(rfile, laenge, name_roh):
    """Liest eine .veadomini-Datei (ab veadotube mini 1.4 eine umbenannte ZIP-Datei
    mit Bildern) und legt daraus ein neues 2D-Avatar-Set an. Bilder, deren Dateiname
    eine Stimmung erkennen lässt (z. B. "happy", "sad"), werden automatisch zugeordnet.
    Alles andere bleibt "nicht zugeordnet" und wird danach im Bearbeitungsbereich per
    Hand zugeordnet. Ältere .veadomini-Dateien (vor Version 1.4, kein ZIP) werden
    nicht unterstützt."""
    if laenge < 4 or laenge > MAX_ZWEID_PAKET:
        raise AvatarFehler("Datei zu klein oder zu groß (höchstens 60 MB).")
    puffer = io.BytesIO()
    rest = laenge
    while rest > 0:
        teil = rfile.read(min(1 << 20, rest))
        if not teil:
            break
        puffer.write(teil)
        rest -= len(teil)
    if rest:
        raise AvatarFehler("Beim Hochladen wurde die Verbindung unterbrochen.")
    puffer.seek(0)
    try:
        zf = zipfile.ZipFile(puffer)
        schlecht = zf.testzip()
    except zipfile.BadZipFile:
        raise AvatarFehler(
            "Das ist keine (neuere) .veadomini-Datei. Ab veadotube mini 1.4 ist das "
            "eine ZIP-Datei; ältere Versionen werden nicht unterstützt.")
    if schlecht:
        raise AvatarFehler("Die Datei ist beschädigt.")

    bilder = []
    for eintrag in zf.infolist():
        if eintrag.is_dir() or not (8 <= eintrag.file_size <= MAX_ZWEID_BILD):
            continue
        try:
            inhalt = zf.read(eintrag)
        except (zipfile.BadZipFile, OSError, ValueError):
            continue
        endung = _hg_bildtyp(inhalt[:16])
        if endung:
            bilder.append((os.path.basename(eintrag.filename), endung, inhalt))
    zf.close()
    if not bilder:
        raise AvatarFehler("In der Datei wurden keine Bilder gefunden.")

    stamm = re.sub(r"[^\w .\-]", "", os.path.splitext(os.path.basename(str(name_roh)))[0],
                   flags=re.UNICODE).strip()
    satz_id = zd_satz_erstellen(stamm or "Importiert")

    zugeordnet, unbekannte = {}, []
    for dateiname, endung, inhalt in bilder:
        zustand = _zd_zustand_aus_dateiname(dateiname)
        if zustand and zustand not in zugeordnet:
            zugeordnet[zustand] = (endung, inhalt)
        else:
            unbekannte.append((endung, inhalt))
    if "neutral" not in zugeordnet:
        quelle = unbekannte.pop(0) if unbekannte else next(iter(zugeordnet.values()), None)
        if quelle:
            zugeordnet["neutral"] = quelle
    for zustand, (endung, inhalt) in zugeordnet.items():
        _zd_bild_speichern(satz_id, zustand, endung, inhalt)
    return {"id": satz_id, "erkannt": sorted(zugeordnet.keys()),
            "nicht_zugeordnet": len(unbekannte)}


# ---------- Verteiler für die Oberfläche ----------
def info():
    st = _lade_status()
    lib = liste()
    return {"liste": lib, "aktiv": aktiver(st, lib), "wechselrecht": st["bot_darf_wechseln"],
            "import_pfad": IMPORT_DIR, "import_ordner": st["import_ordner"],
            "kandidaten": kandidaten(), "steckbrief": lade_steckbrief(),
            "animationen": anim_liste(),
            "hintergruende": hg_liste(), "hintergrund_aktiv": hg_aktiv_id(),
            "zweid_avatare": zd_liste(), "zweid_aktiv": zd_aktiv_id(),
            "zweid_zustaende": ZUSTAENDE,
            "live2d": live2d.liste(), "live2d_aktiv": live2d.aktiv_id(),
            "live2d_bereit": live2d.bibliotheken_vorhanden(),
            "live2d_status": live2d.bibliotheken_status()}


def behandle(pfad, daten):
    if pfad == "/api/avatar_waehlen":
        waehlen(daten.get("name", ""))
    elif pfad == "/api/avatar_loeschen":
        loeschen(daten.get("name", ""))
    elif pfad == "/api/avatar_beschreibung":
        beschreibung_setzen(daten.get("name", ""), daten.get("text", ""))
    elif pfad == "/api/avatar_wechselrecht":
        wechselrecht_setzen(daten.get("erlaubt", False))
    elif pfad == "/api/avatar_importordner":
        import_ordner_setzen(daten.get("pfad", ""))
    elif pfad == "/api/avatar_scan":
        pass
    elif pfad == "/api/avatar_importieren":
        importieren(daten.get("id", ""), bool(daten.get("anziehen")))
    elif pfad == "/api/avatar_ablehnen":
        ablehnen(daten.get("id", ""))
    elif pfad == "/api/animation_loeschen":
        anim_loeschen(daten.get("name", ""))
    elif pfad == "/api/hintergrund_waehlen":
        hg_waehlen(daten.get("id", ""))
    elif pfad == "/api/hintergrund_farbe":
        hg_farbe_hinzufuegen(daten.get("hex", ""), daten.get("name", ""))
    elif pfad == "/api/hintergrund_loeschen":
        hg_loeschen(daten.get("id", ""))
    elif pfad == "/api/2d_waehlen":
        zd_waehlen(daten.get("id", ""))
    elif pfad == "/api/2d_erstellen":
        zd_satz_erstellen(daten.get("name", ""))
    elif pfad == "/api/2d_umbenennen":
        zd_satz_umbenennen(daten.get("id", ""), daten.get("name", ""))
    elif pfad == "/api/2d_zustand_entfernen":
        zd_zustand_entfernen(daten.get("id", ""), daten.get("zustand", ""))
    elif pfad == "/api/2d_loeschen":
        zd_satz_loeschen(daten.get("id", ""))
    elif pfad == "/api/live2d_waehlen":
        live2d.waehlen(daten.get("id", ""))
        if daten.get("id"):
            waehlen("")
            zd_waehlen("")
    elif pfad == "/api/live2d_umbenennen":
        live2d.umbenennen(daten.get("id", ""), daten.get("name", ""))
    elif pfad == "/api/live2d_loeschen":
        live2d.loeschen(daten.get("id", ""))
    elif pfad == "/api/steckbrief":
        sb = steckbrief_erstellen(daten.get("quelle", "lokal"), daten.get("wunsch", ""))
        return {"steckbrief": sb, "avatare": info()}
    else:
        raise AvatarFehler("Unbekannte Anfrage.")
    return {"avatare": info()}
