"""Live2D-Avatare (.moc3) über pixi-live2d-display im Browser.

Feste Regeln:
- Ein hochgeladenes Modellpaket ist eine ZIP-Datei mit genau einer *.model3.json
  und den Dateien, auf die sie verweist (Texturen, ggf. Motions/Expressions/Physics).
- Beim Entpacken wird jeder Dateipfad in der ZIP geprüft, damit kein Eintrag (z. B.
  mit "../" im Namen) außerhalb des Zielordners landet (Zip-Slip-Schutz).
- Die eigentliche Rendering-Bibliothek (Cubism Core, von Live2D selbst bereitgestellt,
  nicht frei weiterverteilbar) wird separat im Setup geladen oder von Hand nachgelegt;
  dieses Modul verwaltet nur die Modell-Dateien und meldet, ob die Bibliotheken da sind.
"""
import io
import json
import os
import re
import secrets
import zipfile

import bot

MODELL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "live2d")
MODELL_DATEI = os.path.join(bot.DATEN, "live2d.json")
LIB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "lib")
MAX_PAKET = 150 * 1024 * 1024    # 150 MB (Texturen können groß sein)
MAX_EINZELDATEI = 40 * 1024 * 1024
MAX_MODELLE = 15
ID_RE = re.compile(r"^[0-9a-f]{12}$")


class Live2DFehler(Exception):
    """Fehler, der dem Nutzer verständlich angezeigt wird."""


NOETIGE_BIBLIOTHEKEN = ("live2dcubismcore.min.js", "pixi.min.js",
                        "pixi-live2d-display-cubism4.min.js")


def bibliotheken_status():
    """Für jede nötige Datei: "fehlt", "verdaechtig" (zu klein oder sieht nach einer
    gespeicherten HTML-Seite statt dem echten Skript aus) oder "ok"."""
    ergebnis = {}
    for name in NOETIGE_BIBLIOTHEKEN:
        pfad = os.path.join(LIB_DIR, name)
        if not os.path.isfile(pfad):
            ergebnis[name] = "fehlt"
            continue
        try:
            groesse = os.path.getsize(pfad)
            with open(pfad, "rb") as f:
                anfang = f.read(200).lstrip().lower()
        except OSError:
            ergebnis[name] = "fehlt"
            continue
        if groesse < 2000 or anfang.startswith(b"<!doctype") or anfang.startswith(b"<html"):
            ergebnis[name] = "verdaechtig"
        else:
            ergebnis[name] = "ok"
    return ergebnis


def bibliotheken_vorhanden():
    return all(v == "ok" for v in bibliotheken_status().values())


# ---------- Verwaltung ----------
def _lade():
    try:
        with open(MODELL_DATEI, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    if not isinstance(d, dict):
        d = {}
    modelle = d.get("modelle")
    modelle = modelle if isinstance(modelle, list) else []
    bereinigt = []
    for m in modelle:
        if isinstance(m, dict) and ID_RE.match(str(m.get("id", ""))) and m.get("haupt_datei"):
            m["name"] = str(m.get("name", ""))[:40] or "Modell"
            bereinigt.append(m)
    aktiv = d.get("aktiv")
    return {"modelle": bereinigt, "aktiv": aktiv if isinstance(aktiv, str) else ""}


def _speichere(d):
    os.makedirs(os.path.dirname(MODELL_DATEI), exist_ok=True)
    tmp = MODELL_DATEI + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, MODELL_DATEI)


def _finden(d, modell_id):
    for m in d["modelle"]:
        if m["id"] == modell_id:
            return m
    return None


def liste():
    d = _lade()
    return [{"id": m["id"], "name": m["name"],
            "url": f"/live2d/{m['id']}/{m['haupt_datei']}"} for m in d["modelle"]]


def aktiv_id():
    d = _lade()
    if d["aktiv"] and _finden(d, d["aktiv"]):
        return d["aktiv"]
    return ""


def waehlen(modell_id):
    modell_id = str(modell_id or "")
    d = _lade()
    if modell_id and not _finden(d, modell_id):
        raise Live2DFehler("Dieses Live2D-Modell gibt es nicht.")
    d["aktiv"] = modell_id
    _speichere(d)


def umbenennen(modell_id, name):
    name = " ".join(str(name or "").split())[:40]
    if not name:
        raise Live2DFehler("Bitte einen Namen angeben.")
    d = _lade()
    m = _finden(d, modell_id)
    if not m:
        raise Live2DFehler("Dieses Live2D-Modell gibt es nicht.")
    m["name"] = name
    _speichere(d)


def loeschen(modell_id):
    d = _lade()
    m = _finden(d, modell_id)
    if not m:
        raise Live2DFehler("Dieses Live2D-Modell gibt es nicht.")
    d["modelle"] = [x for x in d["modelle"] if x["id"] != modell_id]
    if d["aktiv"] == modell_id:
        d["aktiv"] = ""
    _speichere(d)
    ordner = os.path.join(MODELL_DIR, modell_id)
    if os.path.commonpath([os.path.realpath(ordner), os.path.realpath(MODELL_DIR)]) == os.path.realpath(MODELL_DIR):
        import shutil
        shutil.rmtree(ordner, ignore_errors=True)


# ---------- Import (ZIP mit .model3.json + Texturen usw.) ----------
def _sicherer_zielpfad(ordner, name_in_zip):
    """Löst den Zielpfad auf und stellt sicher, dass er innerhalb von 'ordner' bleibt
    (Schutz gegen Zip-Slip, also Einträge wie "../../etc/passwd" in der ZIP)."""
    bereinigt = name_in_zip.replace("\\", "/")
    teile = [t for t in bereinigt.split("/") if t not in ("", ".", "..")]
    if not teile:
        return None
    ziel = os.path.realpath(os.path.join(ordner, *teile))
    basis = os.path.realpath(ordner)
    if ziel != basis and not ziel.startswith(basis + os.sep):
        return None
    return ziel


def importieren(rfile, laenge, name_roh):
    if laenge < 4 or laenge > MAX_PAKET:
        raise Live2DFehler("Datei zu klein oder zu groß (höchstens 150 MB).")
    rest = laenge
    daten = bytearray()
    while rest > 0:
        teil = rfile.read(min(1 << 20, rest))
        if not teil:
            break
        daten += teil
        rest -= len(teil)
    if rest:
        raise Live2DFehler("Beim Hochladen wurde die Verbindung unterbrochen.")
    try:
        zf = zipfile.ZipFile(io.BytesIO(bytes(daten)))
        schlecht = zf.testzip()
    except zipfile.BadZipFile:
        raise Live2DFehler("Das ist keine gültige ZIP-Datei.")
    if schlecht:
        raise Live2DFehler("Die Datei ist beschädigt.")

    manifeste = [e for e in zf.infolist()
                if not e.is_dir() and e.filename.lower().endswith(".model3.json")]
    if not manifeste:
        zf.close()
        raise Live2DFehler("In der ZIP-Datei wurde keine *.model3.json gefunden.")
    if len(manifeste) > 1:
        zf.close()
        raise Live2DFehler("Die ZIP-Datei enthält mehrere *.model3.json-Dateien "
                           "(mehrere Modelle). Bitte nur ein Modell pro ZIP hochladen.")
    manifest_eintrag = manifeste[0]

    d = _lade()
    if len(d["modelle"]) >= MAX_MODELLE:
        zf.close()
        raise Live2DFehler("Es sind schon genug Live2D-Modelle gespeichert.")

    for e in zf.infolist():
        if not e.is_dir() and e.file_size > MAX_EINZELDATEI:
            zf.close()
            raise Live2DFehler(f"Datei '{e.filename}' ist zu groß (höchstens 40 MB je Datei).")

    modell_id = secrets.token_hex(6)
    ziel_ordner = os.path.join(MODELL_DIR, modell_id)
    os.makedirs(ziel_ordner, exist_ok=True)
    geschrieben = []
    try:
        for e in zf.infolist():
            if e.is_dir():
                continue
            ziel = _sicherer_zielpfad(ziel_ordner, e.filename)
            if ziel is None:
                continue   # Eintrag versucht, den Zielordner zu verlassen: überspringen
            os.makedirs(os.path.dirname(ziel), exist_ok=True)
            with zf.open(e) as quelle, open(ziel, "wb") as f:
                f.write(quelle.read())
            geschrieben.append(ziel)
        zf.close()

        haupt_datei = _sicherer_zielpfad(ziel_ordner, manifest_eintrag.filename)
        if not haupt_datei or not os.path.isfile(haupt_datei):
            raise Live2DFehler("Die *.model3.json konnte nicht gespeichert werden.")
        rel_haupt = os.path.relpath(haupt_datei, ziel_ordner).replace(os.sep, "/")

        try:
            with open(haupt_datei, encoding="utf-8") as f:
                manifest = json.load(f)
        except (OSError, ValueError):
            raise Live2DFehler("Die *.model3.json ist kein gültiges JSON.")
        moc = ((manifest or {}).get("FileReferences") or {}).get("Moc") if isinstance(manifest, dict) else None
        # Moc ist relativ zum ORDNER der model3.json selbst angegeben (Cubism-Format),
        # nicht relativ zur ZIP-Wurzel - bei einem Modell in einem Unterordner (der
        # Normalfall) muss dieser Unterordner hier mit einbezogen werden.
        manifest_ordner = os.path.dirname(rel_haupt)
        moc_rel = (manifest_ordner + "/" + str(moc)) if manifest_ordner and moc else moc
        moc_pfad = _sicherer_zielpfad(ziel_ordner, moc_rel) if moc else None
        moc_korrigiert = False
        if not moc_pfad or not os.path.isfile(moc_pfad):
            # Der angegebene Pfad passt nicht (z. B. wegen einer ungewöhnlichen
            # ZIP-Struktur oder abweichender Schreibweise) - stattdessen im
            # entpackten Ordner selbst nach einer .moc3-Datei suchen und sie
            # verwenden, wenn sie eindeutig ist.
            gefundene = [p for p in geschrieben if p.lower().endswith(".moc3")]
            if len(gefundene) == 1:
                moc_pfad = gefundene[0]
                moc_korrigiert = True
            elif len(gefundene) > 1:
                raise Live2DFehler("Die *.model3.json verweist auf keine vorhandene "
                                   ".moc3-Datei, und in der ZIP liegen mehrere "
                                   ".moc3-Dateien - nicht eindeutig, welche gemeint ist.")
            else:
                raise Live2DFehler("In der ZIP-Datei wurde keine .moc3-Datei gefunden.")

        if moc_korrigiert:
            # Die model3.json wird tatsächlich auf der Platte korrigiert, denn der
            # Browser lädt sie später direkt per HTTP und würde sonst weiterhin
            # den falschen (nicht vorhandenen) Pfad zu lesen bekommen.
            if not isinstance(manifest, dict):
                manifest = {}
            manifest.setdefault("FileReferences", {})["Moc"] = os.path.relpath(
                moc_pfad, os.path.dirname(haupt_datei)).replace(os.sep, "/")
            with open(haupt_datei, "w", encoding="utf-8") as f:
                json.dump(manifest, f, ensure_ascii=False, indent=1)

        stamm = re.sub(r"[^\w .\-]", "", os.path.splitext(os.path.basename(str(name_roh)))[0],
                       flags=re.UNICODE).strip()
        d = _lade()
        d["modelle"].append({"id": modell_id, "name": stamm or "Live2D-Modell",
                             "haupt_datei": rel_haupt})
        _speichere(d)
    except Live2DFehler:
        import shutil
        shutil.rmtree(ziel_ordner, ignore_errors=True)
        raise
    return modell_id
