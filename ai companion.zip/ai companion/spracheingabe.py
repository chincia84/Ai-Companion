"""Lokale Spracherkennung (Speech-to-Text) über faster-whisper.

Läuft - genau wie Piper für die Sprachausgabe - direkt in der Projekt-venv.
Das Modell wird beim allerersten Gebrauch einmalig heruntergeladen (siehe
Setup-Skript), falls das nicht schon beim Einrichten geklappt hat.
"""
import os
import sys
import threading

BASIS = os.path.dirname(os.path.abspath(__file__))
MODELL_ORDNER = os.path.join(BASIS, "stt-modell")
MODELL_GROESSE = os.environ.get("KI_STT_MODELL", "small")
MAX_STT_AUDIO = 25 * 1024 * 1024   # 25 MB - reicht für mehrere Minuten Sprache

_modell = None
_modell_lock = threading.Lock()


class SttFehler(Exception):
    """Fehler, der dem Nutzer verständlich angezeigt wird."""


def _hole_modell():
    global _modell
    with _modell_lock:
        if _modell is not None:
            return _modell
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            raise SttFehler("Spracherkennung ist nicht installiert.")
        geraet, rechentyp = "cpu", "int8"
        try:
            import ctranslate2
            if ctranslate2.get_cuda_device_count() > 0:
                geraet, rechentyp = "cuda", "float16"
        except Exception:
            pass   # keine GPU erkannt oder ctranslate2 ohne CUDA - läuft auch auf der CPU
        try:
            _modell = WhisperModel(MODELL_GROESSE, device=geraet, compute_type=rechentyp,
                                    download_root=MODELL_ORDNER)
        except Exception as e:
            print("Spracherkennung: Modell konnte nicht geladen werden:", e, file=sys.stderr)
            raise SttFehler("Das Spracherkennungs-Modell konnte nicht geladen werden "
                             "(evtl. kein Internet beim ersten Herunterladen).")
        return _modell


def transkribieren(rfile, laenge, sprache="de"):
    """Nimmt rohe Audiodaten entgegen (ein beliebiges, von ffmpeg/PyAV lesbares
    Format, z. B. WebM/Opus aus dem Browser-Mikrofon) und gibt den erkannten
    Text zurück. Wirft SttFehler, wenn nichts Brauchbares erkannt wurde."""
    if laenge < 200 or laenge > MAX_STT_AUDIO:
        raise SttFehler("Aufnahme zu kurz oder zu groß.")
    rest, puffer = laenge, bytearray()
    while rest > 0:
        teil = rfile.read(min(1 << 20, rest))
        if not teil:
            break
        puffer += teil
        rest -= len(teil)
    if rest:
        raise SttFehler("Beim Hochladen wurde die Verbindung unterbrochen.")
    modell = _hole_modell()
    try:
        import io
        segmente, _info = modell.transcribe(io.BytesIO(bytes(puffer)), language=sprache,
                                             vad_filter=True, beam_size=1)
        text = " ".join(s.text.strip() for s in segmente).strip()
    except SttFehler:
        raise
    except Exception as e:
        print("Spracherkennung fehlgeschlagen:", e, file=sys.stderr)
        raise SttFehler("Die Aufnahme konnte nicht verarbeitet werden.")
    if not text:
        raise SttFehler("Es wurde keine Sprache erkannt.")
    return text
