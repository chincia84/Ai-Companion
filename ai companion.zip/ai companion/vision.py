"""Lokale Bildanalyse über ein Vision-Modell in Ollama (z. B. moondream, llava).

Feste Regeln:
- Bilder werden nur im Arbeitsspeicher verarbeitet, nie auf die Platte
  geschrieben. Bildschirmausschnitte können sensible Inhalte zeigen.
- Die Beschreibung, die das Vision-Modell liefert, ist externer, nicht
  vertrauenswürdiger Text. Der Aufrufer (server.py) schickt sie durch
  sicherheit.extern_verarbeiten(), bevor sie den Bot erreicht.
"""
import json
import re
import urllib.error
import urllib.request

import bot

STANDARD_MODELL = "moondream"
ZEITLIMIT = 120


class VisionFehler(Exception):
    """Fehler, der dem Nutzer verständlich angezeigt wird."""


def aktuelles_modell():
    m = str(bot.lade_persona().get("vision_modell", STANDARD_MODELL))
    return m if re.fullmatch(r"[a-z0-9][a-z0-9.:_\-]{2,60}", m) else STANDARD_MODELL


def modell_setzen(modell):
    modell = str(modell or "").strip()
    if not re.fullmatch(r"[a-z0-9][a-z0-9.:_\-]{2,60}", modell):
        raise VisionFehler("Ungültiger Modellname.")
    bot.setze_persona_feld("vision_modell", modell)


def _tags_url():
    return bot.OLLAMA_URL.rsplit("/", 2)[0] + "/api/tags" if "/api/" in bot.OLLAMA_URL \
        else "http://localhost:11434/api/tags"


def verfuegbar():
    """Prüft über Ollamas eigene Liste, ob das gewählte Modell installiert ist."""
    try:
        with urllib.request.urlopen(_tags_url(), timeout=5) as r:
            daten = json.loads(r.read())
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return False
    if not isinstance(daten, dict):
        return False
    namen = {str(m.get("name", "")).split(":")[0] for m in daten.get("models", [])
             if isinstance(m, dict)}
    return aktuelles_modell().split(":")[0] in namen


def status():
    return {"modell": aktuelles_modell(), "verfuegbar": verfuegbar()}


def bild_analysieren(bild_base64: str, frage: str) -> str:
    frage = " ".join(str(frage or "Beschreibe kurz, was auf dem Bild zu sehen ist.").split())[:400]
    modell = aktuelles_modell()
    daten = json.dumps({
        "model": modell,
        "messages": [{"role": "user", "content": frage, "images": [bild_base64]}],
        "stream": False,
        "options": {"temperature": 0.4},
    }).encode("utf-8")
    req = urllib.request.Request(bot.OLLAMA_URL, data=daten,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=ZEITLIMIT) as r:
            antwort = json.loads(r.read())
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise VisionFehler(f"Das lokale Vision-Modell ist nicht erreichbar ({e}). "
                           f"Ist es geladen (ollama pull {modell})? Läuft Ollama?")
    except ValueError:
        raise VisionFehler("Das lokale Vision-Modell hat keine gültige Antwort geliefert.")
    text = ((antwort or {}).get("message") or {}).get("content", "") if isinstance(antwort, dict) else ""
    if not text:
        raise VisionFehler(f"Das Modell '{modell}' hat nicht geantwortet. Ist es ein "
                           "Vision-Modell und mit 'ollama pull' geladen?")
    return text
