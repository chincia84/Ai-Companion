"""Feste Sicherheitsregeln für den Umgang mit fremdem Code.

Regel 1: Diese Anwendung verändert ihren eigenen Programmcode nie.
Regel 2: Code, der von außen kommt (andere KIs, Chatdienste, Dateien), wird
         nur in eingang/ abgelegt. Er wird nie ausgeführt, nie importiert und
         nie an den eigenen Code angehängt. Der Nutzer prüft ihn selbst.
Regel 3: Beim Start und bei jeder Statusabfrage wird geprüft, ob der Code von
         den Prüfsummen des Setups abweicht (auch neue, unbekannte Codedateien).

Künftige Verbindungen (Discord, andere Bots ...) müssen jede fremde Nachricht
zuerst durch extern_verarbeiten() schicken und nur den zurückgegebenen,
bereinigten Text an das Sprachmodell weitergeben.
"""
import hashlib
import json
import os
import re
import secrets
import threading
import time

BASIS = os.path.dirname(os.path.abspath(__file__))
EINGANG = os.path.join(BASIS, "eingang")
PRUEFSUMMEN = os.path.join(BASIS, ".code-pruefsummen")
MAX_BYTES = 1024 * 1024        # pro gespeichertem Eintrag
MAX_EINTRAEGE = 500            # danach wird nichts Neues mehr gespeichert
MAX_ANZEIGE = 200 * 1024
AUSSCHLUSS = {"venv", "stimmen", "avatar", "import", "animationen", "hintergruende", "avatare2d", "live2d", "daten", "eingang", ".git", "stt-modell", "profile"}
CODE_ENDUNGEN = {".py", ".pyc", ".sh", ".js", ".mjs", ".html", ".css"}

_ID = re.compile(r"^\d{8}-\d{6}-[0-9a-f]{6}$")
_BLOCK = re.compile(r"```([^\n`]*)\n(.*?)```", re.S)
_BEFEHL = re.compile(
    r"(?i)(\b(curl|wget)\b[^\n|]*\|\s*(sudo\s+)?(ba|z)?sh\b"
    r"|\bsudo\s+\S+|\brm\s+-[a-z]*r[a-z]*\b|\bchmod\s+\+x\b"
    r"|\bpip3?\s+install\b|\bpython3?\s+-c\b|\beval\s*\(|\bexec\s*\("
    r"|\bos\.system\s*\(|\bsubprocess\.)"
)
_lock = threading.Lock()
_cache = {"t": 0.0, "wert": []}


# ---------- Eingang (Quarantäne für fremden Code) ----------
def _kurz(text, n):
    return re.sub(r"[^\w .@#+:/-]", "", str(text)).strip()[:n]


def _alle_meta():
    if not os.path.isdir(EINGANG):
        return []
    ergebnis = []
    for name in os.listdir(EINGANG):
        if name.endswith(".json") and _ID.match(name[:-5]):
            try:
                with open(os.path.join(EINGANG, name), encoding="utf-8") as f:
                    meta = json.load(f)
                meta["pfad"] = os.path.join(EINGANG, meta["id"] + ".txt")
                ergebnis.append(meta)
            except (OSError, ValueError, KeyError):
                pass
    return sorted(ergebnis, key=lambda m: m["id"], reverse=True)


def _speichern(quelle, art, sprache, inhalt):
    """Legt fremden Inhalt als reine Textdatei ab. Gibt die ID zurück (oder None)."""
    daten = inhalt.encode("utf-8", "replace")
    abgeschnitten = len(daten) > MAX_BYTES
    daten = daten[:MAX_BYTES]
    pruefsumme = hashlib.sha256(daten).hexdigest()
    os.makedirs(EINGANG, mode=0o700, exist_ok=True)
    with _lock:
        vorhanden = _alle_meta()
        for m in vorhanden:                       # gleicher Inhalt: nicht doppelt speichern
            if m.get("sha256") == pruefsumme:
                return m["id"]
        if len(vorhanden) >= MAX_EINTRAEGE:
            return None
        for _ in range(5):
            eid = time.strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
            try:                                  # 0o600: nicht ausführbar
                fd = os.open(os.path.join(EINGANG, eid + ".txt"),
                             os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                break
            except FileExistsError:
                continue
        else:
            return None
        with os.fdopen(fd, "wb") as f:
            f.write(daten)
        meta = {"id": eid, "quelle": quelle, "art": art, "sprache": sprache,
                "zeit": time.strftime("%Y-%m-%d %H:%M:%S"), "bytes": len(daten),
                "sha256": pruefsumme, "abgeschnitten": abgeschnitten,
                "gesehen": False}
        _meta_schreiben(meta)
    return eid


def _meta_schreiben(meta):
    pfad = os.path.join(EINGANG, meta["id"] + ".json")
    fd = os.open(pfad, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump({k: v for k, v in meta.items() if k != "pfad"}, f,
                  ensure_ascii=False, indent=1)


def extern_verarbeiten(quelle, text):
    """Nimmt eine Nachricht von außen entgegen.

    Code-Blöcke und Befehlszeilen wandern in eingang/ und werden im Text durch
    einen Hinweis ersetzt. Zurück kommt der bereinigte Text für das Sprachmodell.
    """
    quelle = _kurz(quelle, 80) or "unbekannt"
    text = str(text)
    gespeichert = []

    def hinweis(eid, was):
        if eid:
            return f"[{was} von extern zur Prüfung gespeichert ({eid}), nicht ausgeführt]"
        return f"[{was} von extern erkannt, Eingang voll, verworfen]"

    def block(m):
        eid = _speichern(quelle, "code", _kurz(m.group(1), 20), m.group(2))
        if eid:
            gespeichert.append(eid)
        return hinweis(eid, "Code")

    text = _BLOCK.sub(block, text)

    offen = text.find("```")                      # nicht geschlossener Codeblock
    if offen != -1:
        eid = _speichern(quelle, "code", "", text[offen + 3:])
        if eid:
            gespeichert.append(eid)
        text = text[:offen] + hinweis(eid, "Code")

    behalten, befehle = [], []
    for zeile in text.split("\n"):
        (befehle if _BEFEHL.search(zeile) else behalten).append(zeile)
    if befehle:
        eid = _speichern(quelle, "befehl", "", "\n".join(befehle))
        if eid:
            gespeichert.append(eid)
        behalten.append(hinweis(eid, "Befehlszeilen"))

    return {"text": "\n".join(behalten).strip(), "gespeichert": gespeichert,
            "code_erkannt": bool(gespeichert)}


def liste():
    with _lock:
        return _alle_meta()


def lesen(eid):
    """Liefert den Inhalt zur Ansicht und markiert den Eintrag als gesehen."""
    if not _ID.match(str(eid)):
        return None
    with _lock:
        try:
            with open(os.path.join(EINGANG, eid + ".json"), encoding="utf-8") as f:
                meta = json.load(f)
            with open(os.path.join(EINGANG, eid + ".txt"), "rb") as f:
                daten = f.read(MAX_ANZEIGE + 1)
        except (OSError, ValueError):
            return None
        meta["gesehen"] = True
        _meta_schreiben(meta)
    return {"meta": meta, "inhalt": daten[:MAX_ANZEIGE].decode("utf-8", "replace"),
            "gekuerzt": len(daten) > MAX_ANZEIGE,
            "pfad": os.path.join(EINGANG, eid + ".txt")}


def loeschen(eid):
    if not _ID.match(str(eid)):
        return False
    with _lock:
        for endung in (".txt", ".json"):
            try:
                os.remove(os.path.join(EINGANG, eid + endung))
            except OSError:
                pass
    return True


# ---------- Codeprüfung (Wächter) ----------
def _sha(pfad):
    h = hashlib.sha256()
    with open(pfad, "rb") as f:
        for teil in iter(lambda: f.read(1 << 20), b""):
            h.update(teil)
    return h.hexdigest()


def pruefe_code(max_alter=5):
    """Gibt eine Liste von Abweichungen zurück (leer = alles wie im Setup)."""
    jetzt = time.time()
    if max_alter and jetzt - _cache["t"] < max_alter:
        return _cache["wert"]
    abweichungen, bekannt = [], set()
    try:
        with open(PRUEFSUMMEN, encoding="utf-8") as f:
            zeilen = f.read().splitlines()
    except OSError:
        zeilen = None
        abweichungen.append("Prüfsummen-Datei fehlt")
    for zeile in zeilen or []:
        summe, _, rel = zeile.partition("  ")
        if not summe or not rel:
            continue
        bekannt.add(rel)
        try:
            if _sha(os.path.join(BASIS, rel)) != summe:
                abweichungen.append(f"{rel} (geändert)")
        except OSError:
            abweichungen.append(f"{rel} (fehlt)")
    if zeilen is not None:
        for wurzel, ordner, dateien in os.walk(BASIS):
            ordner[:] = [d for d in ordner if d not in AUSSCHLUSS]
            for name in dateien:
                pfad = os.path.join(wurzel, name)
                rel = os.path.relpath(pfad, BASIS)
                if rel in bekannt or rel == ".code-pruefsummen":
                    continue
                if (os.path.splitext(name)[1].lower() in CODE_ENDUNGEN
                        or os.access(pfad, os.X_OK)):
                    abweichungen.append(f"{rel} (neu)")
    _cache["t"], _cache["wert"] = jetzt, abweichungen
    return abweichungen
