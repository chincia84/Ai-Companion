#!/usr/bin/env bash
#   ./start.sh         Bot starten (Beenden: Fenster schließen oder Strg+C)
#   ./start.sh stop    laufenden Bot von einem anderen Terminal aus beenden
cd "$(dirname "$0")" || exit 1
export PATH="$HOME/.local/bin:$PATH"
export KI_MODELL="${KI_MODELL:-qwen2.5:7b}"
export PYTHONDONTWRITEBYTECODE=1
PORT="${KI_PORT:-8765}"
URL="http://127.0.0.1:$PORT"
LOG=/tmp/ki-server.log
PIDDATEI="${XDG_RUNTIME_DIR:-/tmp}/ki-chatbot-$(id -u).pids"

# Prüft, ob PID zu einem Prozess gehört, dessen Aufruf MUSTER enthält
gehoert_zu() { [ -n "$1" ] && [ "$1" != "-" ] && ps -p "$1" -o args= 2>/dev/null | grep -q "$2"; }

# Beendet einen Prozess freundlich, nach 3 Sekunden mit Gewalt
stoppe() {
  local pid="$1"
  [ -n "$pid" ] || return 0
  kill "$pid" 2>/dev/null || return 0
  for _ in $(seq 1 30); do kill -0 "$pid" 2>/dev/null || return 0; sleep 0.1; done
  kill -9 "$pid" 2>/dev/null
}

# ---- ./start.sh stop ----
if [ "${1:-}" = "stop" ]; then
  if [ ! -f "$PIDDATEI" ]; then echo "Es läuft kein Bot."; exit 0; fi
  read -r HAUPT SRV OLL < "$PIDDATEI"
  if gehoert_zu "$HAUPT" "start.sh"; then
    kill "$HAUPT" 2>/dev/null                    # das Startskript räumt selbst auf
    for _ in $(seq 1 50); do kill -0 "$HAUPT" 2>/dev/null || break; sleep 0.1; done
  fi
  # Reste aufräumen, falls das Startskript abgestürzt war
  if gehoert_zu "$SRV" "server.py"; then stoppe "$SRV"; fi
  if gehoert_zu "$OLL" "ollama"; then stoppe "$OLL"; fi
  rm -f "$PIDDATEI"
  echo "Bot beendet."
  exit 0
fi

if [ -x venv/bin/python ]; then PY=venv/bin/python; else PY=python3; fi
SERVER_PID=""; OLLAMA_PID=""; BROWSER_PID=""; PID_GESCHRIEBEN=""; AUFGERAEUMT=""

aufraeumen() {
  [ -z "$AUFGERAEUMT" ] || return 0
  AUFGERAEUMT=1
  trap '' INT TERM HUP                    # zweites Strg+C beim Aufräumen ignorieren
  echo
  echo "Beende den Bot ..."
  stoppe "$BROWSER_PID"
  stoppe "$SERVER_PID"
  if [ -n "$OLLAMA_PID" ]; then
    stoppe "$OLLAMA_PID"                  # nur Ollama, das wir selbst gestartet haben
  elif [ -n "$SERVER_PID" ]; then
    # Ollama läuft anderweitig weiter: nur das Modell aus dem Grafikspeicher nehmen
    curl -s --max-time 2 http://localhost:11434/api/generate \
      -d "{\"model\":\"$KI_MODELL\",\"keep_alive\":0}" > /dev/null 2>&1
  fi
  [ -z "$PID_GESCHRIEBEN" ] || rm -f "$PIDDATEI"
}
trap aufraeumen EXIT
trap 'exit 130' INT
trap 'exit 143' TERM HUP

# ---- Ollama ----
if ! curl -s http://localhost:11434/ > /dev/null 2>&1; then
  if command -v ollama > /dev/null; then
    ollama serve > /tmp/ollama.log 2>&1 &
    OLLAMA_PID=$!
    for _ in $(seq 1 30); do
      curl -s http://localhost:11434/ > /dev/null 2>&1 && break
      sleep 0.5
    done
  else
    echo "Hinweis: ollama nicht gefunden."
  fi
fi

# ---- Chat-Server ----
if curl -s --max-time 1 "$URL" > /dev/null 2>&1; then
  echo "Der Bot-Server läuft schon auf $URL (beenden mit: ./start.sh stop)."
else
  $PY -B server.py > "$LOG" 2>&1 &
  SERVER_PID=$!
  for _ in $(seq 1 40); do
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then
      echo "Server konnte nicht starten. Fehlermeldung:"
      cat "$LOG"
      exit 1
    fi
    curl -s "$URL" > /dev/null 2>&1 && break
    sleep 0.25
  done
  echo "Server läuft: $URL"
fi

if [ -n "$SERVER_PID" ] || [ -n "$OLLAMA_PID" ]; then
  echo "${$} ${SERVER_PID:--} ${OLLAMA_PID:--}" > "$PIDDATEI" && PID_GESCHRIEBEN=1
fi
echo "Beenden: Fenster schließen oder Strg+C."

# ---- Fenster öffnen (App-Modus ohne Adressleiste, sonst normaler Browser) ----
AUDIO="--autoplay-policy=no-user-gesture-required"
START=$(date +%s)
if command -v chromium > /dev/null; then
  chromium --app="$URL" $AUDIO --user-data-dir="$HOME/.cache/ki-chatbot-profil" &
  BROWSER_PID=$!
elif command -v google-chrome > /dev/null; then
  google-chrome --app="$URL" $AUDIO --user-data-dir="$HOME/.cache/ki-chatbot-profil" &
  BROWSER_PID=$!
elif flatpak info org.chromium.Chromium > /dev/null 2>&1; then
  flatpak run org.chromium.Chromium --app="$URL" $AUDIO &
  BROWSER_PID=$!
elif flatpak info com.google.Chrome > /dev/null 2>&1; then
  flatpak run com.google.Chrome --app="$URL" $AUDIO &
  BROWSER_PID=$!
else
  xdg-open "$URL"
fi

# Warten, bis das Fenster geschlossen wird (Strg+C unterbricht das sofort)
[ -z "$BROWSER_PID" ] || wait "$BROWSER_PID"

# Kehrt der Browser sofort zurück (z. B. weil er schon lief), läuft der Server
# weiter, bis du Strg+C drückst.
if [ $(( $(date +%s) - START )) -lt 5 ] && [ -n "$SERVER_PID" ]; then
  echo "Der Server bleibt aktiv. Zum Beenden Strg+C drücken (oder ./start.sh stop)."
  wait "$SERVER_PID"
fi
