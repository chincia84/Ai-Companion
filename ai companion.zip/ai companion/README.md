# KI-Chatbot

Ein lokaler KI-Begleiter mit eigener Persönlichkeit, Gedächtnis, Sprachein-/
-ausgabe und 3D-/2D-Avatar. Läuft komplett auf deinem eigenen Rechner (lokales
Sprachmodell über [Ollama](https://ollama.com)); Cloud-Anteile (Claude-API,
ElevenLabs, Brave Search, Discord) sind optional und jeweils einzeln
zuschaltbar.

> Oberfläche und Prompts sind auf Deutsch. Für andere Sprachen müsste
> `bot.py`/`static/index.html` angepasst werden.

## Funktionen

- **Persona & Gedächtnis**: Name, Charakter, Sprechstil frei einstellbar;
  der Bot merkt sich dauerhafte Fakten über dich (`daten/fakten.json`).
- **Begleiter-Modus**: wärmerer Ton, fragt nach, wie es dir geht, merkt sich
  die letzte Stimmung und meldet sich nach einer einstellbaren Weile Stille
  von selbst.
- **Sprache**: lokale Sprachausgabe (Piper, deutsche Stimmen) und
  Spracheingabe per Mikrofon (faster-whisper, inkl. Dauerzuhören- und
  Weckwort-Modus); optional ElevenLabs als Cloud-Stimme.
- **Avatar**: 3D (VRM, mit Mimik/Lippenbewegung/Blinzeln/Gesten), Live2D
  (.moc3) oder einfache 2D-Bildsets je Stimmung - inkl. Garderobe (mehrere
  Modelle, der Bot kann wechseln) und Import aus VRoid Studio.
- **Erinnerungen/Timer**: "Erinnere mich in 20 Minuten an ..." - der Bot
  meldet sich von selbst, wenn es fällig ist.
- **Discord-Anbindung** (optional): eigener Bot-Account, reagiert auf
  Nachrichten in den Kanälen/DMs, in die er eingeladen wird - mit eigenem,
  vom lokalen Chat getrenntem Gedächtnis.
- **Gespräch mit Claude** (optional, braucht einen API-Schlüssel): der Bot
  kann sich mit Claude über die Anthropic-API unterhalten.
- **Websuche** (optional): DuckDuckGo ohne eigenen Zugang, oder SearXNG/Brave
  mit eigenem Schlüssel.
- **Sicherheit**: fremder Code/Dateien landen nur in einer Quarantäne
  (`eingang/`) und werden nie ausgeführt; der eigene Programmcode wird nach
  der Installation schreibgeschützt und per Prüfsummen überwacht.
- **Sicherung/Export**: Gedächtnis, Persönlichkeit und Auswahl-Einstellungen
  lassen sich als Datei sichern und auf einem anderen Rechner wieder
  einspielen.
- **Profile**: mehrere komplett getrennte Charaktere (eigenes Gedächtnis,
  eigene Persönlichkeit, eigener Avatar) zum Wechseln.

## Voraussetzungen

- Linux (getestet unter Bazzite; andere Distributionen sollten funktionieren)
- Python 3
- [Ollama](https://ollama.com) (wird vom Installer bei Bedarf mit angeboten)
- Internetzugang beim ersten Einrichten (lädt Modell, Stimmen, 3D-Bibliotheken
  herunter) - danach läuft alles offline, bis auf die optionalen
  Cloud-Funktionen

## Installation

```bash
git clone <URL-dieses-Repos> ki-chatbot-repo
cd ki-chatbot-repo
./install.sh
```

Das Skript richtet den eigentlichen, laufenden Bot standardmäßig in
`~/ki-chatbot` ein (getrennt von diesem Repo-Ordner) und fragt dabei einmalig
nach einem Namen für den Bot.

Danach starten mit:

```bash
~/ki-chatbot/start.sh
```

Beenden: Fenster schließen, `Strg+C`, oder von einem anderen Terminal
`~/ki-chatbot/start.sh stop`. Es gibt außerdem einen Starter "KI-Chatbot" im
Anwendungsmenü.

### Aktualisieren

```bash
cd ki-chatbot-repo
git pull
./install.sh
```

Eigene Daten (Persönlichkeit, Gedächtnis, Stimmen, Avatare, API-Schlüssel)
bleiben dabei erhalten.

### Eigene Code-Änderungen

Der Programmcode in `~/ki-chatbot` ist nach der Installation schreibgeschützt
und mit Prüfsummen überwacht. Zum Bearbeiten:

```bash
~/ki-chatbot/code-freigeben.sh entsperren
# ... Dateien ändern ...
~/ki-chatbot/code-freigeben.sh
```

## Konfiguration

Alles über Umgebungsvariablen beim Aufruf von `install.sh` bzw. `start.sh`,
zum Beispiel:

| Variable | Bedeutung | Standard |
|---|---|---|
| `KI_ZIEL` | Projektordner der laufenden Installation | `~/ki-chatbot` |
| `KI_NAME` | Name des Bots (auch zum nachträglichen Ändern) | Zufallsname |
| `KI_MODELL` | Ollama-Modell | `qwen2.5:7b` |
| `KI_PORT` | lokaler Port der Oberfläche | `8765` |
| `KI_ZUSATZ_STIMMEN` | weitere Piper-Stimmen zur Auswahl | drei deutsche Stimmen |
| `ANTHROPIC_API_KEY` | für "Gespräch mit Claude" | - |

Weitere Schlüssel (ElevenLabs, Brave, Discord-Bot-Token) werden direkt in der
Oberfläche unter "Einstellungen" eingetragen und lokal mit eingeschränkten
Dateirechten gespeichert (`daten/*-key.txt`, nie an die Oberfläche
zurückgeschickt).

### Discord einrichten

1. Im [Discord Developer Portal](https://discord.com/developers/applications)
   eine Anwendung anlegen, darin einen Bot anlegen und dessen Token kopieren.
   Unter "Privileged Gateway Intents" **Message Content Intent** einschalten.
2. Über "OAuth2 → URL Generator" mit Scope `bot` und den Berechtigungen
   "Kanäle ansehen", "Nachrichten senden", "Nachrichtenverlauf anzeigen"
   einen Einladungslink erzeugen und den Bot auf deinen Server einladen.
3. In der Oberfläche unter "Einstellungen → Kommunikation" den Token eintragen
   und die Anbindung einschalten.

## Bekannte Einschränkungen

- Oberfläche und System-Prompts sind Deutsch-only.
- Das Standardmodell (`qwen2.5:7b`) ist klein und läuft lokal auf normaler
  Hardware - entsprechend nicht so zuverlässig wie ein großes Cloud-Modell;
  manche Anfragen (z. B. Uhrzeit/Datum) werden deshalb bewusst deterministisch
  im Code beantwortet statt dem Modell überlassen.
- Die Discord-Anbindung reagiert auf **jede** Nachricht in den Kanälen, in die
  sie eingeladen wird (nicht nur bei Erwähnung). Auf einem größeren/öffentlichen
  Server kann dadurch jede fremde Person das Discord-Gedächtnis des Bots
  befüllen (getrennt vom lokalen Gedächtnis, aber trotzdem erwähnenswert).
- Live2D Cubism Core ist proprietär und wird direkt von Live2D Inc. geladen
  (siehe Kommentar in `install.sh`), nicht Teil dieses Repos.

## Lizenz

[MIT](LICENSE) - mit Ausnahme der zur Laufzeit nachgeladenen Bibliotheken
(three.js, three-vrm, PixiJS, pixi-live2d-display, Live2D Cubism Core), die
jeweils ihrer eigenen Lizenz unterliegen und nicht Teil dieses Repos sind.

## Später erweitern

- Gehirn tauschen: `bot.py` → Funktion `antworte()`
- Avatar-Verhalten: `static/index.html` → `avatarReagiere()`, `avatarMund()`
