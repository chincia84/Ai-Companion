"""Websuche für den Bot, ohne eigenen API-Schlüssel (DuckDuckGo).

Feste Regeln:
- Es wird nur gesucht (Titel, kurzer Ausschnitt, Link). Es werden keine
  beliebigen Webseiten geladen oder Inhalte automatisch nachgeladen.
- Ergebnisse sind externer, nicht vertrauenswürdiger Text. Der Server schickt
  sie vor der Weitergabe an den Bot durch sicherheit.extern_verarbeiten(),
  damit darin enthaltener Code oder enthaltene Befehle im Eingang landen und
  nie ausgeführt werden.
- Wie viele Suchrunden pro Nachricht erlaubt sind, entscheidet server.py
  (MAX_SUCH_RUNDEN), nicht der Bot selbst.
"""
import html
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

import bot

MAX_TREFFER = 6
ZEITLIMIT = 8
BRAVE_KEY_DATEI = os.path.join(bot.DATEN, "brave-key.txt")
DIENSTE = ("duckduckgo", "searxng", "brave")


def _such_url():
    return os.environ.get("KI_SUCH_URL", "https://lite.duckduckgo.com/lite/")


class InternetFehler(Exception):
    """Fehler, der dem Nutzer/Bot verständlich angezeigt wird."""


def _dienst():
    d = str(bot.lade_persona().get("such_dienst", "duckduckgo"))
    return d if d in DIENSTE else "duckduckgo"


def _searxng_url():
    return str(bot.lade_persona().get("searxng_url", "")).strip()


def brave_key_status():
    return bool(_brave_key())


def _brave_key():
    try:
        with open(BRAVE_KEY_DATEI, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def brave_key_speichern(schluessel):
    schluessel = str(schluessel).strip()
    if not re.fullmatch(r"[A-Za-z0-9_\-]{10,200}", schluessel):
        raise InternetFehler("Das sieht nicht wie ein gültiger Brave-API-Schlüssel aus.")
    fd = os.open(BRAVE_KEY_DATEI, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(schluessel)
    os.chmod(BRAVE_KEY_DATEI, 0o600)


def brave_key_loeschen():
    try:
        os.remove(BRAVE_KEY_DATEI)
    except OSError:
        pass


def status():
    return {"dienst": _dienst(), "searxng_url": _searxng_url(),
            "brave_key_vorhanden": brave_key_status()}


def dienst_setzen(dienst, searxng_url=None):
    dienst = str(dienst or "")
    if dienst not in DIENSTE:
        raise InternetFehler("Unbekannter Suchdienst.")
    bot.setze_persona_feld("such_dienst", dienst)
    if searxng_url is not None:
        url = str(searxng_url).strip()
        if url and not re.match(r"^https?://", url):
            raise InternetFehler("Die SearXNG-Adresse muss mit http:// oder https:// beginnen.")
        bot.setze_persona_feld("searxng_url", url)


def bot_zusatz():
    return (
        'Wenn dir für eine aktuelle, dir unbekannte oder nachprüfbare Frage eine '
        'kurze Websuche helfen würde, füge deiner JSON-Antwort zusätzlich das Feld '
        '"suche" mit einer kurzen Suchanfrage (2 bis 6 Wörter) hinzu; "text" kann '
        "dabei kurz sagen, dass du nachsiehst. Du bekommst danach die Ergebnisse "
        'und antwortest normal weiter, ohne "suche" erneut zu setzen. Nutze das '
        "nur, wenn es wirklich nötig ist, nicht bei jeder Nachricht."
    )


def _ergebnisse_parsen(seite):
    ergebnisse = []
    links = re.findall(r'class="result-link"[^>]*href="([^"]*)"[^>]*>(.*?)</a>', seite, re.S)
    schnipsel = re.findall(r'class="result-snippet"[^>]*>(.*?)</td>', seite, re.S)
    for i, (roh_url, roh_titel) in enumerate(links):
        url = html.unescape(roh_url).strip()
        treffer = re.search(r"[?&]uddg=([^&]+)", url)
        if treffer:
            url = urllib.parse.unquote(treffer.group(1))
        elif url.startswith("//"):
            url = "https:" + url
        if not url.startswith(("http://", "https://")):
            continue
        titel = html.unescape(re.sub(r"<[^>]+>", "", roh_titel)).strip()
        text = html.unescape(re.sub(r"<[^>]+>", "", schnipsel[i])).strip() if i < len(schnipsel) else ""
        if titel:
            ergebnisse.append({"titel": titel[:200], "url": url[:500], "text": text[:400]})
    return ergebnisse


def _suche_duckduckgo(begriff):
    daten = urllib.parse.urlencode({"q": begriff}).encode()
    req = urllib.request.Request(_such_url(), data=daten, headers={
        "User-Agent": "Mozilla/5.0 (compatible; KI-Chatbot/1.0; lokal)",
        "Content-Type": "application/x-www-form-urlencoded",
    })
    try:
        with urllib.request.urlopen(req, timeout=ZEITLIMIT) as r:
            seite = r.read().decode("utf-8", "replace")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise InternetFehler(f"Suche fehlgeschlagen ({e}).")
    return _ergebnisse_parsen(seite)[:MAX_TREFFER]


def _eintrag(titel, url, text):
    url = str(url or "")
    if not url.startswith(("http://", "https://")):
        return None
    titel = str(titel or "").strip()[:200] or url[:200]
    return {"titel": titel, "url": url[:500], "text": str(text or "").strip()[:400]}


def _suche_searxng(begriff):
    basis = _searxng_url()
    if not basis:
        raise InternetFehler("Es ist noch keine SearXNG-Adresse eingetragen.")
    url = basis.rstrip("/") + "/search?" + urllib.parse.urlencode(
        {"q": begriff, "format": "json"})
    req = urllib.request.Request(url, headers={
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (compatible; KI-Chatbot/1.0; lokal)",
    })
    try:
        with urllib.request.urlopen(req, timeout=ZEITLIMIT) as r:
            daten = json.loads(r.read().decode("utf-8", "replace"))
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise InternetFehler(f"SearXNG-Suche fehlgeschlagen ({e}).")
    except ValueError:
        raise InternetFehler("SearXNG hat keine gültige Antwort geliefert "
                             "(JSON-Ausgabe dort evtl. nicht aktiviert).")
    ergebnisse = daten.get("results") if isinstance(daten, dict) else None
    if not isinstance(ergebnisse, list):
        raise InternetFehler("SearXNG hat keine gültige Antwort geliefert.")
    out = []
    for e in ergebnisse[:MAX_TREFFER]:
        if isinstance(e, dict):
            eintrag = _eintrag(e.get("title"), e.get("url"), e.get("content"))
            if eintrag:
                out.append(eintrag)
    return out


def _suche_brave(begriff):
    schluessel = _brave_key()
    if not schluessel:
        raise InternetFehler("Für Brave Search fehlt der API-Schlüssel.")
    url = "https://api.search.brave.com/res/v1/web/search?" + urllib.parse.urlencode(
        {"q": begriff, "count": MAX_TREFFER})
    req = urllib.request.Request(url, headers={
        "Accept": "application/json",
        "X-Subscription-Token": schluessel,
        "User-Agent": "Mozilla/5.0 (compatible; KI-Chatbot/1.0; lokal)",
    })
    try:
        with urllib.request.urlopen(req, timeout=ZEITLIMIT) as r:
            daten = json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise InternetFehler("Der Brave-API-Schlüssel wurde abgelehnt.")
        raise InternetFehler(f"Brave-Suche fehlgeschlagen (HTTP {e.code}).")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise InternetFehler(f"Brave-Suche fehlgeschlagen ({e}).")
    except ValueError:
        raise InternetFehler("Brave hat keine gültige Antwort geliefert.")
    ergebnisse = ((daten or {}).get("web") or {}).get("results") \
        if isinstance(daten, dict) else None
    if not isinstance(ergebnisse, list):
        return []
    out = []
    for e in ergebnisse[:MAX_TREFFER]:
        if isinstance(e, dict):
            eintrag = _eintrag(e.get("title"), e.get("url"), e.get("description"))
            if eintrag:
                out.append(eintrag)
    return out


def suche(begriff):
    begriff = " ".join(str(begriff or "").split())[:200]
    if not begriff:
        raise InternetFehler("Leere Suchanfrage.")
    dienst = _dienst()
    if dienst == "searxng":
        return _suche_searxng(begriff)
    if dienst == "brave":
        return _suche_brave(begriff)
    return _suche_duckduckgo(begriff)


def ergebnisse_als_text(begriff, treffer):
    if not treffer:
        return f"Suche nach \"{begriff}\" ergab keine Treffer."
    zeilen = [f"Suchergebnisse für \"{begriff}\":"]
    for i, t in enumerate(treffer, 1):
        zeilen.append(f"{i}. {t['titel']} ({t['url']}): {t['text']}")
    return "\n".join(zeilen)
