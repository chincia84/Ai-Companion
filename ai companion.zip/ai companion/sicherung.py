"""Sicherung (Export/Backup) des Bot-Zustands: Gedächtnis (Verlauf, Fakten,
Stimmungsnotiz), Erinnerungen, Persönlichkeit (persona.json) und alle
"aktiv"-Zeiger (welcher Avatar/Hintergrund/welches Live2D-Modell gerade
gewählt ist). Enthält bewusst NICHT die eigentlichen Bild-/Modell-Dateien
(die bleiben, wo sie sind) - nur die vergleichsweise kleinen Zustands-
Dateien, die zusammen "einen Charakter" ausmachen. Wird sowohl für den
manuellen Export/Import als auch von der Profilverwaltung genutzt.
"""
import io
import json
import os
import zipfile

import bot

MAX_BACKUP = 20 * 1024 * 1024   # 20 MB - reicht für die reinen Zustandsdateien

# Relative Pfade, die zusammen "einen Charakter" ausmachen.
DATEN_DATEIEN = [
    "verlauf.json", "fakten.json", "stimmung.json", "avatare.json",
    "steckbrief.json", "avatare2d.json", "hintergruende.json", "live2d.json",
    "erinnerungen.json",
]
SCHLUESSEL_DATEIEN = ["elevenlabs-key.txt", "brave-key.txt", "anthropic-key.txt", "discord-key.txt"]
ERLAUBTE_ZIEL_PFADE = ({"persona.json"} |
                        {"daten/" + n for n in DATEN_DATEIEN + SCHLUESSEL_DATEIEN})


class SicherungFehler(Exception):
    """Fehler, der dem Nutzer verständlich angezeigt wird."""


def _quellen(mit_schluesseln):
    """Gibt Paare (voller Pfad, Pfad im ZIP) zurück - nur für tatsächlich
    vorhandene Dateien."""
    ergebnis = []
    persona_pfad = os.path.join(bot.BASIS, "persona.json")
    if os.path.exists(persona_pfad):
        ergebnis.append((persona_pfad, "persona.json"))
    namen = list(DATEN_DATEIEN)
    if mit_schluesseln:
        namen += SCHLUESSEL_DATEIEN
    for name in namen:
        voll = os.path.join(bot.DATEN, name)
        if os.path.exists(voll):
            ergebnis.append((voll, "daten/" + name))
    return ergebnis


def erzeuge(mit_schluesseln=False):
    """Baut ein ZIP mit dem aktuellen Zustand und gibt die Rohdaten zurück."""
    puffer = io.BytesIO()
    with zipfile.ZipFile(puffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for voll, ziel in _quellen(mit_schluesseln):
            zf.write(voll, ziel)
        zf.writestr("sicherung-info.json",
                    json.dumps({"version": 1, "quelle": "ki-chatbot"}, ensure_ascii=False))
    return puffer.getvalue()


def einspielen(rfile, laenge):
    """Nimmt ein von erzeuge() erstelltes ZIP entgegen und ersetzt damit den
    aktuellen Zustand. Einträge außerhalb der bekannten Zustandsdateien werden
    ignoriert (auch das schützt zusätzlich vor Zip-Slip, da nur eine feste,
    kleine Liste exakter Zielpfade jemals geschrieben wird)."""
    if laenge < 20 or laenge > MAX_BACKUP:
        raise SicherungFehler("Datei zu klein oder zu groß (höchstens 20 MB).")
    rest, puffer = laenge, bytearray()
    while rest > 0:
        teil = rfile.read(min(1 << 20, rest))
        if not teil:
            break
        puffer += teil
        rest -= len(teil)
    if rest:
        raise SicherungFehler("Beim Hochladen wurde die Verbindung unterbrochen.")
    try:
        zf = zipfile.ZipFile(io.BytesIO(bytes(puffer)))
        if zf.testzip() is not None:
            raise SicherungFehler("Die Datei ist beschädigt.")
    except zipfile.BadZipFile:
        raise SicherungFehler("Das ist keine gültige Sicherungsdatei.")
    eingespielt = []
    with zf:
        for info in zf.infolist():
            name = info.filename.replace("\\", "/")
            if name not in ERLAUBTE_ZIEL_PFADE:
                continue
            ziel = os.path.join(bot.BASIS, name)
            os.makedirs(os.path.dirname(ziel), exist_ok=True)
            tmp = ziel + ".tmp"
            with zf.open(info) as quelle, open(tmp, "wb") as f:
                f.write(quelle.read())
            os.replace(tmp, ziel)
            eingespielt.append(name)
    if not eingespielt:
        raise SicherungFehler("Die Sicherungsdatei enthielt nichts Bekanntes.")
    return eingespielt
