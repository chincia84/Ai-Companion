"""Profilverwaltung: mehrere vollständige, unabhängige "Charaktere" anlegen
und umschalten - jeder mit eigenem Gedächtnis, eigener Persönlichkeit,
eigenem Avatar (VRM/2D/Live2D), eigener Stimmenauswahl und eigenem
Hintergrund.

Kernidee: die Daten des GERADE AKTIVEN Profils liegen ganz normal an ihrem
gewohnten Ort (persona.json, daten/*.json, avatar/, avatare2d/,
hintergruende/, live2d/) - so, wie der Bot es schon immer gemacht hat. Nur
die Daten der anderen, gerade NICHT aktiven Profile liegen weggepackt unter
profile/<id>/. Beim Umschalten werden beide Seiten vertauscht (verschoben,
nicht kopiert - schnell und ohne doppelten Platzbedarf).

Bewusst NICHT pro Profil, sondern weiterhin geteilt: API-Schlüssel
(ElevenLabs/Brave/Anthropic - Konto-Zugänge, keine Charaktereigenschaft),
installierte Piper-Stimmen und Gesten-Animationen (gemeinsamer Fundus, nur
die AUSWAHL daraus - in persona.json - ist pro Profil verschieden).
"""
import json
import os
import secrets
import shutil
import threading
import time

import bot
import sicherung

PROFIL_DIR = os.path.join(bot.BASIS, "profile")
PROFIL_DATEI = os.path.join(bot.DATEN, "profile.json")
MAX_PROFILE = 20

# Ordner, die komplett zu einem Charakter gehören und beim Umschalten
# mitwandern (anders als stimmen/, animationen/, import/: gemeinsamer Fundus).
ASSET_ORDNER = ["avatar", "avatare2d", "hintergruende", "live2d"]

_lock = threading.RLock()


class ProfilFehler(Exception):
    """Fehler, der dem Nutzer verständlich angezeigt wird."""


def _lade():
    try:
        with open(PROFIL_DATEI, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    if not isinstance(d, dict):
        d = {}
    if not isinstance(d.get("profile"), list):
        d["profile"] = []
    if not isinstance(d.get("aktiv"), str):
        d["aktiv"] = ""
    return d


def _speichere(d):
    os.makedirs(os.path.dirname(PROFIL_DATEI), exist_ok=True)
    tmp = PROFIL_DATEI + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, PROFIL_DATEI)


def _sicherstellen():
    """Legt beim allerersten Gebrauch ein Standardprofil an, das den schon
    vorhandenen Zustand repräsentiert - ohne irgendetwas zu verschieben."""
    with _lock:
        d = _lade()
        if d["profile"]:
            return d
        persona = bot.lade_persona()
        eid = "standard"
        d["profile"] = [{"id": eid, "name": persona.get("name") or "Standard",
                         "erstellt": time.time()}]
        d["aktiv"] = eid
        _speichere(d)
        return d


def liste():
    with _lock:
        d = _sicherstellen()
        return {"profile": d["profile"], "aktiv": d["aktiv"]}


def _profil_ordner(eid):
    return os.path.join(PROFIL_DIR, eid)


def _weglegen(eid):
    """Verschiebt den aktuellen (lebenden) Zustand nach profile/<eid>/."""
    ziel = _profil_ordner(eid)
    if os.path.exists(ziel):
        shutil.rmtree(ziel)
    os.makedirs(ziel, exist_ok=True)
    persona_pfad = os.path.join(bot.BASIS, "persona.json")
    if os.path.exists(persona_pfad):
        shutil.move(persona_pfad, os.path.join(ziel, "persona.json"))
    daten_ziel = os.path.join(ziel, "daten")
    for name in sicherung.DATEN_DATEIEN:
        quelle = os.path.join(bot.DATEN, name)
        if os.path.exists(quelle):
            os.makedirs(daten_ziel, exist_ok=True)
            shutil.move(quelle, os.path.join(daten_ziel, name))
    for ordner in ASSET_ORDNER:
        quelle = os.path.join(bot.BASIS, ordner)
        if os.path.isdir(quelle):
            shutil.move(quelle, os.path.join(ziel, ordner))


def _einziehen(eid):
    """Holt ein zuvor weggelegtes Profil zurück an seinen gewohnten Ort.
    Fehlt dort etwas (z. B. ein brandneues, noch leeres Profil), bleibt der
    jeweilige Ort einfach leer/fehlend - die übliche Lazy-Init jedes Moduls
    (lade_persona(), _lade_status() usw.) füllt das beim nächsten Zugriff
    automatisch wieder mit Standardwerten."""
    quelle = _profil_ordner(eid)
    persona_quelle = os.path.join(quelle, "persona.json")
    if os.path.exists(persona_quelle):
        shutil.move(persona_quelle, os.path.join(bot.BASIS, "persona.json"))
    daten_quelle = os.path.join(quelle, "daten")
    if os.path.isdir(daten_quelle):
        os.makedirs(bot.DATEN, exist_ok=True)
        for name in os.listdir(daten_quelle):
            shutil.move(os.path.join(daten_quelle, name), os.path.join(bot.DATEN, name))
    for ordner in ASSET_ORDNER:
        ordner_quelle = os.path.join(quelle, ordner)
        if os.path.isdir(ordner_quelle):
            shutil.move(ordner_quelle, os.path.join(bot.BASIS, ordner))
    if os.path.isdir(quelle):
        shutil.rmtree(quelle, ignore_errors=True)


def erstellen(name):
    name = " ".join(str(name or "").split())[:60] or "Neues Profil"
    with _lock:
        d = _sicherstellen()
        if len(d["profile"]) >= MAX_PROFILE:
            raise ProfilFehler("Es sind schon genug Profile angelegt.")
        eid = secrets.token_hex(6)
        d["profile"].append({"id": eid, "name": name, "erstellt": time.time()})
        _speichere(d)
        ordner = _profil_ordner(eid)
        os.makedirs(ordner, exist_ok=True)
        # Den gewählten Namen schon jetzt hinterlegen, damit der Charakter
        # beim ersten Wechsel dorthin sofort so heißt (alles andere bleibt
        # Standard, bis die Person es ändert).
        with open(os.path.join(ordner, "persona.json"), "w", encoding="utf-8") as f:
            json.dump({"name": name}, f, ensure_ascii=False)
        return eid


def umbenennen(eid, name):
    name = " ".join(str(name or "").split())[:60]
    if not name:
        raise ProfilFehler("Name darf nicht leer sein.")
    with _lock:
        d = _sicherstellen()
        eintrag = next((p for p in d["profile"] if p["id"] == eid), None)
        if not eintrag:
            raise ProfilFehler("Dieses Profil gibt es nicht.")
        eintrag["name"] = name
        _speichere(d)
        if eid == d["aktiv"]:
            bot.setze_persona_feld("name", name)


def wechseln(eid):
    eid = str(eid or "")
    with _lock:
        d = _sicherstellen()
        if eid == d["aktiv"]:
            return
        ziel = next((p for p in d["profile"] if p["id"] == eid), None)
        if not ziel:
            raise ProfilFehler("Dieses Profil gibt es nicht.")
        alt = d["aktiv"]
        _weglegen(alt)
        _einziehen(eid)
        d["aktiv"] = eid
        _speichere(d)


def loeschen(eid):
    eid = str(eid or "")
    with _lock:
        d = _sicherstellen()
        if eid == d["aktiv"]:
            raise ProfilFehler("Das aktive Profil kann nicht gelöscht werden "
                               "(zuerst zu einem anderen wechseln).")
        neu = [p for p in d["profile"] if p["id"] != eid]
        if len(neu) == len(d["profile"]):
            raise ProfilFehler("Dieses Profil gibt es nicht.")
        if not neu:
            raise ProfilFehler("Das letzte Profil kann nicht gelöscht werden.")
        d["profile"] = neu
        _speichere(d)
        ordner = _profil_ordner(eid)
        if os.path.isdir(ordner):
            shutil.rmtree(ordner, ignore_errors=True)
