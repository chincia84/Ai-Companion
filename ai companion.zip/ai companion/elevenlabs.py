"""Sprachausgabe über ElevenLabs (Cloud) als Alternative zur lokalen Stimme (Piper).

Feste Regeln:
- Nur der vorzulesende Text geht an ElevenLabs, nie Gedächtnis, Verlauf oder Fakten.
- Der API-Schlüssel liegt in daten/elevenlabs-key.txt (Rechte 600) und wird nie an
  die Oberfläche geschickt.
- Pro Anfrage werden höchstens MAX_ZEICHEN Zeichen gesendet (schont das Guthaben).
- Die Zieladresse ist fest (api.elevenlabs.io). KI_ELEVEN_URL gilt nur für lokale Tests.
"""
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

import bot

KEY_DATEI = os.path.join(bot.DATEN, "elevenlabs-key.txt")
MODELLE = ("eleven_multilingual_v2", "eleven_flash_v2_5", "eleven_turbo_v2_5")
STANDARD_MODELL = MODELLE[0]
MAX_ZEICHEN = 800
ZEITLIMIT = 30
VOICE_RE = re.compile(r"^[A-Za-z0-9]{10,40}$")


class ElevenFehler(Exception):
    """Fehler, der dem Nutzer verständlich angezeigt wird."""
    code = None


def _basis():
    url = os.environ.get("KI_ELEVEN_URL", "")
    if url.startswith(("http://127.0.0.1", "http://localhost")):   # nur für Tests
        return url.rstrip("/")
    return "https://api.elevenlabs.io"


# ---------- Schlüssel ----------
def _key():
    try:
        with open(KEY_DATEI, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def key_speichern(key):
    key = str(key).strip()
    if not re.fullmatch(r"[A-Za-z0-9_\-]{16,200}", key):
        raise ElevenFehler("Das sieht nicht wie ein ElevenLabs-API-Schlüssel aus.")
    fd = os.open(KEY_DATEI, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(key)
    os.chmod(KEY_DATEI, 0o600)


def key_loeschen():
    try:
        os.remove(KEY_DATEI)
    except OSError:
        pass


# ---------- Einstellungen ----------
def einstellungen():
    p = bot.lade_persona()
    engine = p.get("tts_engine")
    modell = str(p.get("eleven_modell", STANDARD_MODELL))
    voice_id = str(p.get("eleven_voice_id", ""))
    return {
        "engine": engine if engine in ("piper", "elevenlabs") else "piper",
        "voice_id": voice_id if VOICE_RE.match(voice_id) else "",
        "voice_name": " ".join(str(p.get("eleven_voice_name", "")).split())[:60],
        "modell": modell if modell in MODELLE else STANDARD_MODELL,
    }


def bereit():
    return bool(_key()) and bool(einstellungen()["voice_id"])


def status():
    e = einstellungen()
    e.update({"key_vorhanden": bool(_key()), "modelle": list(MODELLE), "bereit": bereit()})
    return e


def einstellungen_setzen(engine=None, voice_id=None, voice_name=None, modell=None):
    if engine is not None:
        if engine not in ("piper", "elevenlabs"):
            raise ElevenFehler("Unbekannte Sprachausgabe.")
        bot.setze_persona_feld("tts_engine", engine)
    if voice_id is not None:
        voice_id = str(voice_id).strip()
        if voice_id and not VOICE_RE.match(voice_id):
            raise ElevenFehler("Ungültige Stimmen-ID.")
        bot.setze_persona_feld("eleven_voice_id", voice_id)
        bot.setze_persona_feld("eleven_voice_name", " ".join(str(voice_name or "").split())[:60])
    if modell is not None:
        if modell not in MODELLE:
            raise ElevenFehler("Unbekanntes Modell.")
        bot.setze_persona_feld("eleven_modell", modell)


# ---------- API ----------
def _anfrage(methode, pfad, daten=None):
    key = _key()
    if not key:
        raise ElevenFehler("Es ist noch kein ElevenLabs-API-Schlüssel gespeichert.")
    kopf = {"xi-api-key": key, "Accept": "*/*", "User-Agent": "KI-Chatbot/1.0 (lokal)"}
    body = None
    if daten is not None:
        body = json.dumps(daten).encode("utf-8")
        kopf["Content-Type"] = "application/json"
    req = urllib.request.Request(_basis() + pfad, data=body, method=methode, headers=kopf)
    try:
        with urllib.request.urlopen(req, timeout=ZEITLIMIT) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            d = json.loads(e.read())
            det = d.get("detail") if isinstance(d, dict) else None
            if isinstance(det, dict):
                detail = str(det.get("message") or det.get("status") or "")
            elif isinstance(det, str):
                detail = det
        except (ValueError, OSError):
            pass
        detail = detail.replace(key, "***")[:160]
        hinweise = {
            401: "Schlüssel abgelehnt oder Guthaben aufgebraucht.",
            403: "Kein Zugriff mit diesem Schlüssel.",
            404: "Stimme oder Modell nicht gefunden.",
            422: "Anfrage abgelehnt.",
            429: "Zu viele Anfragen oder Limit erreicht.",
        }
        fehler = ElevenFehler(
            f"{hinweise.get(e.code, 'ElevenLabs-Fehler')} (HTTP {e.code}) {detail}".strip())
        fehler.code = e.code
        raise fehler
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ElevenFehler(f"Keine Verbindung zu ElevenLabs ({e}).")


def kuerzen(text):
    """Kürzt lange Texte auf MAX_ZEICHEN, möglichst an einem Satzende."""
    text = " ".join(str(text).split())
    if len(text) <= MAX_ZEICHEN:
        return text
    stueck = text[:MAX_ZEICHEN]
    ende = max(stueck.rfind(". "), stueck.rfind("! "), stueck.rfind("? "))
    if ende >= MAX_ZEICHEN // 2:
        return stueck[:ende + 1]
    leer = stueck.rfind(" ")
    return stueck[:leer] if leer > 0 else stueck


def _stimme_eintrag(v):
    if not isinstance(v, dict):
        return None
    vid = str(v.get("voice_id", ""))
    if not VOICE_RE.match(vid):
        return None
    name = " ".join(str(v.get("name") or vid).split())[:60]
    labels = v.get("labels") if isinstance(v.get("labels"), dict) else {}
    teile = [str(v.get("category") or ""), str(labels.get("gender") or ""),
             str(labels.get("accent") or "")]
    return {"id": vid, "name": name, "info": ", ".join(t for t in teile if t)[:60]}


def stimmen_laden():
    """Stimmen im eigenen Konto (v2 mit Seiten, sonst ältere v1-Liste)."""
    roh = []
    try:
        token, seiten = None, 0
        while seiten < 3:
            pfad = "/v2/voices?page_size=100"
            if token:
                pfad += "&next_page_token=" + urllib.parse.quote(token)
            d = json.loads(_anfrage("GET", pfad))
            roh += d.get("voices", []) if isinstance(d, dict) else []
            seiten += 1
            if isinstance(d, dict) and d.get("has_more") and d.get("next_page_token"):
                token = str(d["next_page_token"])
            else:
                break
    except ElevenFehler as e:
        if e.code not in (404, 405):
            raise
        d = json.loads(_anfrage("GET", "/v1/voices"))
        roh = d.get("voices", []) if isinstance(d, dict) else []
    except ValueError:
        raise ElevenFehler("ElevenLabs hat keine gültige Stimmenliste geliefert.")
    gesehen, ergebnis = set(), []
    for v in roh:
        eintrag = _stimme_eintrag(v)
        if eintrag and eintrag["id"] not in gesehen:
            gesehen.add(eintrag["id"])
            ergebnis.append(eintrag)
    return sorted(ergebnis, key=lambda x: x["name"].lower())[:300]


def sprechen(text):
    text = kuerzen(text)
    if not text:
        raise ElevenFehler("Kein Text zum Sprechen.")
    if not _key():
        raise ElevenFehler("Es ist noch kein ElevenLabs-API-Schlüssel gespeichert.")
    e = einstellungen()
    if not e["voice_id"]:
        raise ElevenFehler("Es ist noch keine ElevenLabs-Stimme ausgewählt.")
    pfad = f"/v1/text-to-speech/{e['voice_id']}?" + urllib.parse.urlencode(
        {"output_format": "mp3_44100_128"})
    audio = _anfrage("POST", pfad, {"text": text, "model_id": e["modell"]})
    if len(audio) < 100:
        raise ElevenFehler("ElevenLabs hat kein Audio geliefert.")
    return audio


def guthaben():
    try:
        d = json.loads(_anfrage("GET", "/v1/user/subscription"))
        return {"verbraucht": int(d["character_count"]), "limit": int(d["character_limit"])}
    except (ValueError, KeyError, TypeError):
        raise ElevenFehler("Das Guthaben konnte nicht gelesen werden (der Schlüssel "
                           "braucht dafür evtl. die Berechtigung für Nutzerdaten).")
