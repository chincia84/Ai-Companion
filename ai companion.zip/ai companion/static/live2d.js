// Live2D-Avatare (.moc3) über pixi-live2d-display im Browser.
// Wird von index.html geladen und stellt window.Live2D bereit.
//
// Die Bibliotheken (Cubism Core, PixiJS, pixi-live2d-display) werden absichtlich
// erst beim ersten tatsächlichen Gebrauch nachgeladen (lazy), nicht beim Start der
// Seite: Cubism Core darf laut Lizenz nur direkt von Live2D selbst bezogen werden
// und könnte fehlen, wenn das automatische Nachladen im Setup nicht geklappt hat.
// Fehlt sie, bleibt die restliche App (3D- und 2D-Avatare) davon unberührt.
(function () {
  const feld = document.getElementById("avatarFeld");
  let canvas = null, app = null, modell = null;
  let bibliothekenVersprechen = null;
  let mundZiel = 0;

  // Zählt jeden Aufruf von laden() durch. Falls laden() überlappend aufgerufen
  // wird (z.B. durch zwei schnell aufeinanderfolgende Auswahl-Änderungen),
  // verwirft ein veralteter, inzwischen überholter Ladevorgang sein Ergebnis
  // selbst dann, wenn er zuerst fertig wird - sonst bliebe sein Modell als nie
  // entfernter "Geister-Avatar" neben dem eigentlichen stehen.
  let ladeZaehler = 0;

  // Verschieben (Ziehen) und Zoomen (Mausrad) des Modells per Hand - wird pro
  // Modell in localStorage gemerkt, damit die Einstellung nach einem Neuladen
  // der Seite erhalten bleibt. offsetX/offsetY sind zusätzliche Verschiebungen
  // in Pixeln, zoomFaktor multipliziert die automatisch berechnete
  // Einpass-Skalierung.
  let offsetX = 0, offsetY = 0, zoomFaktor = 1;
  let aktuelleUrl = null;
  let ziehtGerade = false, ziehStartX = 0, ziehStartY = 0, ziehOffsetX0 = 0, ziehOffsetY0 = 0;

  function anpassungSchluessel(url) {
    return "live2dAnpassung:" + url;
  }

  function anpassungLaden(url) {
    try {
      const roh = localStorage.getItem(anpassungSchluessel(url));
      if (!roh) return { x: 0, y: 0, zoom: 1 };
      const w = JSON.parse(roh);
      return {
        x: typeof w.x === "number" ? w.x : 0,
        y: typeof w.y === "number" ? w.y : 0,
        zoom: typeof w.zoom === "number" && w.zoom > 0 ? w.zoom : 1,
      };
    } catch (e) { return { x: 0, y: 0, zoom: 1 }; }
  }

  function anpassungSpeichern() {
    if (!aktuelleUrl) return;
    try {
      localStorage.setItem(anpassungSchluessel(aktuelleUrl),
        JSON.stringify({ x: offsetX, y: offsetY, zoom: zoomFaktor }));
    } catch (e) { /* localStorage evtl. nicht verfügbar - kein Problem */ }
  }

  function skriptLaden(src) {
    return new Promise((resolve, reject) => {
      if (document.querySelector('script[src="' + src + '"]')) { resolve(); return; }
      const s = document.createElement("script");
      s.src = src;
      s.onload = () => resolve();
      s.onerror = () => reject(new Error("Konnte " + src + " nicht laden: " + src));
      document.head.appendChild(s);
    });
  }

  function bibliothekenLaden() {
    if (!bibliothekenVersprechen) {
      bibliothekenVersprechen = (async () => {
        // Reihenfolge wichtig: Cubism Core muss vor pixi-live2d-display da sein.
        await skriptLaden("/lib/live2dcubismcore.min.js");
        await skriptLaden("/lib/pixi.min.js");
        await skriptLaden("/lib/pixi-live2d-display-cubism4.min.js");
        if (!window.PIXI || !window.PIXI.live2d) {
          throw new Error("Live2D-Bibliotheken sind unvollständig.");
        }
      })();
    }
    return bibliothekenVersprechen;
  }

  function kanvasBereitstellen() {
    if (canvas) return canvas;
    canvas = document.createElement("canvas");
    canvas.id = "live2dCanvas";
    canvas.style.cssText = "display:block;width:100%;height:100%;cursor:grab;touch-action:none";
    canvas.hidden = true;
    feld.appendChild(canvas);
    new ResizeObserver(groesseAnpassen).observe(feld);

    // Ziehen mit der Maus/dem Finger verschiebt das Modell.
    canvas.addEventListener("pointerdown", (ev) => {
      if (!modell) return;
      ziehtGerade = true;
      ziehStartX = ev.clientX;
      ziehStartY = ev.clientY;
      ziehOffsetX0 = offsetX;
      ziehOffsetY0 = offsetY;
      canvas.style.cursor = "grabbing";
      try { canvas.setPointerCapture(ev.pointerId); } catch (e) { /* ignorieren */ }
    });
    canvas.addEventListener("pointermove", (ev) => {
      if (!ziehtGerade) return;
      offsetX = ziehOffsetX0 + (ev.clientX - ziehStartX);
      offsetY = ziehOffsetY0 + (ev.clientY - ziehStartY);
      passeModellEin();
    });
    const ziehenBeenden = () => {
      if (!ziehtGerade) return;
      ziehtGerade = false;
      canvas.style.cursor = "grab";
      anpassungSpeichern();
    };
    canvas.addEventListener("pointerup", ziehenBeenden);
    canvas.addEventListener("pointercancel", ziehenBeenden);
    canvas.addEventListener("pointerleave", () => { if (ziehtGerade) ziehenBeenden(); });

    // Mausrad zoomt hinein/heraus.
    canvas.addEventListener("wheel", (ev) => {
      if (!modell) return;
      ev.preventDefault();
      const richtung = ev.deltaY > 0 ? -1 : 1;
      zoomFaktor = Math.max(0.3, Math.min(5, zoomFaktor * (richtung > 0 ? 1.1 : 1 / 1.1)));
      passeModellEin();
      anpassungSpeichern();
    }, { passive: false });

    // Doppelklick setzt Position/Zoom zurück auf die automatische Einpassung.
    canvas.addEventListener("dblclick", () => {
      if (!modell) return;
      offsetX = 0; offsetY = 0; zoomFaktor = 1;
      passeModellEin();
      anpassungSpeichern();
    });

    return canvas;
  }

  function groesseAnpassen() {
    if (!app) return;
    const b = feld.clientWidth, h = feld.clientHeight;
    if (b < 2 || h < 2) return;
    app.renderer.resize(b, h);
    passeModellEin();
  }

  function passeModellEin() {
    if (!modell || !app) return;
    const b = app.renderer.width, h = app.renderer.height;
    const bModell = modell.internalModel.width || modell.width || 1;
    const hModell = modell.internalModel.height || modell.height || 1;
    const basisSkala = Math.min(b / bModell, h / hModell) * 0.85;
    modell.scale.set(basisSkala * zoomFaktor);
    modell.anchor.set(0.5, 0.5);
    modell.position.set(b / 2 + offsetX, h / 2 + offsetY);
  }

  async function laden(url) {
    const eigeneGeneration = ++ladeZaehler;
    await bibliothekenLaden();
    if (eigeneGeneration !== ladeZaehler) return;   // inzwischen überholt
    kanvasBereitstellen();
    if (!app) {
      app = new PIXI.Application({ view: canvas, autoStart: true, backgroundAlpha: 0,
                                   resolution: Math.min(window.devicePixelRatio || 1, 2) });
    }
    if (modell) {
      app.stage.removeChild(modell);
      modell.destroy();
      modell = null;
    }
    if (!window.PIXI || !window.PIXI.live2d || !window.PIXI.live2d.Live2DModel) {
      // Typischerweise eine nicht zu pixi-live2d-display passende PixiJS-Version
      // (pixi-live2d-display initialisiert sich dann nicht richtig und hängt
      // kein Live2DModel an PIXI.live2d an) - klare Meldung statt kryptischem
      // TypeError weiter unten.
      throw new Error("PIXI.live2d.Live2DModel fehlt - vermutlich passt die " +
        "geladene PixiJS-Version nicht zu pixi-live2d-display (es wird PixiJS 6.x " +
        "benötigt). Setup erneut ausführen, nachdem static/lib/pixi.min.js gelöscht " +
        "wurde, damit die richtige Version neu geladen wird.");
    }
    aktuelleUrl = url;
    const gemerkt = anpassungLaden(url);
    offsetX = gemerkt.x; offsetY = gemerkt.y; zoomFaktor = gemerkt.zoom;
    const neuesModell = await PIXI.live2d.Live2DModel.from(url, { autoInteract: false });
    if (eigeneGeneration !== ladeZaehler) {
      // Ein neuerer Ladevorgang hat inzwischen übernommen - dieses Ergebnis
      // verwerfen statt es zusätzlich zur Bühne hinzuzufügen.
      neuesModell.destroy();
      return;
    }
    modell = neuesModell;
    app.stage.addChild(modell);
    groesseAnpassen();
    canvas.hidden = false;
  }

  function entfernen() {
    if (modell && app) {
      app.stage.removeChild(modell);
      modell.destroy();
      modell = null;
    }
    if (canvas) canvas.hidden = true;
  }

  function parameterSetzen(name, wert) {
    try {
      const kern = modell && modell.internalModel && modell.internalModel.coreModel;
      if (kern) kern.setParameterValueById(name, wert);
    } catch (e) { /* Modell kennt diesen Parameter nicht - kein Problem */ }
  }

  // Nicht jedes Live2D-Modell hat Ausdrücke/Motions mit diesen Namen - best effort,
  // schlägt eine Zuordnung fehl, bleibt der Avatar einfach in seiner aktuellen Pose.
  const EMOTION_AUSDRUECKE = { freundlich: "happy", traurig: "sad", "überrascht": "surprised" };
  const GESTEN_MOTIONS = { nicken: "Nod", winken: "Wave" };

  function emotion(name) {
    if (!modell) return;
    const ausdruck = EMOTION_AUSDRUECKE[name];
    try {
      if (ausdruck && typeof modell.expression === "function") modell.expression(ausdruck);
      else if (!ausdruck && typeof modell.expression === "function") modell.expression();
    } catch (e) { /* kein passender Ausdruck im Modell - kein Problem */ }
  }

  function geste(name) {
    if (!modell) return;
    const motion = GESTEN_MOTIONS[name];
    if (!motion) return;
    try {
      if (typeof modell.motion === "function") modell.motion(motion);
    } catch (e) { /* keine passende Motion im Modell - kein Problem */ }
  }

  function mund(level) {
    mundZiel = Math.max(0, Math.min(1, level));
    parameterSetzen("ParamMouthOpenY", mundZiel);
  }

  window.Live2D = {
    laden,
    entfernen,
    emotion,
    geste,
    mund,
    geladen: () => modell !== null,
    bibliothekenBereit: () => !!(window.PIXI && window.PIXI.live2d),
  };
  window.dispatchEvent(new Event("live2d-bereit"));
})();

