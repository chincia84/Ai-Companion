// 3D-Avatar (VRM) mit three.js und @pixiv/three-vrm.
// Wird von index.html geladen und stellt window.Avatar bereit.
import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { VRMLoaderPlugin, VRMUtils } from "@pixiv/three-vrm";
import { VRMAnimationLoaderPlugin, createVRMAnimationClip } from "@pixiv/three-vrm-animation";

// ---- Einstellungen zum Feintunen ----
const ARM_WINKEL = 1.2;             // wie weit die Arme aus der T-Pose gesenkt werden
const EMO_BEIM_SPRECHEN = 0.6;      // Stärke der Mimik, während gesprochen wird
const KAMERA_ABSTAND = 1.5;         // Meter (kleiner = näher dran)
const EMOTION_ZIEL = {
  neutral: {},
  freundlich: { happy: 0.6 },
  traurig: { sad: 0.8 },
  "überrascht": { surprised: 0.8 },
};
const EMOTIONS_NAMEN = ["happy", "sad", "surprised", "angry", "relaxed"];

const feld = document.getElementById("avatarFeld");
let renderer = null, scene = null, camera = null, controls = null;
let vrm = null;
let animMixer = null, animAction = null;
const uhr = new THREE.Clock();

// Zustand
let emotionsName = "neutral";
const emotionsWerte = {};
let mundZiel = 0, mundGlatt = 0;
const blinzeln = { timer: 2, phase: -1 };
const gestenZustand = { art: "keine", t: 0, dauer: 0 };
let armL = ARM_WINKEL, armR = -ARM_WINKEL;  // wird beim Laden gemessen

// Ruhe-Animation: Lebendigkeit (0 = reglos, 1 = normal, 2 = sehr lebendig) und Umschauen
const idle = { staerke: 1, umschauen: true, naechstesUmschauen: 8 + Math.random() * 12,
              umschauPhase: 0, umschauDauer: 0, umschauZiel: 0 };

function initSzene() {
  if (renderer) return;
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.domElement.hidden = true;   // erst sichtbar, wenn wirklich ein Modell geladen ist -
                                        // sonst bleibt die leere/alte Canvas über anderen
                                        // Avatar-Arten (2D, Live2D) sichtbar liegen
  feld.appendChild(renderer.domElement);

  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(30, 1, 0.1, 20);
  camera.position.set(0, 1.35, KAMERA_ABSTAND);

  controls = new OrbitControls(camera, renderer.domElement);
  controls.enablePan = false;
  controls.minDistance = 0.5;
  controls.maxDistance = 4;
  controls.target.set(0, 1.3, 0);
  controls.update();

  const licht = new THREE.DirectionalLight(0xffffff, Math.PI);
  licht.position.set(1, 1.5, 2);
  scene.add(licht);
  scene.add(new THREE.AmbientLight(0xffffff, 0.4));

  new ResizeObserver(groesseAnpassen).observe(feld);
  groesseAnpassen();
  schleife();
}

function groesseAnpassen() {
  if (!renderer) return;
  const b = feld.clientWidth, h = feld.clientHeight;
  if (b < 2 || h < 2) return;
  renderer.setSize(b, h, false);
  camera.aspect = b / h;
  camera.updateProjectionMatrix();
}

// Findet heraus, in welche Drehrichtung der Arm nach unten geht (modellunabhängig)
function richtungFuerArm(v, oberarm, hand) {
  const arm = v.humanoid.getNormalizedBoneNode(oberarm);
  const h = v.humanoid.getRawBoneNode(hand);
  if (!arm || !h) return 1;
  const messeY = () => {
    v.humanoid.update();
    v.scene.updateMatrixWorld(true);
    return new THREE.Vector3().setFromMatrixPosition(h.matrixWorld).y;
  };
  arm.rotation.z = 0;
  const y0 = messeY();
  arm.rotation.z = -0.8;
  const y1 = messeY();
  arm.rotation.z = 0;
  v.humanoid.update();
  return y1 < y0 ? -1 : 1;
}

function kameraRahmen() {
  const kopf = vrm.humanoid.getRawBoneNode("head");
  vrm.humanoid.update();
  vrm.scene.updateMatrixWorld(true);
  if (!kopf) return;
  const p = new THREE.Vector3().setFromMatrixPosition(kopf.matrixWorld);
  controls.target.set(p.x, p.y - 0.12, 0);
  camera.position.set(p.x, p.y - 0.05, KAMERA_ABSTAND);
  controls.update();
}

async function laden(url) {
  initSzene();
  const lader = new GLTFLoader();
  lader.register(parser => new VRMLoaderPlugin(parser));
  const gltf = await lader.loadAsync(url);
  const neu = gltf.userData.vrm;
  if (!neu) throw new Error("Datei enthält kein VRM-Modell");

  entfernen();
  VRMUtils.rotateVRM0(neu);                     // VRM0-Modelle drehen, damit sie zur Kamera schauen
  neu.scene.traverse(o => { o.frustumCulled = false; });
  scene.add(neu.scene);
  vrm = neu;
  animMixer = null;
  animAction = null;

  armL = richtungFuerArm(vrm, "leftUpperArm", "leftHand") * ARM_WINKEL;
  armR = richtungFuerArm(vrm, "rightUpperArm", "rightHand") * ARM_WINKEL;
  kameraRahmen();
  groesseAnpassen();
  renderer.domElement.hidden = false;
}

function entfernen() {
  if (renderer) renderer.domElement.hidden = true;
  if (!vrm) return;
  scene.remove(vrm.scene);
  VRMUtils.deepDispose(vrm.scene);
  vrm = null;
  animMixer = null;
  animAction = null;
}

// Spielt eine .vrma-Bewegungsdatei ab. Solange sie läuft, pausiert die
// prozedurale Ruhe-Animation (Atmen, Kopf, Arme, Gesten) für den Körper,
// damit sich beide nicht gegenseitig überschreiben.
async function spieleAnimation(url) {
  if (!vrm) throw new Error("Kein Avatar geladen.");
  const lader = new GLTFLoader();
  lader.register(parser => new VRMAnimationLoaderPlugin(parser));
  const gltf = await lader.loadAsync(url);
  const anim = gltf.userData.vrmAnimations && gltf.userData.vrmAnimations[0];
  if (!anim) throw new Error("Die Datei enthält keine VRM-Bewegung.");
  const clip = createVRMAnimationClip(anim, vrm);
  if (!animMixer) animMixer = new THREE.AnimationMixer(vrm.scene);
  animMixer.stopAllAction();
  animAction = animMixer.clipAction(clip);
  animAction.setLoop(THREE.LoopRepeat);
  animAction.play();
}

function stoppeAnimation() {
  if (animMixer) animMixer.stopAllAction();
  animAction = null;
}

function animiere(dt, t) {
  const h = vrm.humanoid;
  const em = vrm.expressionManager;
  const knochen = name => h.getNormalizedBoneNode(name);

  // Läuft gerade eine importierte Bewegung (.vrma)? Dann steuert sie Kopf, Arme
  // und Körper selbst, und die eingebaute Ruhe-Animation für den Körper pausiert.
  if (!animAction) {
    // --- Geste weiterlaufen lassen ---
    let nick = 0, winkEinfluss = 0;
    if (gestenZustand.art !== "keine") {
      gestenZustand.t += dt;
      const p = gestenZustand.t / gestenZustand.dauer;
      if (p >= 1) {
        gestenZustand.art = "keine";
      } else if (gestenZustand.art === "nicken") {
        nick = Math.sin(p * Math.PI * 3) * 0.14 * (1 - p * 0.5);
      } else if (gestenZustand.art === "winken") {
        winkEinfluss = Math.sin(Math.PI * p);
      }
    }

    // --- gelegentliches größeres Umsehen ---
    let umschauY = 0;
    if (idle.umschauen && idle.staerke > 0) {
      if (idle.umschauPhase === 0) {
        idle.naechstesUmschauen -= dt;
        if (idle.naechstesUmschauen <= 0) {
          idle.umschauPhase = 1; idle.umschauDauer = 0;
          idle.umschauZiel = (Math.random() < 0.5 ? -1 : 1) * (0.25 + Math.random() * 0.25);
        }
      } else {
        idle.umschauDauer += dt;
        const gesamt = 3.2, halb = gesamt / 2;
        const verlauf = idle.umschauDauer < halb
          ? idle.umschauDauer / halb : 1 - (idle.umschauDauer - halb) / halb;
        umschauY = idle.umschauZiel * Math.max(0, Math.min(1, verlauf));
        if (idle.umschauDauer >= gesamt) {
          idle.umschauPhase = 0; idle.naechstesUmschauen = 10 + Math.random() * 15;
        }
      }
    }

    // --- Körper: Atmen, Kopf, Arme ---
    const st = idle.staerke;
    const brust = knochen("chest") || knochen("spine");
    if (brust) brust.rotation.x = Math.sin(t * 1.5) * 0.012 * st;

    const kopf = knochen("head");
    if (kopf) {
      kopf.rotation.y = Math.sin(t * 0.4) * 0.05 * st + umschauY;
      kopf.rotation.x = Math.sin(t * 0.6) * 0.02 * st + nick;
    }

    const links = knochen("leftUpperArm"), rechts = knochen("rightUpperArm");
    if (links) links.rotation.z = armL + Math.sin(t * 1.5) * 0.01;
    if (rechts) {
      const oben = -armR * 0.35;                  // Arm leicht über Schulterhöhe
      rechts.rotation.z = armR + (oben - armR) * winkEinfluss
                        + Math.sin(t * 11) * 0.12 * winkEinfluss
                        + Math.sin(t * 1.5 + 1) * 0.01 * (1 - winkEinfluss);
    }
  }

  if (!em) return;

  // --- Mimik (weich überblenden) ---
  const ziele = EMOTION_ZIEL[emotionsName] || {};
  const spricht = mundGlatt > 0.08;
  for (const name of EMOTIONS_NAMEN) {
    const soll = (ziele[name] || 0) * (spricht ? EMO_BEIM_SPRECHEN : 1);
    const ist = emotionsWerte[name] || 0;
    const neuWert = ist + (soll - ist) * Math.min(1, dt * 6);
    emotionsWerte[name] = neuWert;
    em.setValue(name, neuWert);
  }

  // --- Blinzeln ---
  blinzeln.timer -= dt;
  if (blinzeln.phase < 0 && blinzeln.timer <= 0) blinzeln.phase = 0;
  if (blinzeln.phase >= 0) {
    blinzeln.phase += dt;
    em.setValue("blink", Math.sin(Math.min(blinzeln.phase / 0.18, 1) * Math.PI));
    if (blinzeln.phase >= 0.18) {
      blinzeln.phase = -1;
      blinzeln.timer = 2 + Math.random() * 4;
      em.setValue("blink", 0);
    }
  }

  // --- Lippenbewegung aus der Lautstärke der Stimme ---
  mundGlatt += (mundZiel - mundGlatt) * Math.min(1, dt * 20);
  const g = mundGlatt;
  em.setValue("aa", Math.min(1, g * (0.55 + 0.45 * Math.abs(Math.sin(t * 10)))));
  em.setValue("oh", g * 0.25 * Math.abs(Math.sin(t * 6.3)));
  em.setValue("ih", g * 0.2 * Math.abs(Math.sin(t * 8.1 + 1)));
}

function schleife() {
  requestAnimationFrame(schleife);
  if (document.hidden) return;
  const dt = Math.min(uhr.getDelta(), 0.1);
  if (vrm) {
    if (animMixer) animMixer.update(dt);
    animiere(dt, uhr.elapsedTime);
    vrm.update(dt);
  }
  controls.update();
  renderer.render(scene, camera);
}

// ---- Schnittstelle nach außen ----
window.Avatar = {
  laden,
  entfernen,
  geladen: () => vrm !== null,
  emotion(name) { emotionsName = name; },
  geste(name) {
    if (name === "nicken" || name === "winken") {
      gestenZustand.art = name;
      gestenZustand.t = 0;
      gestenZustand.dauer = name === "nicken" ? 1.1 : 2.4;
    }
  },
  mund(level) { mundZiel = level; },
  spieleAnimation,
  stoppeAnimation,
  animationAktiv: () => animAction !== null,
  setIdle(einstellungen) {
    if (typeof einstellungen.staerke === "number" && isFinite(einstellungen.staerke)) {
      idle.staerke = Math.max(0, Math.min(2, einstellungen.staerke));
    }
    if (typeof einstellungen.umschauen === "boolean") {
      idle.umschauen = einstellungen.umschauen;
    }
  },
};
window.dispatchEvent(new Event("avatar-bereit"));
