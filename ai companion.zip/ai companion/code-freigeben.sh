#!/usr/bin/env bash
# Sperrt den Programmcode und berechnet die Prüfsummen.
#   ./code-freigeben.sh entsperren   -> Code zum Bearbeiten freigeben
#   ./code-freigeben.sh              -> nach deinen Änderungen: Prüfsummen neu,
#                                       Code wieder sperren
# Der Bot hat keine Funktion, die das kann.
cd "$(dirname "$0")" || exit 1
DATEIEN="bot.py server.py sicherheit.py claude_partner.py avatar_studio.py internet.py vision.py elevenlabs.py live2d.py spracheingabe.py erinnerungen.py discord_bot.py sicherung.py profile.py start.sh code-freigeben.sh static/index.html static/avatar.js"

if [ "${1:-}" = "entsperren" ]; then
  chmod u+w . static $DATEIEN .code-pruefsummen 2>/dev/null
  chmod -R u+w static
  echo "Code entsperrt. Ändere die Dateien und führe danach ./code-freigeben.sh aus."
  exit 0
fi

[ -e .code-pruefsummen ] && chmod u+w .code-pruefsummen
{
  sha256sum $DATEIEN
  find static/lib -type f 2>/dev/null | sort | xargs -r sha256sum
} > .code-pruefsummen
rm -rf __pycache__ 2>/dev/null
chmod a-w $DATEIEN .code-pruefsummen   # Dateien nicht änderbar
chmod -R a-w static                    # static und alles darin
chmod a-w .                            # Ordner gesperrt: nichts löschen/ersetzen
echo "Prüfsummen aktualisiert, Code gesperrt. Bot neu starten."
