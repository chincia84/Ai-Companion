import base64
import glob
import importlib.util
import io
import json
import os
import re
import signal
import sys
import threading
import time
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, unquote, urlsplit

import bot
import sicherheit
import claude_partner
import avatar_studio
import internet
import vision
import elevenlabs
import live2d
import spracheingabe
import erinnerungen
import discord_bot
import sicherung
import profile

BASIS = os.path.dirname(os.path.abspath(__file__))
STIMMEN = os.path.join(BASIS, "stimmen")
VERLAUF_DATEI = os.path.join(bot.DATEN, "verlauf.json")
FAKTEN_DATEI = os.path.join(bot.DATEN, "fakten.json")
STIMMUNG_DATEI = os.path.join(bot.DATEN, "stimmung.json")
ZEITFORMAT = "%Y-%m-%d %H:%M:%S"
PORT = int(os.environ.get("KI_PORT", "8765"))
AVATAR_DIR = avatar_studio.AVATAR_DIR
MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".vrm": "model/gltf-binary",
    ".vrma": "model/gltf-binary",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif": "image/gif",
}
MAX_GESPEICHERT = 200   # Nachrichten auf der Platte
MAX_AN_MODELL = 24      # Nachrichten, die das Modell sieht
MAX_SUCH_RUNDEN = 2     # höchstens so oft pro Nachricht suchen (vom Server erzwungen)

_daten_lock = threading.Lock()
_stimme = None
_stimme_pfad = None
_stimme_lock = threading.Lock()
_synth_lock = threading.Lock()


# ---------- Speicher ----------
def lade_json(pfad, standard):
    """Lädt eine JSON-Datei; bei Fehlern oder falschem Typ gilt der Standardwert."""
    try:
        with open(pfad, encoding="utf-8") as f:
            daten = json.load(f)
    except (OSError, ValueError):
        return standard
    return daten if isinstance(daten, type(standard)) else standard


def speichere_json(pfad, daten):
    tmp = pfad + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(daten, f, ensure_ascii=False, indent=1)
    os.replace(tmp, pfad)


# ---------- Sprachausgabe ----------
def installierte_stimmen():
    pfade = glob.glob(os.path.join(STIMMEN, "**", "*.onnx"), recursive=True)
    return sorted({os.path.basename(p)[:-len(".onnx")] for p in pfade})


def stimme_pfad():
    name = bot.lade_persona()["stimme"]
    treffer = glob.glob(os.path.join(STIMMEN, "**", name + ".onnx"),
                        recursive=True)
    return treffer[0] if treffer else None


def piper_verfuegbar():
    return importlib.util.find_spec("piper") is not None and stimme_pfad() is not None


def tts_engine():
    e = bot.lade_persona().get("tts_engine", "piper")
    return e if e in ("piper", "elevenlabs") else "piper"


def tts_verfuegbar():
    """True, wenn irgendeine Sprachausgabe funktioniert (bei ElevenLabs zählt die
    lokale Stimme als Rückfall)."""
    if tts_engine() == "elevenlabs":
        return elevenlabs.bereit() or piper_verfuegbar()
    return piper_verfuegbar()


def hole_stimme():
    """Lädt die in persona.json eingestellte Stimme; wechselt bei Änderung."""
    global _stimme, _stimme_pfad
    pfad = stimme_pfad()
    with _stimme_lock:
        if _stimme is None or _stimme_pfad != pfad:
            from piper import PiperVoice
            _stimme = PiperVoice.load(pfad)
            _stimme_pfad = pfad
        return _stimme


def sprechtext(text):
    """Entfernt Emojis und Markdown-Zeichen, damit nichts Komisches vorgelesen wird."""
    text = re.sub(r"[\U00010000-\U0010ffff\u2600-\u27bf]", "", text)
    text = re.sub(r"[*_`#>~|]", "", text)
    return " ".join(text.split())


def synthetisiere(text):
    stimme = hole_stimme()
    puffer = io.BytesIO()
    with _synth_lock:
        with wave.open(puffer, "wb") as w:
            stimme.synthesize_wav(text, w)
    return puffer.getvalue()


def erzeuge_sprache(text):
    """Liefert (audio, mime, hinweis). Fällt bei ElevenLabs-Problemen auf die
    lokale Stimme zurück, wenn es sie gibt; sonst wird der Fehler weitergereicht."""
    if tts_engine() == "elevenlabs":
        try:
            return elevenlabs.sprechen(text), "audio/mpeg", ""
        except elevenlabs.ElevenFehler as e:
            if not piper_verfuegbar():
                raise
            return synthetisiere(text), "audio/wav", f"ElevenLabs: {e} Lokale Stimme verwendet."[:220]
    return synthetisiere(text), "audio/wav", ""


# ---------- Chat ----------
def _zusatz(persona):
    z = (f"Aktuelles Datum und Uhrzeit (von der Systemuhr, verlässliche Quelle): "
        f"{bot.uhrzeit_text()}. Nutze das für Fragen nach Uhrzeit/Datum, statt zu raten.")
    z = (z + " " + avatar_studio.bot_zusatz()).strip()
    if persona.get("internet_erlaubt"):
        z = (z + " " + internet.bot_zusatz()).strip()
    return z


def chat(text):
    with _daten_lock:
        verlauf = lade_json(VERLAUF_DATEI, [])
        fakten = lade_json(FAKTEN_DATEI, [])
    persona = bot.lade_persona()
    internet_erlaubt = bool(persona.get("internet_erlaubt"))
    with _daten_lock:
        stimmung = lade_json(STIMMUNG_DATEI, {})
    kontext = verlauf[-(MAX_AN_MODELL - 1):] + [{"role": "user", "content": text}]
    antwort = bot.antworte(kontext, fakten, zusatz=_zusatz(persona), stimmung=stimmung.get("text", ""))
    if antwort.get("fehler"):          # Fehler nicht im Verlauf speichern
        antwort["fakten"] = fakten
        return antwort

    gesuche = []
    runden = 0
    while internet_erlaubt and antwort.get("suche") and runden < MAX_SUCH_RUNDEN:
        frage = antwort.pop("suche")
        runden += 1
        try:
            treffer = internet.suche(frage)
            fehlermeldung = None
        except internet.InternetFehler as e:
            treffer, fehlermeldung = [], str(e)
        # Jeder Fundstellentext ist externer, nicht vertrauenswürdiger Inhalt: Code
        # oder Befehle darin werden herausgefiltert und landen im Eingang, bevor
        # irgendetwas davon den Bot ODER die Oberfläche erreicht.
        bereinigt = []
        for t in treffer:
            sauber_t = sicherheit.extern_verarbeiten(f"Websuche: {frage} ({t['url']})", t["text"])
            bereinigt.append({"titel": t["titel"], "url": t["url"], "text": sauber_t["text"]})
        gesuche.append({"frage": frage, "treffer": bereinigt, "fehler": fehlermeldung})
        text_fuer_bot = fehlermeldung or internet.ergebnisse_als_text(frage, bereinigt)
        kontext = kontext + [
            {"role": "assistant", "content": f"[Ich suche: {frage}]"},
            {"role": "user", "content": text_fuer_bot},
        ]
        antwort = bot.antworte(kontext, fakten, zusatz=_zusatz(persona), stimmung=stimmung.get("text", ""))
        if antwort.get("fehler"):
            antwort["fakten"] = fakten
            return antwort
    antwort.pop("suche", None)   # Limit erreicht: letzten Suchwunsch nicht mehr zeigen
    outfit = antwort.pop("outfit", "")
    neue_stimmung = antwort.pop("stimmung", "")

    erinnerung_minuten = antwort.pop("erinnerung_minuten", 0)
    erinnerung_text = antwort.pop("erinnerung_text", "")
    gemerkt = bot.fakt_hinzufuegen(fakten, antwort.pop("merke", ""))
    gewechselt = avatar_studio.bot_wechsel(outfit)
    if gewechselt:
        antwort["avatar_gewechselt"] = gewechselt
    if erinnerung_minuten and erinnerung_text:
        neu = erinnerungen.hinzufuegen(erinnerung_text, erinnerung_minuten)
        if neu:
            antwort["erinnerung_gesetzt"] = {"text": neu["text"], "minuten": erinnerung_minuten}
            antwort["erinnerungen"] = erinnerungen.liste()
    jetzt = time.strftime(ZEITFORMAT)
    verlauf.append({"role": "user", "content": text, "zeit": jetzt})
    verlauf.append({"role": "assistant", "content": antwort["text"],
                    "emotion": antwort["emotion"], "geste": antwort["geste"], "zeit": jetzt})
    verlauf = verlauf[-MAX_GESPEICHERT:]
    with _daten_lock:
        speichere_json(VERLAUF_DATEI, verlauf)
        speichere_json(FAKTEN_DATEI, fakten)
        if neue_stimmung:
            speichere_json(STIMMUNG_DATEI, {"text": neue_stimmung, "zeit": jetzt})
    antwort["fakten"] = fakten
    antwort["gemerkt"] = gemerkt
    if gesuche:
        antwort["suchen"] = gesuche
    return antwort


def _erinnerungen_pruefen_und_erzeugen():
    """Hängt fällige Erinnerungen als Bot-Nachricht an den Verlauf an - genau wie
    eine proaktive Begleiter-Nachricht, nur ausgelöst durch die Uhrzeit statt durch
    Stille."""
    faellige = erinnerungen.faellige_abholen()
    if not faellige:
        return
    with _daten_lock:
        verlauf = lade_json(VERLAUF_DATEI, [])
        for e in faellige:
            jetzt = time.strftime(ZEITFORMAT)
            verlauf.append({"role": "assistant",
                           "content": "⏰ Erinnerung: " + e["text"],
                           "emotion": "freundlich", "geste": "winken",
                           "zeit": jetzt, "proaktiv": True})
        verlauf = verlauf[-MAX_GESPEICHERT:]
        speichere_json(VERLAUF_DATEI, verlauf)


def _proaktiv_pruefen_und_erzeugen():
    """Lässt den Bot sich von selbst melden, wenn der Begleiter-Modus an ist und
    lange genug Stille war. Wird bei jeder Statusabfrage geprüft; da die neue
    Nachricht selbst zum jüngsten Verlaufseintrag wird, stellt sich die Uhr dabei
    automatisch zurück (kein wiederholtes Auslösen bei jeder Abfrage)."""
    persona = bot.lade_persona()
    if not persona.get("begleiter_modus"):
        return None
    with _daten_lock:
        verlauf = lade_json(VERLAUF_DATEI, [])
        fakten = lade_json(FAKTEN_DATEI, [])
        stimmung = lade_json(STIMMUNG_DATEI, {})
    if not verlauf:
        return None
    schwelle_stunden = float(persona.get("begleiter_stunden", 4) or 4)
    schwelle_stunden = max(0.1, min(168, schwelle_stunden))
    letzte_zeit_roh = verlauf[-1].get("zeit")
    letzte_zeit = 0.0
    if letzte_zeit_roh:
        try:
            letzte_zeit = time.mktime(time.strptime(letzte_zeit_roh, ZEITFORMAT))
        except ValueError:
            letzte_zeit = 0.0
    if letzte_zeit:
        verstrichen_stunden = (time.time() - letzte_zeit) / 3600
        if verstrichen_stunden < schwelle_stunden:
            return None
    else:
        verstrichen_stunden = schwelle_stunden   # alter Eintrag ohne Zeitstempel: einmalig auslösen

    antwort = bot.proaktive_nachricht(fakten, stimmung.get("text", ""), verstrichen_stunden)
    if antwort.get("fehler"):
        return None   # z. B. Ollama gerade nicht erreichbar: beim nächsten Mal erneut versuchen
    neue_stimmung = antwort.pop("stimmung", "")
    jetzt = time.strftime(ZEITFORMAT)
    eintrag = {"role": "assistant", "content": antwort["text"], "emotion": antwort["emotion"],
              "geste": antwort["geste"], "zeit": jetzt, "proaktiv": True}
    with _daten_lock:
        verlauf = lade_json(VERLAUF_DATEI, [])
        verlauf.append(eintrag)
        verlauf = verlauf[-MAX_GESPEICHERT:]
        speichere_json(VERLAUF_DATEI, verlauf)
        if neue_stimmung:
            speichere_json(STIMMUNG_DATEI, {"text": neue_stimmung, "zeit": jetzt})
    return eintrag


class Handler(BaseHTTPRequestHandler):
    def _senden(self, code, inhalt, typ, kopf=None):
        self.send_response(code)
        self.send_header("Content-Type", typ)
        self.send_header("Content-Length", str(len(inhalt)))
        for name, wert in (kopf or {}).items():
            self.send_header(name, wert)
        self.end_headers()
        self.wfile.write(inhalt)

    def _json(self, code, obj):
        self._senden(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                     "application/json; charset=utf-8")

    def _erlaubt(self):
        """Nur Anfragen von der eigenen Oberfläche (Schutz vor fremden Webseiten)."""
        host = self.headers.get("Host", "")
        origin = self.headers.get("Origin")
        if host not in (f"127.0.0.1:{PORT}", f"localhost:{PORT}"):
            return False
        return origin is None or origin in (f"http://127.0.0.1:{PORT}",
                                            f"http://localhost:{PORT}")

    def _datei(self, wurzel, rel):
        """Liefert eine Datei aus 'wurzel' aus (kein Zugriff außerhalb)."""
        wurzel = os.path.realpath(wurzel)
        pfad = os.path.realpath(os.path.join(wurzel, rel))
        if not pfad.startswith(wurzel + os.sep) or not os.path.isfile(pfad):
            return self._senden(404, b"nicht gefunden", "text/plain")
        typ = MIME.get(os.path.splitext(pfad)[1].lower(), "application/octet-stream")
        with open(pfad, "rb") as f:
            self._senden(200, f.read(), typ)

    def _bildschirm_verarbeiten(self, laenge):
        qs = parse_qs(urlsplit(self.path).query)
        backend = qs.get("backend", ["claude"])[0]
        frage = qs.get("frage", [""])[0][:400]

        if laenge < 100 or laenge > 15 * 1024 * 1024:
            return self._json(400, {"fehler": True,
                                    "text": "Bild zu klein oder zu groß (höchstens 15 MB)."})
        rest, bild = laenge, bytearray()
        while rest > 0:
            teil = self.rfile.read(min(1 << 20, rest))
            if not teil:
                break
            bild += teil
            rest -= len(teil)
        if rest or bytes(bild[:8]) != b"\x89PNG\r\n\x1a\n":
            return self._json(400, {"fehler": True, "text": "Kein gültiges PNG."})
        bild_b64 = base64.b64encode(bytes(bild)).decode("ascii")
        del bild   # Bilddaten so kurz wie möglich im Speicher halten

        try:
            if backend == "lokal":
                beschreibung = vision.bild_analysieren(bild_b64, frage)
                quelle = f"Bildschirm ({vision.aktuelles_modell()})"
            else:
                if not claude_partner.hole_key():
                    return self._json(400, {"fehler": True,
                                            "text": "Für Claude fehlt der API-Schlüssel "
                                                    "(Bereich \"Gespräch mit Claude\")."})
                beschreibung = claude_partner.bild_analysieren(bild_b64, "image/png", frage)
                quelle = "Bildschirm (Claude)"
        except (vision.VisionFehler, claude_partner.ClaudeFehler) as e:
            return self._json(400, {"fehler": True, "text": str(e)})
        del bild_b64

        # Die Bildbeschreibung ist externer, nicht vertrauenswürdiger Text: Code oder
        # Befehle darin landen im Eingang, bevor sie den Bot erreichen.
        sauber = sicherheit.extern_verarbeiten(quelle, beschreibung)

        persona = bot.lade_persona()
        with _daten_lock:
            verlauf = lade_json(VERLAUF_DATEI, [])
            fakten = lade_json(FAKTEN_DATEI, [])
            stimmung = lade_json(STIMMUNG_DATEI, {})
        anzeige_text = frage.strip() or "Ich zeige dir etwas auf meinem Bildschirm."
        kontext_liste = verlauf[-(MAX_AN_MODELL - 1):] + [
            {"role": "user", "content": f"{anzeige_text}\n\n[Bildbeschreibung: {sauber['text']}]"}
        ]
        antwort = bot.antworte(kontext_liste, fakten, zusatz=_zusatz(persona),
                               stimmung=stimmung.get("text", ""))
        if antwort.get("fehler"):
            antwort["fakten"] = fakten
            return self._json(200, antwort)

        antwort.pop("suche", None)   # hier nicht unterstützt, nur das interne Feld entfernen
        outfit = antwort.pop("outfit", "")
        neue_stimmung = antwort.pop("stimmung", "")
        erinnerung_minuten = antwort.pop("erinnerung_minuten", 0)
        erinnerung_text = antwort.pop("erinnerung_text", "")
        gemerkt = bot.fakt_hinzufuegen(fakten, antwort.pop("merke", ""))
        gewechselt = avatar_studio.bot_wechsel(outfit)
        if gewechselt:
            antwort["avatar_gewechselt"] = gewechselt
        if erinnerung_minuten and erinnerung_text:
            neu = erinnerungen.hinzufuegen(erinnerung_text, erinnerung_minuten)
            if neu:
                antwort["erinnerung_gesetzt"] = {"text": neu["text"], "minuten": erinnerung_minuten}
                antwort["erinnerungen"] = erinnerungen.liste()
        jetzt = time.strftime(ZEITFORMAT)
        verlauf.append({"role": "user", "content": anzeige_text, "zeit": jetzt, "bildschirm": True})
        verlauf.append({"role": "assistant", "content": antwort["text"], "emotion": antwort["emotion"],
                        "geste": antwort["geste"], "zeit": jetzt})
        verlauf = verlauf[-MAX_GESPEICHERT:]
        with _daten_lock:
            speichere_json(VERLAUF_DATEI, verlauf)
            speichere_json(FAKTEN_DATEI, fakten)
            if neue_stimmung:
                speichere_json(STIMMUNG_DATEI, {"text": neue_stimmung, "zeit": jetzt})
        antwort["fakten"] = fakten
        antwort["gemerkt"] = gemerkt
        if sauber.get("gespeichert"):
            antwort["hinweis_eingang"] = True
        return self._json(200, antwort)

    def do_GET(self):
        if not self._erlaubt():
            return self._senden(403, b"verboten", "text/plain")
        pfad = unquote(self.path.split("?")[0])
        if pfad in ("/", "/index.html"):
            self._datei(os.path.join(BASIS, "static"), "index.html")
        elif pfad in ("/avatar.js", "/live2d.js") or pfad.startswith("/lib/"):
            self._datei(os.path.join(BASIS, "static"), pfad.lstrip("/"))
        elif (pfad.startswith("/avatar/") and pfad.lower().endswith(".vrm")
              and "/" not in pfad[len("/avatar/"):]):
            self._datei(AVATAR_DIR, pfad[len("/avatar/"):])
        elif (pfad.startswith("/animation/") and pfad.lower().endswith(".vrma")
              and "/" not in pfad[len("/animation/"):]):
            self._datei(avatar_studio.ANIM_DIR, pfad[len("/animation/"):])
        elif (pfad.startswith("/hintergrund/")
              and os.path.splitext(pfad)[1].lower() in (".png", ".jpg", ".jpeg", ".webp")
              and "/" not in pfad[len("/hintergrund/"):]):
            self._datei(avatar_studio.HG_DIR, pfad[len("/hintergrund/"):])
        elif (pfad.startswith("/avatar2d/")
              and os.path.splitext(pfad)[1].lower() in (".png", ".jpg", ".jpeg", ".webp")
              and "/" not in pfad[len("/avatar2d/"):]):
            self._datei(avatar_studio.ZWEID_DIR, pfad[len("/avatar2d/"):])
        elif pfad.startswith("/live2d/"):
            modell_id, _, unterpfad = pfad[len("/live2d/"):].partition("/")
            if live2d.ID_RE.match(modell_id) and unterpfad:
                self._datei(os.path.join(live2d.MODELL_DIR, modell_id), unterpfad)
            else:
                self._senden(404, b"nicht gefunden", "text/plain")
        elif pfad == "/api/sicherung":
            mit_schluesseln = parse_qs(urlsplit(self.path).query).get("schluessel", ["0"])[0] == "1"
            paket = sicherung.erzeuge(mit_schluesseln)
            self._senden(200, paket, "application/zip",
                        {"Content-Disposition": 'attachment; filename="ki-chatbot-sicherung.zip"'})
        elif pfad == "/api/state":
            _proaktiv_pruefen_und_erzeugen()   # ggf. neue Begrüßung anhängen, bevor wir laden
            _erinnerungen_pruefen_und_erzeugen()   # ggf. fällige Erinnerungen anhängen
            persona = bot.lade_persona()
            with _daten_lock:
                verlauf = lade_json(VERLAUF_DATEI, [])
                fakten = lade_json(FAKTEN_DATEI, [])
                stimmung = lade_json(STIMMUNG_DATEI, {})
            self._json(200, {"name": persona["name"], "tts": tts_verfuegbar(),
                             "begleiter_modus": bool(persona.get("begleiter_modus")),
                             "begleiter_stunden": persona.get("begleiter_stunden", 4),
                             "stimmung": stimmung,
                             "stimme": persona["stimme"],
                             "stimmen": installierte_stimmen(),
                             "avatare": avatar_studio.info(),
                             "idle": {"staerke": persona["idle_staerke"],
                                     "umschauen": persona["idle_umschauen"]},
                             "internet_erlaubt": bool(persona.get("internet_erlaubt")),
                             "internet_dienst": internet.status(),
                             "vision": vision.status(),
                             "tts_engine": tts_engine(),
                             "eleven": elevenlabs.status(),
                             "eingang": sicherheit.liste(),
                             "codeGeaendert": sicherheit.pruefe_code(),
                             "claude": claude_partner.info(),
                             "erinnerungen": erinnerungen.liste(),
                             "discord": discord_bot.status(),
                             "profil": profile.liste(),
                             "verlauf": verlauf[-60:], "fakten": fakten})
        else:
            self._senden(404, b"nicht gefunden", "text/plain")

    def do_POST(self):
        if not self._erlaubt():
            return self._senden(403, b"verboten", "text/plain")
        try:
            p = self.path.split("?")[0]
            laenge = int(self.headers.get("Content-Length", 0))

            # Bildschirmausschnitt hochladen und analysieren lassen (Rohdaten, kein JSON)
            if p == "/api/bildschirm":
                return self._bildschirm_verarbeiten(laenge)

            # VRM-Datei hochladen (Rohdaten, kein JSON)
            if p == "/api/avatar":
                name = parse_qs(urlsplit(self.path).query).get("name", ["avatar.vrm"])[0]
                try:
                    return self._json(200, avatar_studio.hochladen(self.rfile, laenge, name))
                except avatar_studio.AvatarFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # VRMA-Bewegungsdatei hochladen (Rohdaten, kein JSON)
            if p == "/api/animation":
                name = parse_qs(urlsplit(self.path).query).get("name", ["bewegung.vrma"])[0]
                try:
                    return self._json(200, avatar_studio.anim_hochladen(self.rfile, laenge, name))
                except avatar_studio.AvatarFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # 2D-Avatar-Bild für einen Zustand hochladen (Rohdaten, kein JSON)
            if p == "/api/2d_bild":
                qs = parse_qs(urlsplit(self.path).query)
                satz_id = qs.get("satz", [""])[0]
                zustand = qs.get("zustand", [""])[0]
                try:
                    avatar_studio.zd_bild_setzen(satz_id, zustand, self.rfile, laenge)
                    return self._json(200, {"avatare": avatar_studio.info()})
                except avatar_studio.AvatarFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # veadotube-Datei importieren (Rohdaten, kein JSON)
            if p == "/api/2d_veadomini":
                name = parse_qs(urlsplit(self.path).query).get("name", ["import.veadomini"])[0]
                try:
                    ergebnis = avatar_studio.veadomini_importieren(self.rfile, laenge, name)
                    ergebnis["avatare"] = avatar_studio.info()
                    return self._json(200, ergebnis)
                except avatar_studio.AvatarFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # .veado-Datei importieren (rohes veadotube-mini-Projektformat,
            # Rohdaten, kein JSON)
            if p == "/api/2d_veado":
                name = parse_qs(urlsplit(self.path).query).get("name", ["import.veado"])[0]
                try:
                    ergebnis = avatar_studio.veado_importieren(self.rfile, laenge, name)
                    ergebnis["avatare"] = avatar_studio.info()
                    return self._json(200, ergebnis)
                except avatar_studio.AvatarFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # Live2D-Modellpaket hochladen (ZIP, Rohdaten, kein JSON)
            if p == "/api/live2d_import":
                name = parse_qs(urlsplit(self.path).query).get("name", ["modell.zip"])[0]
                try:
                    modell_id = live2d.importieren(self.rfile, laenge, name)
                    return self._json(200, {"id": modell_id, "avatare": avatar_studio.info()})
                except live2d.Live2DFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # Hintergrundbild hochladen (Rohdaten, kein JSON)
            if p == "/api/hintergrund":
                name = parse_qs(urlsplit(self.path).query).get("name", ["hintergrund.png"])[0]
                try:
                    avatar_studio.hg_bild_hochladen(self.rfile, laenge, name)
                    return self._json(200, {"avatare": avatar_studio.info()})
                except avatar_studio.AvatarFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # Spracheingabe: Audioaufnahme aus dem Mikrofon transkribieren
            # (Rohdaten, kein JSON)
            if p == "/api/stt":
                try:
                    text = spracheingabe.transkribieren(self.rfile, laenge)
                    return self._json(200, {"text": text})
                except spracheingabe.SttFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # Sicherung wiedereinspielen (Rohdaten: ZIP, kein JSON)
            if p == "/api/sicherung_einspielen":
                try:
                    eingespielt = sicherung.einspielen(self.rfile, laenge)
                    return self._json(200, {"eingespielt": eingespielt})
                except sicherung.SicherungFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            if laenge > 5 * 1024 * 1024:
                return self._json(413, {"fehler": True, "text": "Anfrage zu groß"})
            daten = json.loads(self.rfile.read(laenge) or b"{}")

            # --- Fremde Inhalte: Code wird nur gespeichert, nie ausgeführt ---
            if p == "/api/extern":
                return self._json(200, sicherheit.extern_verarbeiten(
                    daten.get("quelle", ""), daten.get("text", "")))

            # --- Avatar-Animation (Ruhe-Bewegung) ---
            if p == "/api/idle":
                try:
                    staerke = max(0.0, min(2.0, float(daten.get("staerke", 1))))
                except (TypeError, ValueError):
                    staerke = 1.0
                bot.setze_persona_feld("idle_staerke", staerke)
                bot.setze_persona_feld("idle_umschauen", bool(daten.get("umschauen", True)))
                return self._json(200, {"idle": {"staerke": staerke,
                                                 "umschauen": bool(daten.get("umschauen", True))}})

            # --- Begleiter-Modus ---
            if p == "/api/begleiter":
                if "modus" in daten:
                    bot.setze_persona_feld("begleiter_modus", bool(daten.get("modus")))
                if "stunden" in daten:
                    try:
                        stunden = max(0.1, min(168, float(daten.get("stunden"))))
                    except (TypeError, ValueError):
                        stunden = 4.0
                    bot.setze_persona_feld("begleiter_stunden", stunden)
                persona = bot.lade_persona()
                return self._json(200, {"begleiter_modus": bool(persona.get("begleiter_modus")),
                                        "begleiter_stunden": persona.get("begleiter_stunden", 4)})

            # --- Discord-Anbindung ---
            if p == "/api/discord_key":
                try:
                    if daten.get("loeschen"):
                        discord_bot.key_loeschen()
                    else:
                        discord_bot.key_speichern(daten.get("key", ""))
                except discord_bot.DiscordFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})
                return self._json(200, {"discord": discord_bot.status()})

            if p == "/api/discord":
                if "ein" in daten:
                    gewollt = bool(daten.get("ein"))
                    bot.setze_persona_feld("discord_aktiv", gewollt)
                    try:
                        if gewollt:
                            discord_bot.starten()
                        else:
                            discord_bot.stoppen()
                    except discord_bot.DiscordFehler as e:
                        return self._json(400, {"fehler": True, "text": str(e)})
                return self._json(200, {"discord": discord_bot.status()})

            if p == "/api/stimmung_loeschen":
                with _daten_lock:
                    speichere_json(STIMMUNG_DATEI, {})
                return self._json(200, {"stimmung": {}})

            # --- Websuche an/aus, Dienst wählen, Brave-Schlüssel verwalten ---
            if p == "/api/internet":
                erlaubt = bool(daten.get("erlaubt", False))
                bot.setze_persona_feld("internet_erlaubt", erlaubt)
                return self._json(200, {"internet_erlaubt": erlaubt})

            # --- Sprachausgabe über ElevenLabs ---
            if p.startswith("/api/eleven_"):
                antwort = {}
                try:
                    if p == "/api/eleven_key":
                        if daten.get("loeschen"):
                            elevenlabs.key_loeschen()
                        else:
                            elevenlabs.key_speichern(daten.get("key", ""))
                    elif p == "/api/eleven_einstellungen":
                        elevenlabs.einstellungen_setzen(
                            engine=daten.get("engine"), voice_id=daten.get("voice_id"),
                            voice_name=daten.get("voice_name"), modell=daten.get("modell"))
                    elif p == "/api/eleven_stimmen":
                        antwort["stimmen"] = elevenlabs.stimmen_laden()
                    elif p == "/api/eleven_guthaben":
                        antwort["guthaben"] = elevenlabs.guthaben()
                    else:
                        return self._senden(404, b"nicht gefunden", "text/plain")
                except elevenlabs.ElevenFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})
                antwort.update({"eleven": elevenlabs.status(), "tts": tts_verfuegbar()})
                return self._json(200, antwort)

            if p == "/api/vision_modell":
                try:
                    vision.modell_setzen(daten.get("modell", ""))
                    return self._json(200, {"vision": vision.status()})
                except vision.VisionFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            if p == "/api/internet_dienst":
                try:
                    internet.dienst_setzen(daten.get("dienst", ""), daten.get("searxng_url"))
                    return self._json(200, {"internet_dienst": internet.status()})
                except internet.InternetFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            if p == "/api/internet_brave_key":
                try:
                    if daten.get("loeschen"):
                        internet.brave_key_loeschen()
                    else:
                        internet.brave_key_speichern(daten.get("key", ""))
                    return self._json(200, {"internet_dienst": internet.status()})
                except internet.InternetFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # --- Avatar: Garderobe, Import, Steckbrief ---
            if (p.startswith("/api/avatar_") or p == "/api/animation_loeschen"
                    or p.startswith("/api/hintergrund_") or p.startswith("/api/2d_")
                    or p.startswith("/api/live2d_") or p == "/api/steckbrief"):
                try:
                    return self._json(200, avatar_studio.behandle(p, daten))
                except (avatar_studio.AvatarFehler, claude_partner.ClaudeFehler) as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # --- Gespräch mit Claude (über die API) ---
            if p.startswith("/api/claude_"):
                try:
                    return self._json(200, claude_partner.behandle(p, daten))
                except claude_partner.ClaudeFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            if p == "/api/eingang_lesen":
                r = sicherheit.lesen(daten.get("id", ""))
                if not r:
                    return self._json(404, {"fehler": True, "text": "nicht gefunden"})
                r["eingang"] = sicherheit.liste()
                return self._json(200, r)

            if p == "/api/eingang_loeschen":
                sicherheit.loeschen(daten.get("id", ""))
                return self._json(200, {"eingang": sicherheit.liste()})

            if p == "/api/chat":
                text = str(daten.get("text", "")).strip()
                if not text:
                    return self._json(400, {"fehler": True, "text": "Leere Nachricht."})
                return self._json(200, chat(text))

            if p == "/api/tts":
                text = sprechtext(str(daten.get("text", "")))
                if not text:
                    return self._senden(204, b"", "audio/wav")
                if not tts_verfuegbar():
                    return self._json(503, {"fehler": True, "text":
                                            "Keine Sprachausgabe verfügbar (Piper oder ElevenLabs einrichten)."})
                try:
                    audio, mime, hinweis = erzeuge_sprache(text)
                except elevenlabs.ElevenFehler as e:
                    return self._json(503, {"fehler": True, "text": str(e)})
                kopf = {"X-TTS-Hinweis": quote(hinweis)} if hinweis else None
                return self._senden(200, audio, mime, kopf)

            if p == "/api/stimme":
                name = str(daten.get("name", ""))
                if name not in installierte_stimmen():
                    return self._json(400, {"fehler": True,
                                            "text": "Stimme nicht installiert"})
                bot.setze_persona_feld("stimme", name)
                return self._json(200, {"stimme": name})

            if p == "/api/reset":
                with _daten_lock:
                    speichere_json(VERLAUF_DATEI, [])
                    if daten.get("fakten"):
                        speichere_json(FAKTEN_DATEI, [])
                    fakten = lade_json(FAKTEN_DATEI, [])
                return self._json(200, {"fakten": fakten})

            if p == "/api/fakt_loeschen":
                with _daten_lock:
                    fakten = lade_json(FAKTEN_DATEI, [])
                    i = int(daten.get("index", -1))
                    if 0 <= i < len(fakten):
                        del fakten[i]
                        speichere_json(FAKTEN_DATEI, fakten)
                return self._json(200, {"fakten": fakten})

            # --- Profile (mehrere vollständige Charaktere) ---
            if p == "/api/profil_erstellen":
                try:
                    profile.erstellen(daten.get("name", ""))
                    return self._json(200, profile.liste())
                except profile.ProfilFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            if p == "/api/profil_umbenennen":
                try:
                    profile.umbenennen(daten.get("id", ""), daten.get("name", ""))
                    return self._json(200, profile.liste())
                except profile.ProfilFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            if p == "/api/profil_wechseln":
                try:
                    profile.wechseln(daten.get("id", ""))
                    return self._json(200, {"profil": profile.liste()})
                except profile.ProfilFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            if p == "/api/profil_loeschen":
                try:
                    profile.loeschen(daten.get("id", ""))
                    return self._json(200, profile.liste())
                except profile.ProfilFehler as e:
                    return self._json(400, {"fehler": True, "text": str(e)})

            # --- Erinnerungen/Timer von Hand anlegen/löschen ---
            if p == "/api/erinnerung_hinzufuegen":
                neu = erinnerungen.hinzufuegen(daten.get("text", ""), daten.get("minuten", 0))
                if not neu:
                    return self._json(400, {"fehler": True,
                                            "text": "Text und Minuten angeben (Minuten > 0)."})
                return self._json(200, {"erinnerungen": erinnerungen.liste()})

            if p == "/api/erinnerung_loeschen":
                erinnerungen.entfernen(daten.get("id", ""))
                return self._json(200, {"erinnerungen": erinnerungen.liste()})

            self._senden(404, b"nicht gefunden", "text/plain")
        except Exception as e:  # noqa: BLE001
            self._json(500, {"fehler": True, "text": f"Serverfehler: {e}"})

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    # Nur lokal erreichbar (127.0.0.1)
    try:
        httpd = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError as e:
        print(f"Port {PORT} ist nicht frei ({e}). Läuft der Bot schon? "
              "Beenden mit: ./start.sh stop")
        sys.exit(1)
    print(f"Server läuft auf http://127.0.0.1:{PORT}")
    print("Sprachausgabe:", "bereit" if tts_verfuegbar() else "nicht verfügbar")
    print("Stimme:", bot.lade_persona()["stimme"])
    print("Installiert:", ", ".join(installierte_stimmen()) or "keine")
    abw = sicherheit.pruefe_code(0)
    print("Codeprüfung:", "in Ordnung" if not abw else "ABWEICHUNG: " + ", ".join(abw))
    if bot.lade_persona().get("discord_aktiv") and discord_bot.key_status():
        try:
            discord_bot.starten()
            print("Discord: Anbindung wird gestartet ...")
        except discord_bot.DiscordFehler as e:
            print("Discord: konnte nicht starten:", e, file=sys.stderr)

    def beenden(*_):          # Strg+C und "kill" sauber behandeln, ohne Fehlermeldung
        threading.Thread(target=httpd.shutdown, daemon=True).start()
        discord_bot.stoppen()

    signal.signal(signal.SIGINT, beenden)
    signal.signal(signal.SIGTERM, beenden)
    try:
        httpd.serve_forever()
    finally:
        httpd.server_close()
        print("Server beendet.")
