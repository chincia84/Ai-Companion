#!/usr/bin/env bash
# ------------------------------------------------------------
#  KI-Chatbot - Installer für Linux
#
#  Richtet den Bot aus diesem Repo in einem eigenen Projektordner ein
#  (Standard: ~/ki-chatbot, änderbar über KI_ZIEL). Der Projektordner ist
#  die laufende, schreibgeschützte Kopie - das Repo selbst bleibt ein
#  normaler, von git verwalteter Ordner, den du jederzeit per "git pull"
#  aktualisieren kannst. Nach einem "git pull" dieses Skript einfach
#  erneut ausführen, um die Änderungen in den Projektordner zu übernehmen;
#  eigene Daten (persona.json, daten/, stimmen/, Avatare, ...) bleiben dabei
#  erhalten.
# ------------------------------------------------------------
set -euo pipefail

REPO="$(cd "$(dirname "$0")" && pwd)"
PROJEKT="${KI_ZIEL:-$HOME/ki-chatbot}"
MODELL="${KI_MODELL:-qwen2.5:7b}"

echo "==> Repo:          $REPO"
echo "==> Projektordner: $PROJEKT"

# Diese Dateien gelten als "Programmcode": Sie werden am Ende schreibgeschützt,
# ihr Ordner gesperrt und alles mit Prüfsummen überwacht.
CODE_DATEIEN="bot.py server.py sicherheit.py claude_partner.py avatar_studio.py internet.py vision.py elevenlabs.py live2d.py spracheingabe.py erinnerungen.py discord_bot.py sicherung.py profile.py start.sh code-freigeben.sh static/index.html static/avatar.js"
export PYTHONDONTWRITEBYTECODE=1     # keine __pycache__-Dateien neben dem Code

# ------------------------------------------------------------
# 1) Vorbereitung: Sperre aus einem früheren Durchlauf aufheben, Ordner anlegen
# ------------------------------------------------------------
if [ -d "$PROJEKT" ]; then
  chmod u+w "$PROJEKT"
  if [ -d "$PROJEKT/static" ]; then chmod -R u+w "$PROJEKT/static"; fi
  for f in $CODE_DATEIEN .code-pruefsummen; do
    if [ -e "$PROJEKT/$f" ]; then chmod u+w "$PROJEKT/$f"; fi
  done
fi

mkdir -p "$PROJEKT/static" "$PROJEKT/daten" "$PROJEKT/stimmen" "$PROJEKT/avatar" "$PROJEKT/import" "$PROJEKT/animationen" "$PROJEKT/hintergruende" "$PROJEKT/avatare2d" "$PROJEKT/live2d"
mkdir -p "$PROJEKT/eingang" && chmod 700 "$PROJEKT/eingang"

# ------------------------------------------------------------
# 2) Code-Dateien aus dem Repo in den Projektordner kopieren
# ------------------------------------------------------------
echo "==> Kopiere Code-Dateien ins Projektverzeichnis"
cp "$REPO"/*.py "$PROJEKT/"
cp "$REPO/start.sh" "$REPO/code-freigeben.sh" "$PROJEKT/"
cp "$REPO/static/index.html" "$REPO/static/avatar.js" "$REPO/static/live2d.js" "$PROJEKT/static/"
chmod +x "$PROJEKT/start.sh" "$PROJEKT/code-freigeben.sh"

# ------------------------------------------------------------
# 3) Persona anlegen. Beim ersten Mal wird der Name des Bots festgelegt:
#   - Umgebungsvariable KI_NAME (auch bei bestehender Installation, ändert den Namen)
#   - sonst Abfrage im Terminal (Enter = Zufallsname)
#   - sonst (kein Terminal) Zufallsname
# ------------------------------------------------------------
NAMEN=(Mika Lena Nova Luna Emi Yuna Kira Mira Runa Nia Ada Juno Momo Kaya Ilva Sora)
BOT_NAME="${KI_NAME:-}"
if [ -z "$BOT_NAME" ] && [ ! -f "$PROJEKT/persona.json" ]; then
  if [ -t 0 ]; then
    echo
    read -r -p "==> Wie soll dein Bot heißen? (Enter = Zufallsname) " BOT_NAME || BOT_NAME=""
  fi
  if [ -z "${BOT_NAME// /}" ]; then
    BOT_NAME="${NAMEN[RANDOM % ${#NAMEN[@]}]}"
    echo "    Zufallsname gewählt: $BOT_NAME"
  fi
fi
if [ -n "$BOT_NAME" ]; then
  (cd "$PROJEKT" && BOT_NAME="$BOT_NAME" python3 -c \
    'import os, bot; bot.lade_persona(); bot.setze_persona_feld("name", os.environ["BOT_NAME"].strip()[:30])')
else
  (cd "$PROJEKT" && python3 -c "import bot; bot.lade_persona()")   # Standardwerte, falls nötig
fi
BOT_NAME="$(cd "$PROJEKT" && python3 -c 'import bot; print(bot.lade_persona()["name"])')"
echo "==> Name des Bots: $BOT_NAME"

# ------------------------------------------------------------
# 4) Starter im Anwendungsmenü
# ------------------------------------------------------------
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/ki-chatbot.desktop" << DESKTOPEOF
[Desktop Entry]
Type=Application
Name=KI-Chatbot
Comment=Lokaler KI-Chatbot mit Ollama
Exec=$PROJEKT/start.sh
Icon=utilities-terminal
Terminal=false
Categories=Utility;
DESKTOPEOF

# ------------------------------------------------------------
# 5) Ollama prüfen / optional installieren
# ------------------------------------------------------------
export PATH="$HOME/.local/bin:$PATH"

if ! command -v ollama > /dev/null; then
  echo
  echo "==> Ollama ist nicht installiert."
  read -r -p "    Jetzt nach ~/.local installieren (ohne Root)? [j/N] " antwort
  if [[ "$antwort" =~ ^[jJyY]$ ]]; then
    TMP="$(mktemp -d)"
    if curl -fL "https://ollama.com/download/ollama-linux-amd64.tar.zst" \
         -o "$TMP/ollama.tar.zst" \
       && mkdir -p "$HOME/.local" \
       && tar --zstd -C "$HOME/.local" -xf "$TMP/ollama.tar.zst"; then
      echo "    Ollama installiert."
    else
      echo "    Download fehlgeschlagen. Installiere Ollama manuell"
      echo "    (siehe ollama.com/download) und starte dieses Skript erneut."
    fi
    rm -rf "$TMP"
  else
    echo "    Übersprungen. Ohne Ollama antwortet der Bot nicht."
  fi
fi

if command -v ollama > /dev/null; then
  if ! curl -s http://localhost:11434/ > /dev/null 2>&1; then
    ollama serve > /tmp/ollama.log 2>&1 &
    OLLAMA_TMP=$!
    for _ in $(seq 1 20); do
      curl -s http://localhost:11434/ > /dev/null 2>&1 && break
      sleep 0.5
    done
  fi
  echo
  echo "==> Prüfe Modell: $MODELL"
  if ollama list 2>/dev/null | grep -qF "$MODELL"; then
    echo "    Modell ist schon vorhanden."
  else
    for versuch in 1 2 3; do
      ollama pull "$MODELL" && break
      echo "    Versuch $versuch fehlgeschlagen, neuer Versuch ..."
      sleep 3
    done
  fi
  [ -n "${OLLAMA_TMP:-}" ] && kill "$OLLAMA_TMP" 2>/dev/null || true
fi

# ------------------------------------------------------------
# 6) Sprachausgabe (Piper), Spracheingabe (faster-whisper) und
#    Discord-Anbindung: alle drei in einer gemeinsamen venv
# ------------------------------------------------------------
echo
echo "==> Richte Sprachausgabe (Piper) ein"
if [ ! -x "$PROJEKT/venv/bin/python" ]; then
  # Kaputte oder unvollständige venv aus einem früheren Versuch entfernen
  rm -rf "$PROJEKT/venv"
  python3 -m venv "$PROJEKT/venv" \
    || echo "    venv konnte nicht erstellt werden."
fi
if [ -x "$PROJEKT/venv/bin/python" ]; then
  if "$PROJEKT/venv/bin/python" -m pip install --upgrade piper-tts; then
    STIMME="$(cd "$PROJEKT" && python3 -c 'import bot; print(bot.lade_persona()["stimme"])')"
    echo "==> Lade Stimme: $STIMME"
    "$PROJEKT/venv/bin/python" -m piper.download_voices "$STIMME" \
      --data-dir "$PROJEKT/stimmen" \
      || echo "    Stimme konnte nicht geladen werden."
    # Weitere Stimmen zur Auswahl im Fenster (Umgebungsvariable KI_ZUSATZ_STIMMEN)
    for extra in ${KI_ZUSATZ_STIMMEN-de_DE-ramona-low de_DE-kerstin-low de_DE-eva_k-x_low}; do
      [ "$extra" = "$STIMME" ] && continue
      echo "==> Lade zusätzliche Stimme: $extra"
      "$PROJEKT/venv/bin/python" -m piper.download_voices "$extra" \
        --data-dir "$PROJEKT/stimmen" \
        || echo "    $extra konnte nicht geladen werden."
    done
  else
    echo "    Piper konnte nicht installiert werden. Der Bot läuft trotzdem,"
    echo "    nur ohne Sprachausgabe."
  fi

  echo "==> Richte Spracheingabe (faster-whisper) ein"
  if "$PROJEKT/venv/bin/python" -m pip install --upgrade faster-whisper; then
    echo "==> Lade Spracherkennungs-Modell vor (einmalig, kann einen Moment dauern)"
    (cd "$PROJEKT" && "$PROJEKT/venv/bin/python" -c "import spracheingabe; spracheingabe._hole_modell()") \
      || echo "    Modell konnte nicht vorab geladen werden - wird beim ersten Gebrauch im Bot nachgeholt."
  else
    echo "    faster-whisper konnte nicht installiert werden. Der Bot läuft trotzdem,"
    echo "    nur ohne Spracheingabe per Mikrofon."
  fi

  echo "==> Richte Discord-Anbindung ein (nur nötig, falls du das nutzt)"
  if ! "$PROJEKT/venv/bin/python" -m pip install --upgrade "discord.py>=2.3"; then
    echo "    discord.py konnte nicht installiert werden. Der Bot läuft trotzdem,"
    echo "    nur ohne Discord-Anbindung."
  fi
fi

# ------------------------------------------------------------
# 7) 3D-Bibliotheken (three.js + three-vrm) und Live2D lokal ablegen
#    Danach läuft alles offline. Quelle: npm-Registry.
# ------------------------------------------------------------
LIB="$PROJEKT/static/lib"
THREE_V="${KI_THREE_VERSION:-0.177.0}"
VRM_V="${KI_VRM_VERSION:-3.4.2}"
VRMA_V="${KI_VRM_ANIMATION_VERSION:-$VRM_V}"

if [ -f "$LIB/three/build/three.module.js" ] && [ -f "$LIB/three-vrm.module.min.js" ]; then
  echo
  echo "==> 3D-Bibliotheken sind schon vorhanden."
else
  echo
  echo "==> Lade 3D-Bibliotheken (three $THREE_V, three-vrm $VRM_V)"
  TMP="$(mktemp -d)"
  mkdir -p "$TMP/three" "$TMP/vrm" "$LIB/three"
  if curl -fL "https://registry.npmjs.org/three/-/three-$THREE_V.tgz" -o "$TMP/three.tgz" \
     && curl -fL "https://registry.npmjs.org/@pixiv/three-vrm/-/three-vrm-$VRM_V.tgz" -o "$TMP/vrm.tgz"; then
    tar -xzf "$TMP/three.tgz" -C "$TMP/three" --wildcards \
      'package/build/three.module.js' 'package/build/three.core.js' \
      'package/examples/jsm/loaders/GLTFLoader.js' \
      'package/examples/jsm/utils/BufferGeometryUtils.js' \
      'package/examples/jsm/controls/OrbitControls.js' || true
    tar -xzf "$TMP/vrm.tgz" -C "$TMP/vrm" --wildcards \
      'package/lib/three-vrm.module.min.js' || true
    cp -r "$TMP/three/package/build" "$LIB/three/" 2>/dev/null || true
    cp -r "$TMP/three/package/examples" "$LIB/three/" 2>/dev/null || true
    cp "$TMP/vrm/package/lib/three-vrm.module.min.js" "$LIB/" 2>/dev/null || true
  else
    echo "    Download fehlgeschlagen."
  fi
  rm -rf "$TMP"
  if [ -f "$LIB/three/build/three.module.js" ] && [ -f "$LIB/three-vrm.module.min.js" ]; then
    echo "    3D-Bibliotheken installiert."
  else
    echo "    3D-Bibliotheken fehlen. Der Bot läuft trotzdem, nur ohne 3D-Avatar."
    echo "    Skript später nochmal ausführen (Internet nötig)."
  fi
fi

# Zusatzpaket, damit fertige .vrma-Bewegungsdateien abgespielt werden können
if [ -f "$LIB/three-vrm-animation.module.min.js" ]; then
  echo "==> Bibliothek für Bewegungsdateien ist schon vorhanden."
else
  echo "==> Lade Bibliothek für Bewegungsdateien (three-vrm-animation $VRMA_V)"
  TMP="$(mktemp -d)"
  if curl -fL "https://registry.npmjs.org/@pixiv/three-vrm-animation/-/three-vrm-animation-$VRMA_V.tgz" \
       -o "$TMP/anim.tgz"; then
    mkdir -p "$TMP/anim"
    tar -xzf "$TMP/anim.tgz" -C "$TMP/anim" --wildcards \
      'package/lib/three-vrm-animation.module.min.js' \
      'package/lib/three-vrm-animation.module.js' || true
    if [ -f "$TMP/anim/package/lib/three-vrm-animation.module.min.js" ]; then
      cp "$TMP/anim/package/lib/three-vrm-animation.module.min.js" "$LIB/"
    elif [ -f "$TMP/anim/package/lib/three-vrm-animation.module.js" ]; then
      cp "$TMP/anim/package/lib/three-vrm-animation.module.js" "$LIB/three-vrm-animation.module.min.js"
    fi
  fi
  rm -rf "$TMP"
  if [ -f "$LIB/three-vrm-animation.module.min.js" ]; then
    echo "    Bibliothek für Bewegungsdateien installiert."
  else
    echo "    Bibliothek für Bewegungsdateien fehlt. Avatare funktionieren trotzdem,"
    echo "    nur ohne Abspielen von .vrma-Dateien. Skript später erneut ausführen."
  fi
fi

# Live2D (.moc3): PixiJS + pixi-live2d-display (Cubism 4) + Cubism Core.
# Cubism Core ist eine proprietäre Bibliothek von Live2D Inc. und darf laut Live2D
# nicht frei weiterverteilt werden; sie wird deshalb direkt von Live2Ds eigener
# Adresse geladen, genau wie es auch offizielle Beispiele tun. Klappt der
# automatische Download nicht, lädst du sie von https://www.live2d.com/en/sdk/download/web/
# von Hand und legst die Datei "live2dcubismcore.min.js" in $LIB ab.
if [ -f "$LIB/live2dcubismcore.min.js" ] && [ -f "$LIB/pixi.min.js" ] \
   && [ -f "$LIB/pixi-live2d-display-cubism4.min.js" ]; then
  echo
  echo "==> Live2D-Bibliotheken sind schon vorhanden."
else
  echo
  echo "==> Lade Live2D-Bibliotheken (PixiJS, pixi-live2d-display, Cubism Core)"

  # Cubism Core direkt von Live2D
  curl -fL "https://cubism.live2d.com/sdk-web/cubismcore/live2dcubismcore.min.js" \
    -o "$LIB/live2dcubismcore.min.js" 2>/dev/null \
    || echo "    Cubism Core konnte nicht automatisch geladen werden."

  # PixiJS und pixi-live2d-display: aktuelle Version über die npm-Registry ermitteln,
  # damit keine Versionsnummer fest im Skript stehen muss.
  hole_neuestes_npm_paket() {   # $1 = Paketname, $2 = Zielordner, $3 = Haupt-
                                # versionsnummer als Festlegung (optional, z. B. "6")
    local meta tarball
    if [ -n "${3:-}" ]; then
      # Volle Paket-Metadaten statt des "/latest"-Tags, damit gezielt die
      # neueste Version EINER bestimmten Hauptversion gewählt werden kann -
      # pixi-live2d-display unterstützt z. B. kein PixiJS 8, "latest" wäre
      # also falsch.
      meta="$(curl -fsL "https://registry.npmjs.org/$1" 2>/dev/null)" || return 1
      tarball="$(echo "$meta" | python3 -c "
import json, sys
haupt = sys.argv[1]
try:
    d = json.load(sys.stdin)
    kandidaten = []
    for v, info in d.get('versions', {}).items():
        teile = v.split('.')
        if teile and teile[0] == haupt:
            try:
                schluessel = tuple(int(t) for t in teile[:3])
            except ValueError:
                continue   # Vorab-/Beta-Version ueberspringen
            kandidaten.append((schluessel, info['dist']['tarball']))
    if kandidaten:
        kandidaten.sort()
        print(kandidaten[-1][1])
except Exception:
    pass
" "$3" 2>/dev/null)"
    else
      meta="$(curl -fsL "https://registry.npmjs.org/$1/latest" 2>/dev/null)" || return 1
      tarball="$(echo "$meta" | python3 -c \
        'import json,sys
try:
    print(json.load(sys.stdin)["dist"]["tarball"])
except Exception:
    pass' 2>/dev/null)"
    fi
    [ -n "$tarball" ] || return 1
    mkdir -p "$2"
    curl -fL "$tarball" -o "$2/paket.tgz" 2>/dev/null || return 1
    # Entpacken per Python statt per externem "tar": manche npm-Pakete
    # veröffentlichen Ordner/Dateien mit zu restriktiven Rechten, die ein
    # systemeigenes tar (je nach Version/Umgebung) trotz
    # "--no-same-permissions" übernimmt. Hier überschreiben wir die Rechte
    # jedes Archiv-Mitglieds selbst, bevor überhaupt etwas geschrieben wird.
    python3 - "$2/paket.tgz" "$2" <<'PYEOF2' || return 1
import sys, tarfile
quelle, ziel = sys.argv[1], sys.argv[2]
with tarfile.open(quelle) as tf:
    mitglieder = tf.getmembers()
    for m in mitglieder:
        if m.isdir():
            m.mode = 0o755
        elif not (m.issym() or m.islnk()):
            m.mode = 0o644
    try:
        tf.extractall(ziel, mitglieder, filter="fully_trusted")
    except TypeError:   # ältere Python-Version ohne "filter"-Parameter
        tf.extractall(ziel, mitglieder)
PYEOF2
    chmod -R u+rwX "$2" 2>/dev/null   # zur Sicherheit, falls doch noch etwas
                                      # schreibgeschützt übrig bleibt
  }

  TMP="$(mktemp -d)"
  if hole_neuestes_npm_paket "pixi.js" "$TMP/pixi" "6"; then
    for kandidat in "$TMP/pixi/package/dist/pixi.min.js" "$TMP/pixi/package/dist/pixi.js" \
                    "$TMP/pixi/package/dist/browser/pixi.min.js"; do
      [ -f "$kandidat" ] && cp "$kandidat" "$LIB/pixi.min.js" && break
    done
  fi
  if hole_neuestes_npm_paket "pixi-live2d-display" "$TMP/l2d"; then
    for kandidat in "$TMP/l2d/package/dist/cubism4.min.js" "$TMP/l2d/package/dist/cubism4.js" \
                    "$TMP/l2d/package/dist/index.min.js"; do
      [ -f "$kandidat" ] && cp "$kandidat" "$LIB/pixi-live2d-display-cubism4.min.js" && break
    done
  fi
  chmod -R u+rwX "$TMP" 2>/dev/null   # falls trotzdem noch etwas schreibgeschützt ist
  rm -rf "$TMP"

  if [ -f "$LIB/live2dcubismcore.min.js" ] && [ -f "$LIB/pixi.min.js" ] \
     && [ -f "$LIB/pixi-live2d-display-cubism4.min.js" ]; then
    echo "    Live2D-Bibliotheken installiert."
  else
    echo "    Live2D-Bibliotheken konnten nicht vollständig automatisch geladen werden."
    echo "    Live2D-Avatare funktionieren dann nicht, der Rest des Bots schon."
    echo "    Fehlende Dateien von Hand in $LIB ablegen:"
    [ -f "$LIB/live2dcubismcore.min.js" ] || echo "      - live2dcubismcore.min.js: https://www.live2d.com/en/sdk/download/web/"
    [ -f "$LIB/pixi.min.js" ] || echo "      - pixi.min.js: https://www.npmjs.com/package/pixi.js (dist/pixi.min.js)"
    [ -f "$LIB/pixi-live2d-display-cubism4.min.js" ] || echo "      - pixi-live2d-display-cubism4.min.js: https://www.npmjs.com/package/pixi-live2d-display (dist/cubism4.min.js)"
  fi
fi

# ------------------------------------------------------------
# 8) Schutz: Programmcode schreibschützen + Prüfsummen anlegen
# ------------------------------------------------------------
echo
echo "==> Sichere Programmcode (Schreibschutz + Prüfsummen)"
"$PROJEKT/code-freigeben.sh"

cat << FERTIG

============================================================
 Fertig!
 - Starten:    $PROJEKT/start.sh   (Beenden: Fenster schließen oder Strg+C,
               von einem anderen Terminal: $PROJEKT/start.sh stop)
               oder "KI-Chatbot" im Anwendungsmenü
 - Name:       $BOT_NAME  (ändern: KI_NAME=Neuer ./install.sh
               oder in persona.json)
 - Persona:    $PROJEKT/persona.json  (Name, Charakter, Stil, Stimme)
               Nach Änderungen Bot neu starten.
 - Gedächtnis: $PROJEKT/daten/  (verlauf.json, fakten.json)
 - Schutz:     Programmcode und sein Ordner sind gesperrt und werden
               mit Prüfsummen überwacht. Fremder Code landet nur in
               $PROJEKT/eingang/ und wird nie ausgeführt (Ansicht: Bereich
               "Eingang" im Fenster).
               Eigene Änderungen am Code:
                 $PROJEKT/code-freigeben.sh entsperren
                 ... Dateien ändern ...
                 $PROJEKT/code-freigeben.sh
               Testdateien bitte nicht im Projektordner erzeugen.
 - Aktualisieren: im Repo-Ordner "git pull", dann hier ./install.sh
               erneut ausführen. Eigene Daten bleiben erhalten.
 - Claude:     Bereich "Gespräch mit Claude" im Fenster. Braucht einen
               API-Schlüssel (Eintrag dort oder Umgebungsvariable
               ANTHROPIC_API_KEY). Gespräche werden in $PROJEKT/daten/
               claude-gespraeche/ protokolliert.
 - Discord:    Bereich "Kommunikation" im Fenster (Bot-Token aus dem
               Discord Developer Portal, siehe README).
 - Stimmen:    $PROJEKT/stimmen/  (Auswahl oben im Fenster)
               Optional ElevenLabs (Cloud): Einstellungen -> Stimme
 - Avatar:     Bereich "Avatar, Garderobe und Steckbrief" im Fenster.
               Aus VRoid Studio als .vrm nach $PROJEKT/import/ exportieren:
               neue Dateien erscheinen dort zur Bestätigung.
 - Modell:     $MODELL  (ändern: KI_MODELL=... ./start.sh)

 Später erweitern:
 - Gehirn tauschen:  bot.py -> Funktion antworte()
 - Avatar:           static/index.html -> avatarReagiere(), avatarMund()
============================================================
FERTIG
